import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');out=root/'target/live-perf/paused-iterm-events';out.mkdir(exist_ok=True)
name='rbirds-perf-paused-iterm-events'
command=shlex.join(['/usr/bin/env','RBIRDS_TRACE='+str(out/'candidate.jsonl'),'/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),str(root/'target/live-perf/paused-after-rbirds'),'--panel','--render','sixel','--seed','42','--frames','2400','--trails','--depth','--hawks','4','--flocks','3','--color','ember'])
started=time.monotonic()
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True))
print('own window',window,flush=True)
events=[]
def action(text):
    script=f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window})\n{text}\nend tell'
    subprocess.run(['osascript','-e',script],check=True)
    events.append({'action':text,'seconds_after_launch':time.monotonic()-started})
def shot(label):
    path=subprocess.check_output(['/opt/homebrew/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True)
    (out/(label+'-screenshot.txt')).write_text(path)
    print(label,path.strip(),flush=True)
time.sleep(4)
action('write text " " newline NO')
time.sleep(1)
shot('paused')
capture=subprocess.Popen([str(root/'target/presentation-capture'),name,str(out/'presentation.json'),'20'])
for text in ['write text "." newline NO','write text "h" newline NO','set columns to 120\nset rows to 36','write text "h" newline NO','write text " " newline NO']:
    time.sleep(3)
    action(text)
assert capture.wait(timeout=30)==0
shot('resumed')
(out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
for _ in range(100):
    if (out/'completed.json').exists():
        assert json.loads((out/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:raise RuntimeError('run did not finish')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
