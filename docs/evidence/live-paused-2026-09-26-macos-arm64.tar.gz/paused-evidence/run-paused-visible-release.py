import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');out=root/'target/live-perf/paused-visible-current';out.mkdir(exist_ok=True)
kitty='/Applications/kitty.app/Contents/MacOS/kitty'
for mode in ['default','kitty','sixel']:
    for side in ['before','after']:
        name=f'rbirds-perf-paused-{mode}-{side}'
        binary=root/'target/live-perf'/f'paused-{side}-rbirds'
        measure=['/usr/bin/env','RBIRDS_TRACE='+str(out/(name+'.jsonl')),'/opt/homebrew/bin/python3',str(root/'tools/terminal-perf.py'),'--warmup-seconds','7','--sample-seconds','10','--output',str(out/(name+'.json')),'--note','Own visible test window, paused before interval sample; no capture, profiling, builds or tests; UFC off']
        if mode=='sixel':
            helper=subprocess.check_output(['pgrep','-x','iTerm2SandboxedWorker'],text=True).strip()
            assert helper.isdecimal(),helper
            measure+=['--terminal-pid','73499','--helper-pid',helper]
        measure+=['--',str(binary),'--seed','42','--frames','1200']
        if mode!='default':measure+=['--render',mode]
        if mode=='sixel':
            command=shlex.join(['/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/(name+'-completed.json')),*measure])
            window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True))
            time.sleep(4)
            subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text " " newline NO'],check=True)
        else:
            socket=out/(mode+'-'+side+'.sock')
            assert not socket.exists(),socket
            process=subprocess.Popen(['open','-W','-n','-a','kitty','--args','--config','NONE','--title',name,'--listen-on','unix:'+str(socket),'--override','allow_remote_control=socket-only','--override','initial_window_width=800','--override','initial_window_height=500','--override','remember_window_size=no','--override','macos_quit_when_last_window_closed=yes',*measure])
            time.sleep(4)
            listing=json.loads(subprocess.check_output([kitty,'@','--to','unix:'+str(socket),'ls'],text=True))
            titles=[w['title'] for osw in listing for tab in osw['tabs'] for w in tab['windows']]
            windows=[w for osw in listing for tab in osw['tabs'] for w in tab['windows']]
            assert len(windows)==1,windows
            subprocess.run([kitty,'@','--to','unix:'+str(socket),'send-text','--match','id:'+str(windows[0]['id']),' '],check=True)
        (out/(name+'-event.json')).write_text(json.dumps({'input':' ','monotonic':time.monotonic()})+'\n')
        if mode=='sixel':
            for _ in range(100):
                done=out/(name+'-completed.json')
                if done.exists():
                    assert json.loads(done.read_text())['status']==0
                    break
                time.sleep(.5)
            else:raise RuntimeError('Run did not finish')
            subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
        else:
            assert process.wait(timeout=40)==0
        r=json.loads((out/(name+'.json')).read_text())
        assert r['status']==0 and 'error' not in r['interval_sample'],r
        if mode=='sixel':assert 'cpu_ms_per_second' in r['interval_sample']['terminal_helpers'],r
        print(name,r['interval_sample'],flush=True)
