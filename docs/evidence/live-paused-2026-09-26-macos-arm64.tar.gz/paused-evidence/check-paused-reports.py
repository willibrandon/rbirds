import importlib.util,json
from pathlib import Path
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
report=load('trace_report','tools/trace-report.py');live=load('live_perf','tools/live-perf.py')
root=Path('target/live-perf/trace-idle-check');root.mkdir(exist_ok=True)
def check(name,ticks):
    samples=[dict(kind='frame',start_us=t,drawn=d,update_us=0,compose_us=0,encode_us=0,flush_us=0,wake_late_us=0) for t,d in ticks]
    path=root/(name+'.jsonl')
    summary=dict(kind='summary',version=1,renderer='test',viewport=[1,1,1,1],wall_us=10000000,cpu_us=100,samples=len(samples),omitted=0,drawn_frames=sum(d for t,d in ticks))
    path.write_text('\n'.join(json.dumps(x) for x in [summary,*samples])+'\n')
    return report.summarize(path,0)
r=check('pause-resume',[(0,True),(16000,True),(32000,False),(9000000,False),(9016000,True),(9032000,True)])
assert r['gaps_over_25ms']==0 and r['sampled_frames']==4 and r['sampled_idle_ticks']==2,r
r=check('idle-only',[(0,False)])
assert r['live_cpu_ms_per_frame'] is None and r['interval_ms_after_warmup'] is None,r
r=check('separate-stalls',[(0,True),(40000,True),(50000,False),(60000,True),(100000,True)])
assert r['gaps_over_25ms']==2 and r['longest_run_of_gaps_over_25ms']==1,r
assert live.longest_gap_run([40,None,40])==1
r=report.summarize(Path('target/live-perf/paused-pty/default-before.jsonl'),2)
assert r['sampled_frames']==300 and r['sampled_idle_ticks']==0,r
print('Report checks passed: legacy, idle-only, pause/resume and separated stalls')
