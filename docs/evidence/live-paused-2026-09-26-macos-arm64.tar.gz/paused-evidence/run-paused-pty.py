import json,subprocess,sys
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');out=root/'target/live-perf/paused-pty';out.mkdir(exist_ok=True)
side=sys.argv[1]
for mode in ['default','kitty','sixel']:
    name=f'{mode}-{side}'
    cmd=[sys.executable,str(root/'tools/live-perf.py'),'--binary',str(root/'target/live-perf'/f'paused-{side}-rbirds'),'--render',mode,'--frames','300','--cols','100','--rows','32','--cell-width','14','--cell-height','34','--input-at','1','--input',' ','--trace',str(out/(name+'.jsonl')),'--output',str(out/(name+'.json'))]
    subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
    r=json.loads((out/(name+'.json')).read_text())
    print(name,{k:v for k,v in r.items() if 'cpu' in k or 'bytes' in k},flush=True)
