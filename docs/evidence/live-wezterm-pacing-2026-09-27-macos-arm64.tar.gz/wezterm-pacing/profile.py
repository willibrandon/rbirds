import json,subprocess,sys,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from process_usage import Counters
session=json.loads((work/'session.json').read_text());pid=session['terminal_pid']
output=work/'profile';output.mkdir()
assert not(work/'child.json').exists()
(work/'job.json').write_text(json.dumps({'title':'rbirds-perf-wezterm-profile',
 'command':['/usr/bin/env','RBIRDS_TRACE='+str(output/'trace.jsonl'),str(work/'baseline/rbirds'),'--render','sixel','--seed','42','--frames','1200'],
 'completed':str(output/'completed.json')}))
time.sleep(.4)
subprocess.run(['osascript','-e',f'tell application "System Events" to tell (first application process whose unix id is {pid})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "rbirds-perf-wezterm-profile")\nend tell'],check=True)
time.sleep(3)
with (output/'sample-tool.txt').open('w') as log:
    sample=subprocess.run(['/usr/bin/sample',str(pid),'5','1','-file',str(output/'terminal.sample.txt')],stdout=log,stderr=subprocess.STDOUT)
    assert sample.returncode==0
print('Terminal sample recorded.',flush=True)
observations=[];start=time.monotonic()
with Counters() as counters:
    while not(output/'completed.json').exists():
        if time.monotonic()-start>100:raise TimeoutError('profiled command')
        memory=counters.snapshot(pid).memory
        observations.append({'seconds':time.monotonic()-start,'memory':memory})
        assert memory['physical_footprint']<2*1024**3
        time.sleep(1)
(output/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
assert json.loads((output/'completed.json').read_text())['status']==0
print('Profiled command completed.',flush=True)
