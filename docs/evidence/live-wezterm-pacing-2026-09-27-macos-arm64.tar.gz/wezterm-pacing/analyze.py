import collections,importlib.util,json,math,statistics
from pathlib import Path
work=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('comparison',work/'compare-fixed-scenes.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
cpu={}
for experiment,cases in [('ack',['normal']),('inline',['normal','dense'])]:
    for case in cases:
        paths=sorted((work/(experiment+'-cpu')).glob(case+'-*/cpu.json'))
        assert len(paths)==4
        compared=mod.compare([json.loads(p.read_text()) for p in paths])
        groups={v:[row for path,row in zip(paths,compared['runs']) if v in path.parent.name] for v in ['baseline','candidate']}
        summary={v:{'app_ms_per_frame':statistics.mean(r['cpu_ms_per_frame']['application'] for r in rows),
                    'terminal_ms_per_frame':statistics.mean(r['cpu_ms_per_frame']['terminal'] for r in rows),
                    'combined_ms_per_frame':statistics.mean(r['cpu_ms_per_frame']['combined'] for r in rows),
                    'combined_cpu_percent':statistics.mean(r['cpu_ms_per_second']['combined']/10 for r in rows),
                    'submitted_hz':statistics.mean(600/r['wall_seconds'] for r in rows)} for v,rows in groups.items()}
        cpu[experiment+'-'+case]={'summary':summary,'comparison':compared}
presentation={}
for experiment in ['ack','pipeline','inline']:
    for path in sorted((work/(experiment+'-visible')).glob('*/presentation.json')):
        data=json.loads(path.read_text());frames=data['frames']
        times=[f['pts'] for f in frames if f['changed']]
        gaps=sorted((b-a)*1000 for a,b in zip(times,times[1:]))
        item={'samples':len(frames),'visible_hz':(len(times)-1)/(times[-1]-times[0]),
              'p99_gap_ms':gaps[math.ceil(len(gaps)*.99)-1],'max_gap_ms':max(gaps),
              'dominant_rgb':collections.Counter(str(f['dominant_rgb']) for f in frames),
              'focus_samples':len(data['focus_observations']),
              'focus':all(f['owner_active'] and f['top_normal_window'] for f in data['focus_observations'])}
        assert item['focus'] and all(f['dominant_rgb']==[17,17,22] for f in frames)
        presentation[str(path.parent.relative_to(work))]=item
for root in ['ack-cpu','inline-cpu','ack-visible','pipeline-visible','inline-visible']:
    for directory in (work/root).iterdir():
        assert json.loads((directory/'completed.json').read_text())['status']==0
        assert json.loads((directory/'result.json').read_text())['termios_equal']
        assert all(row.get('owner_active',True) for row in json.loads((directory/'observations.json').read_text()))
out={'cpu':cpu,'presentation':presentation}
(work/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'cpu':{k:v['summary'] for k,v in cpu.items()},'presentation':presentation},indent=2))
