import hashlib,json,shutil,tarfile
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
stage=work/'evidence';stage.mkdir()
names=[str(p.relative_to(work)) for p in work.iterdir() if p.is_file() and p.suffix in ['.py','.rs','.json','.lua','.log']]
names += [str(p.relative_to(work)) for name in ['profile','upstream','ack-cpu','ack-visible','pipeline-visible','inline-cpu','inline-visible']
          for p in sorted((work/name).rglob('*')) if p.is_file() and p.suffix in ['.png','.json','.jsonl','.txt','.rs']]
for name in names:
    dest=stage/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(work/name,dest)
for name in ['src/live.rs','src/render/compose.rs','src/terminal.rs','Cargo.toml','Cargo.lock','rust-toolchain.toml',
             'tools/terminal-perf.py','tools/process_usage.py','tools/presentation-capture.swift']:
    dest=stage/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,dest)
manifest={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root/'docs/evidence/live-wezterm-pacing-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(stage,arcname='wezterm-pacing')
with tarfile.open(archive,'r:gz') as tar:
    for name,expected in manifest.items():assert hashlib.sha256(tar.extractfile('wezterm-pacing/'+name).read()).hexdigest()==expected,name
result={'files':len(manifest),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(work/'archive.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
