import fcntl, hashlib, json, os, shutil, struct, subprocess, sys, termios, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds')
work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from process_usage import Counters
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
session=json.loads((work/'session.json').read_text());pid=session['terminal_pid']
if sys.argv[1]=='child':
    directory=Path(sys.argv[2]);job=json.loads((directory/'job.json').read_text())
    before=termios.tcgetattr(0)
    save(directory/'geometry.json',struct.unpack('HHHH',fcntl.ioctl(1,termios.TIOCGWINSZ,b'\0'*8)))
    command=job['command'];env=os.environ.copy()
    if job['kind']=='cpu':
        command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(directory/'cpu.json'),
          '--trace',str(directory/'trace.jsonl'),'--terminal-pid',str(pid),'--fixture-frames','180:600',
          '--note','Experimental per-frame DA acknowledgement; owned foreground WezTerm 20240203, 100x32, same config and fixed inputs, UFC off; no builds/tests/profiling/capture during CPU; 1 Hz memory guard and 5 s focus observations', '--',*command]
    else: env['RBIRDS_TRACE']=str(directory/'trace.jsonl')
    status=subprocess.run(command,env=env).returncode
    save(directory/'result.json',{'status':status,'termios_equal':before==termios.tcgetattr(0)})
    raise SystemExit(status)
kind=sys.argv[1];assert kind in ['cpu','visible']
dense=['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']
with Counters() as counters:
    for case,extra in [('normal',[]),('dense',dense)]:
        order=['baseline','candidate','candidate','baseline'] if kind=='cpu' else ['baseline','candidate']
        for n,variant in enumerate(order):
            directory=work/('inline-'+kind)/f'{case}-{n}-{variant}';directory.mkdir(parents=True)
            binary=work/'baseline'/('fixture' if kind=='cpu' else 'rbirds') if variant=='baseline' else work/'prototype/target/release'/('examples/fixed-scene' if kind=='cpu' else 'rbirds')
            title=f'rbirds-perf-wezterm-{kind}-{case}'
            job={'kind':kind,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
              'command':[str(binary),'--seed','42','--frames','780' if kind=='cpu' else '1200','--render','sixel',*extra]}
            save(directory/'job.json',job)
            assert not(work/'child.json').exists() and not(work/'job.json').exists()
            save(work/'job.json',{'title':title,'command':['/usr/bin/python3',str(Path(__file__).resolve()),'child',str(directory)],'completed':str(directory/'completed.json')})
            time.sleep(.3)
            subprocess.run(['osascript','-e',f'tell application "System Events" to tell (first application process whose unix id is {pid})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{title}")\nend tell'],check=True,stdout=subprocess.DEVNULL)
            print(kind,case,variant,n,'started',flush=True)
            started=time.monotonic();observations=[];captured=False
            while not(directory/'completed.json').exists():
                elapsed=time.monotonic()-started
                if elapsed>200:raise TimeoutError(directory)
                record={'seconds':elapsed,'memory':counters.snapshot(pid).memory}
                if record['memory']['physical_footprint']>2*1024**3:raise RuntimeError('Memory guard')
                if len(observations)%5==0:
                    record['owner_active']=subprocess.check_output(['osascript','-e',f'tell application "System Events" to get frontmost of (first application process whose unix id is {pid})'],text=True).strip()=='true'
                observations.append(record)
                if kind=='visible' and elapsed>=3 and not captured:
                    subprocess.run([str(root/'target/presentation-capture'),title,str(directory/'presentation.json'),'15'],check=True)
                    capture=json.loads((directory/'presentation.json').read_text())
                    shot=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--window-id',str(capture['window_id']),'--mode','temp'],text=True).strip()
                    shutil.copy2(shot,directory/'screenshot.png');save(directory/'screenshot.json',{'path':shot});captured=True
                time.sleep(1)
            save(directory/'observations.json',observations)
            assert json.loads((directory/'completed.json').read_text())['status']==0
            assert json.loads((directory/'result.json').read_text())['termios_equal']
            assert all(o.get('owner_active',True) for o in observations)
            if kind=='cpu':assert json.loads((directory/'cpu.json').read_text())['measurement_valid']
            print(kind,case,variant,n,'complete',flush=True)
