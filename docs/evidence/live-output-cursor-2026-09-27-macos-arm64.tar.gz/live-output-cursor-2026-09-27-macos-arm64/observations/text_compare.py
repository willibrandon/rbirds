import json
from pathlib import Path
import shlex
import subprocess
import time

root=Path('/Users/brandon/src/rbirds');work=root/'target/live-perf/output-cursor';out=work/'text-compare';out.mkdir()
for variant in ['before','after']:
    name='rbirds-perf-output-cursor-text-'+variant
    binary=work/('before-rbirds' if variant=='before' else 'candidate-rbirds')
    command=shlex.join(['/usr/bin/env','RBIRDS_TRACE='+str(out/(variant+'.jsonl')),
                       '/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),
                       name,str(out/(variant+'-completed.json')),str(binary),'--render','braille','--seed','42','--frames','1200'])
    window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True));print(variant,'window',window,flush=True)
    time.sleep(5)
    subprocess.run([str(root/'target/presentation-capture'),name,str(out/(variant+'-presentation.json')),'10'],check=True)
    for _ in range(100):
        if (out/(variant+'-completed.json')).exists():
            assert json.loads((out/(variant+'-completed.json')).read_text())['status']==0
            break
        time.sleep(.5)
    else:raise RuntimeError('finite command has not completed')
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
    print(variant,'done',flush=True)
