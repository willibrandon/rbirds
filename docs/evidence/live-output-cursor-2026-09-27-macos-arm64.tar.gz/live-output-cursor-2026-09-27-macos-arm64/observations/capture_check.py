import json
from pathlib import Path
import shlex
import subprocess
import time

root=Path('/Users/brandon/src/rbirds');out=root/'target/live-perf/output-cursor/capture-check';out.mkdir()
name='rbirds-perf-capture-pixels'
command=shlex.join(['/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),str(root/'target/live-perf/output-cursor/candidate-rbirds'),'--render','braille','--birds','32','--seed','42','--frames','1800'])
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True));print('window',window,flush=True)
def key(text):
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "{text}" newline NO'],check=True)
time.sleep(5)
subprocess.run([str(root/'target/presentation-capture'),name,str(out/'moving.json'),'5'],check=True)
key(' ');time.sleep(.5)
subprocess.run([str(root/'target/presentation-capture'),name,str(out/'paused.json'),'5'],check=True)
key('q')
for _ in range(100):
    if (out/'completed.json').exists():
        result=json.loads((out/'completed.json').read_text());assert result['status']==0,result
        break
    time.sleep(.2)
else:raise RuntimeError('owned child did not finish')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
summary={}
for scene in ['moving','paused']:
    report=json.loads((out/(scene+'.json')).read_text());frames=report['frames']
    summary[scene]={'samples':len(frames),'full_changes':sum(f['changed'] for f in frames),'sampled_changes':sum(f['sampled_changed'] for f in frames),'missed_by_grid':sum(f['changed'] and not f['sampled_changed'] for f in frames),'inconsistent':sum(not f['changed'] and f['sampled_changed'] for f in frames),'capture_cpu_seconds':report['capture_cpu_seconds']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
assert summary['moving']['inconsistent']==0
assert summary['paused']['full_changes']==1, summary
