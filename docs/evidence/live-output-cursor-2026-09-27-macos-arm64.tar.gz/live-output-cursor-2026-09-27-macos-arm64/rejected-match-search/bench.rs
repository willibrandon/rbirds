use std::{fs,time::Instant};
mod kitty {pub use rbirds::render::kitty::KittyError;}
mod image {pub use rbirds::image::Image;}
mod baseline;
mod frame_codes;
mod probe2;
mod probe4;
mod probe8;
fn main(){
 let dir=std::env::args().nth(1).unwrap();let out=std::env::args().nth(2).unwrap();
 let mut a=baseline::PixelRuns::default();let mut b=probe2::PixelRuns::default();let mut c=probe4::PixelRuns::default();let mut d=probe8::PixelRuns::default();
 let mut paths:Vec<_>=fs::read_dir(&dir).unwrap().map(|r|r.unwrap().path()).filter(|p|p.extension().is_some_and(|e|e=="rgba")).collect();paths.sort();
 for path in paths {
  let name=path.file_name().unwrap().to_str().unwrap();let dims=name.split('.').nth(1).unwrap();let (w,h)=dims.split_once('x').unwrap();let (width,height):(usize,usize)=(w.parse().unwrap(),h.parse().unwrap());let image=image::Image{width:width as i32,height:height as i32,pixels:fs::read(&path).unwrap()};
  let mut timings:[Vec<f64>;4]=Default::default();let mut sizes=[0;4];
  for cycle in 0..16 { for step in 0..4 {
   let which=if cycle%2==0 {step} else {3-step};let start=Instant::now();
   let bytes=match which {0=>a.encode_region(&image,0,0,width,height),1=>b.encode_region(&image,0,0,width,height),2=>c.encode_region(&image,0,0,width,height),_=>d.encode_region(&image,0,0,width,height)}.unwrap();
   sizes[which]=std::hint::black_box(bytes.len());let elapsed=start.elapsed().as_secs_f64()*1000.;if cycle>0 {timings[which].push(elapsed);}
   if cycle==15 {fs::write(format!("{out}/{name}.{which}.zlib"),bytes).unwrap();}
  }}
  for t in &mut timings {t.sort_by(f64::total_cmp);}
  println!("{name} {:?} {:?}",sizes,timings.each_ref().map(|t|t[t.len()/2]));
 }
}
