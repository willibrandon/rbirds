from pathlib import Path
p=Path(__file__).parent
source=(p/'baseline.rs').read_text()
start=source.index('                        let (prior, source) = self.positions[slot];')
end=source.index('\n                    }\n                    self.tokens.push', start)
replacement='''                        let candidates = self.positions[slot];
                        self.positions[slot].copy_within(0..DEPTH-1, 1);
                        self.positions[slot][0] = (logical, start + at);
                        let mut best_length = 0;
                        let mut best_distance = 0;
                        for (prior, source) in candidates {
                            if prior >= logical || logical - prior > 32768 { continue; }
                            let source_left = source % (iw * 4);
                            let limit = 256.min(row.len() - at).min((left + width) * 4 - source_left);
                            if limit <= best_length || limit < 8 { continue; }
                            if image.pixels[source..source+8] != row[at..at+8] { continue; }
                            let mut length = 8;
                            while length < limit && image.pixels[source+length..source+length+4] == row[at+length..at+length+4] {
                                length += 4;
                            }
                            if length > best_length {
                                best_length = length;
                                best_distance = logical-prior;
                                if length == 256 { break; }
                            }
                        }
                        if best_length >= 8 {
                            self.run(best_length, best_distance);
                            previous = Some(row[at+best_length-4..at+best_length].try_into().unwrap());
                            at += best_length;
                            continue;
                        }'''
for depth in (2,4,8):
    s=source[:start]+replacement+source[end:]
    s=s.replace('positions: Vec<(usize, usize)>',f'positions: Vec<[(usize, usize); {depth}]>')
    s=s.replace('(SLOTS, (usize::MAX, 0))',f'(SLOTS, [(usize::MAX, 0); {depth}])')
    s=s.replace('.fill((usize::MAX, 0))',f'.fill([(usize::MAX, 0); {depth}])')
    s=s.replace('const SLOTS: usize = 16384;',f'const SLOTS: usize = 16384; const DEPTH: usize = {depth};')
    (p/f'probe{depth}.rs').write_text(s)
