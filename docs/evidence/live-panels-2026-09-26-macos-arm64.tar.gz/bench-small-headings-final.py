import json,re,statistics,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'small-headings-final';out.mkdir(exist_ok=True)
data=[]
for birds in [1,8,32,128]:
 args=['--render','kitty','--birds',str(birds),'--bench','30000','--seed','42']
 for side in ['before','after','after','before','before','after','after','before']:
  binary=root/('paired-trig-rbirds' if side=='before' else 'legend-delta-final-rbirds')
  raw=subprocess.check_output([str(binary),*args],text=True)
  fps=float(re.search(r'ceiling\s+(\S+)',raw)[1])
  data.append({'birds':birds,'variant':side,'command':args,'stdout':raw,'us_per_frame_from_rounded_ceiling':1e6/fps})
  (out/'bench.json').write_text(json.dumps(data,indent=2))
 med={s:statistics.median(x['us_per_frame_from_rounded_ceiling'] for x in data if x['birds']==birds and x['variant']==s) for s in ['before','after']}
 print(birds,med,'ratio',med['after']/med['before'],flush=True)
