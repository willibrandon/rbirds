import json, re, subprocess, statistics, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds/target/live-perf')
out=root/'cached-headings';out.mkdir(exist_ok=True)
variants={'before':root/'paired-trig-rbirds','after':root/'cached-headings-rbirds'}
results=[]
for mode,args in [('kitty',[]),('kitty-busy',['--trails','--depth','--hawks','4','--flocks','3','--speed','12']),('kitty-crowded',['--birds','4096']),('braille',[])]:
    command=['--render',mode.split('-')[0],'--bench',('300' if 'crowded' in mode else '1500'),'--seed','42',*args]
    for binary in variants.values():subprocess.run([str(binary),*command],stdout=subprocess.DEVNULL,check=True)
    for side in ['before','after','after','before','before','after','after','before']:
        start=time.monotonic(); raw=subprocess.check_output([str(variants[side]),*command],text=True)
        row={'mode':mode,'variant':side,'command':command,'wall':time.monotonic()-start,'stdout':raw}
        row['ms']=float(re.search(r'frame time\s+(\S+)',raw)[1]);row['bytes']=re.search(r'bytes/frame\s+(\S+)',raw)[1]
        results.append(row)
        (out/'bench.json').write_text(json.dumps(results,indent=2))
    items=[r for r in results if r['mode']==mode]
    assert len({r['bytes'] for r in items})==1
    med={side:statistics.median(r['ms'] for r in items if r['variant']==side) for side in variants}
    print(mode,med,'ratio',med['after']/med['before'],flush=True)
