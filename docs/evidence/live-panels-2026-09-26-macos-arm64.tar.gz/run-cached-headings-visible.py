import json
from pathlib import Path
import subprocess

root = Path('/Users/brandon/src/rbirds')
out = root / 'target/live-perf/cached-headings-visible'
out.mkdir(exist_ok=True)
for mode in ['default', 'kitty']:
    for variant, repeat in [('current', 1), ('candidate', 1), ('candidate', 2), ('current', 2)]:
        name = f'{mode}-{variant}-{repeat}'
        binary = root / 'target/live-perf' / {'baseline': 'baseline/rbirds', 'current': 'paired-trig-rbirds', 'candidate': 'cached-headings-rbirds'}[variant]
        render = [] if mode == 'default' else ['--render', mode]
        cmd = ['open', '-W', '-n', '-a', 'kitty', '--args', '--config', 'NONE',
               '--title', 'rbirds-perf-' + name,
               '--override', 'initial_window_width=800', '--override', 'initial_window_height=500',
               '--override', 'remember_window_size=no', '--override', 'macos_quit_when_last_window_closed=yes',
               '/usr/bin/env', 'RBIRDS_TRACE=' + str(out / (name + '.jsonl')),
               '/opt/homebrew/bin/python3', str(root / 'tools/terminal-perf.py'),
               '--warmup-seconds', '3', '--sample-seconds', '30', '--output', str(out / (name + '.json')), '--note',
               'Visible Kitty 0.44.0; UFC off; no capture; 800x500 logical window',
               '--', str(binary), *render, '--seed', '42', '--frames', '2400']
        subprocess.run(cmd, check=True, timeout=90)
        data = json.loads((out / (name + '.json')).read_text())
        print(name, {k: data[k] for k in ['wall_seconds', 'interval_sample']}, flush=True)
