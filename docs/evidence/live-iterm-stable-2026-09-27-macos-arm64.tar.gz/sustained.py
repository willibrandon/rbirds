import json,subprocess,sys,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from process_usage import Counters
owned=json.loads((work/'owned-window.json').read_text());pid=owned['pid'];window=owned['window'];app=str(work/'unpacked/iTerm.app')
def tell(script):
    subprocess.run(['osascript','-e',f'tell application "{app}" to tell current session of (first window whose id is {window})\n'+script+'\nend tell'],check=True)
def focus():
    return subprocess.check_output(['osascript','-e',f'tell application "System Events" to get frontmost of (first application process whose unix id is {pid})'],text=True).strip()=='true'
with Counters() as counters:
    for scene,extra in [('default',[]),('dense',['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember'])]:
        out=work/'sustained'/scene;out.mkdir(parents=True);name='rbirds-perf-stable-long-'+scene
        request={'title':name,'completed':str(out/'completed.json'),'command':['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(out/'cpu.json'),'--trace',str(out/'trace.jsonl'),'--terminal-pid',str(pid),'--warmup-seconds','5','--sample-seconds','15','--sample-count','6','--sample-gap-seconds','15','--note','iTerm 3.7.3, isolated suite, one owned 100x32/1400x1088 window, original dark colors/fonts copied; no builds/tests/capture/profiling; native memory guard 1Hz and app focus observations ~5s; UFC off.','--',str(root/'target/release/rbirds'),'--render','kitty','--seed','42','--frames','36000',*extra]}
        (out/'job.json').write_text(json.dumps(request,indent=2)+'\n');temp=work/'job.tmp';temp.write_text(json.dumps(request));temp.replace(work/'job.json')
        time.sleep(.5)
        subprocess.run(['osascript','-e',f'tell application "System Events" to tell (first application process whose unix id is {pid})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{name}")\nend tell'],check=True)
        start=time.monotonic();observations=[];initial=counters.snapshot(pid);limit=min(initial.memory['physical_footprint']+1.2*1024**3,2*1024**3)
        print(scene,'started',flush=True)
        try:
            while time.monotonic()-start<172:
                current=counters.snapshot(pid);assert current.identity==initial.identity and current.alive
                sample={'elapsed':time.monotonic()-start,'memory':current.memory}
                if len(observations)%5==0:sample['owner_active']=focus()
                observations.append(sample);(out/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
                if current.memory['physical_footprint']>limit:
                    (out/'stopped-for-memory.txt').write_text(str(current.memory)+'\n');break
                if (out/'completed.json').exists():break
                time.sleep(1)
        finally:tell('write text "q" newline NO')
        for _ in range(120):
            if (out/'completed.json').exists():
                result=json.loads((out/'completed.json').read_text());assert result['status']==0,result;break
            time.sleep(.5)
        else:raise RuntimeError('Owned command did not complete')
        report=json.loads((out/'cpu.json').read_text());assert report['measurement_valid'],report
        print(scene,'complete',len(observations),'observations',max(o['memory']['physical_footprint'] for o in observations)/1024**2,'max MiB',flush=True)
