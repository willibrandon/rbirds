import json, os, subprocess, sys, time
from pathlib import Path
out = Path(sys.argv[1]); name = sys.argv[2]
assert name.startswith('rbirds-perf-')
os.write(1, ('\x1b]0;' + name + '\x07').encode())
time.sleep(2)
child = subprocess.Popen(sys.argv[3:], stderr=subprocess.PIPE)
(out / 'running.json').write_text(json.dumps({'pid': child.pid, 'parent': os.getpid(), 'command': sys.argv[3:]}) + '\n')
_, err = child.communicate()
temp = out / 'completed.tmp'
temp.write_text(json.dumps({'status': child.returncode, 'stderr': err.decode(errors='replace')}) + '\n')
temp.replace(out / 'completed.json')
