import json, shlex, shutil, signal, subprocess, sys, time
from pathlib import Path
root = Path('/Users/brandon/src/rbirds'); work = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'tools'))
from process_usage import Counters
scene = sys.argv[1]; assert scene in ['default', 'dense']
out = work / 'visible' / scene; out.mkdir(parents=True)
name = 'rbirds-perf-legacy-atlas-' + scene
extra = [] if scene == 'default' else ['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']
binary = str(work / 'build/release/rbirds')
command = ['/usr/bin/python3', str(work/'owned-command.py'), str(out), name, '/usr/bin/env', 'RBIRDS_TRACE='+str(out/'trace.jsonl'), binary, '--render','kitty','--seed','42','--frames','7200',*extra]
(out/'command.json').write_text(json.dumps(command, indent=2)+'\n')
window = int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),shlex.join(command),name],text=True))
(out/'window.txt').write_text(str(window)+'\n')
print('owned window',window,flush=True)
def tell(text):
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window})\n{text}\nend tell'],check=True)
capture = None
observations=[]
with Counters() as counters:
    initial = counters.snapshot(73499); limit = min(initial.memory['physical_footprint'] + 700*2**20, 2*2**30)
    try:
        time.sleep(5)
        capture = subprocess.Popen([str(root/'target/presentation-capture'), name, str(out/'presentation.json'), '10'])
        while capture.poll() is None:
            snapshot = counters.snapshot(73499); assert snapshot.identity == initial.identity
            observations.append({'time':time.monotonic(),'memory':snapshot.memory})
            if snapshot.memory['physical_footprint'] > limit:raise RuntimeError('Memory guard reached')
            time.sleep(1)
        assert capture.returncode == 0
        shot=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
        (out/'screenshot-path.txt').write_text(shot+'\n');shutil.copy2(shot,out/'screenshot.png');print(shot,flush=True)
    finally:
        if capture is not None and capture.poll() is None:capture.terminate();capture.wait(timeout=10)
        (out/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
        tell('write text "q" newline NO')
        for _ in range(40):
            if (out/'completed.json').exists():break
            time.sleep(.5)
        else:
            running=json.loads((out/'running.json').read_text());pid=running['pid']
            actual=subprocess.check_output(['ps','-p',str(pid),'-o','comm='],text=True).strip()
            assert actual==binary
            subprocess.run(['kill','-TERM',str(pid)],check=True)
            for _ in range(20):
                if (out/'completed.json').exists():break
                time.sleep(.5)
        assert (out/'completed.json').exists(),'Retaining owned window because child has not exited'
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
        print((out/'completed.json').read_text(),flush=True)
