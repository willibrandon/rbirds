import json, shutil, subprocess, sys, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from process_usage import Counters
owned=json.loads((work/'owned-window.json').read_text());app=str(work/'unpacked/iTerm.app')
def action(script):
    subprocess.run(['osascript','-e',f'tell application "{app}" to tell current session of (first window whose id is {owned["window"]})\n{script}\nend tell'],check=True)
def focus(name):
    subprocess.run(['osascript','-e',f'tell application "System Events" to tell (first application process whose unix id is {owned["pid"]})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{name}")\nend tell'],check=True)
with Counters() as counters:
    for scene,backend,extra in [('braille','braille',[]),('sixel-default','sixel',[]),('sixel-dense','sixel',['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember'])]:
        out=work/'other-backends'/scene;out.mkdir(parents=True);name='rbirds-perf-stable-'+scene
        job={'title':name,'completed':str(out/'completed.json'),'command':['/usr/bin/env','RBIRDS_TRACE='+str(out/'trace.jsonl'),str(root/'target/release/rbirds'),'--render',backend,'--seed','42','--frames','7200',*extra]}
        (out/'job.json').write_text(json.dumps(job,indent=2)+'\n');temp=work/'job.tmp';temp.write_text(json.dumps(job));temp.replace(work/'job.json');started=time.monotonic();memory=[];capture=None
        try:
            for label,delay in ([('early',3),('later',43)] if scene=='braille' else [('scene',3)]):
                remaining=delay-(time.monotonic()-started)
                if remaining>0:time.sleep(remaining)
                focus(name)
                capture=subprocess.Popen([str(root/'target/presentation-capture'),name,str(out/(label+'-presentation.json')),'15'])
                while capture.poll() is None:
                    snap=counters.snapshot(owned['pid']);memory.append({'seconds':time.monotonic()-started,'memory':snap.memory})
                    if snap.memory['physical_footprint']>2*1024**3:raise RuntimeError('two-GiB memory guard')
                    time.sleep(1)
                assert capture.returncode==0
                screenshot=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
                (out/(label+'-screenshot.txt')).write_text(screenshot+'\n');shutil.copy2(screenshot,out/(label+'.png'));print(scene,label,screenshot,flush=True)
        finally:
            if capture is not None and capture.poll() is None:capture.terminate();capture.wait(timeout=10)
            action('write text "q" newline NO');(out/'memory.json').write_text(json.dumps(memory,indent=2)+'\n')
        for _ in range(120):
            if (out/'completed.json').exists():
                result=json.loads((out/'completed.json').read_text());assert result['status']==0,result;break
            time.sleep(.5)
        else:raise RuntimeError('Owned command did not complete')
