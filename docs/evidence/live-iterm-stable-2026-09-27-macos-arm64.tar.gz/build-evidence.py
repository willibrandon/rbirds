import hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
work=Path(__file__).resolve().parent;root=work.parents[2];stage=work/'evidence';stage.mkdir()
for name in ['analyze.py','build-evidence.py','session.py','visible.py','sustained.py','qualify.py','other-backends.py','cleanup.py','cleanup.json','download.json','setup.json','test-preferences.plist','session.json','app-process.json','owned-window.json','local-validation.json','visible-summary.json','sustained-summary.json','other-backends-summary.json']:
    shutil.copy2(work/name,stage/name)
for name in ['visible','sustained','qualification','other-backends','old-version-check']:
    shutil.copytree(work/name,stage/name)
legacy=work.parent/'kitty-legacy-atlas';dst=stage/'rejected-atlas';dst.mkdir()
for name in ['summary.json','live.rs.patch','render-kitty.rs.patch','owned-command.py','run-visible.py']:
    shutil.copy2(legacy/name,dst/name)
shutil.copytree(legacy/'visible',dst/'visible')
sources=stage/'sources';sources.mkdir()
shutil.copy2(legacy/'v3.7.3-KittyImageRenderer.swift',sources/'v3.7.3-KittyImageRenderer.swift')
for name in ['show-scene.py','static-after.bin']:
    shutil.copy2(work.parent/'iterm-kitty-frame'/name,sources/name)
for name in ['presentation-capture.swift','process_usage.py','terminal-perf.py']:
    shutil.copy2(root/'tools'/name,sources/name)
(stage/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/live.rs','src/terminal.rs','tests/pty_kitty_raster.rs'],cwd=root))
manifest={str(p.relative_to(stage)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(stage.rglob('*')) if p.is_file()}
assert not any('private-user' in name or name.endswith('.zip') for name in manifest)
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root/'docs/evidence/live-iterm-stable-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name in [*manifest,'manifest.json']:tar.add(stage/name,arcname=name)
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(manifest)|{'manifest.json'}
    for name,expected in manifest.items():
        data=tar.extractfile(name).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':len(manifest),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
