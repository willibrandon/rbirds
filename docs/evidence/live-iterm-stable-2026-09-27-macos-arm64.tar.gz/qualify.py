import json, shutil, subprocess, time
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent
owned = json.loads((work / 'owned-window.json').read_text())
app = str(work / 'unpacked/iTerm.app')
out = work / 'qualification'
out.mkdir()

def action(script):
    subprocess.run(['osascript', '-e', f'tell application "{app}" to tell current session of (first window whose id is {owned["window"]})\n{script}\nend tell'], check=True)

def start(label, command):
    name = 'rbirds-perf-stable-' + label
    job = {'title': name, 'completed': str(out / (label + '-completed.json')), 'command': command}
    (out / (label + '-job.json')).write_text(json.dumps(job, indent=2) + '\n')
    temp = work / 'job.tmp'
    temp.write_text(json.dumps(job))
    temp.replace(work / 'job.json')
    time.sleep(1)
    subprocess.run(['osascript', '-e', f'tell application "System Events" to tell (first application process whose unix id is {owned["pid"]})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{name}")\nend tell'], check=True)
    return name

def completed(label):
    for _ in range(30):
        p = out / (label + '-completed.json')
        if p.exists():
            result = json.loads(p.read_text())
            assert result['status'] == 0, result
            return
        time.sleep(.5)
    raise RuntimeError('Owned command did not complete')

def shot(name, label):
    path = subprocess.check_output(['/usr/bin/python3', '/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py', '--app', 'iTerm2', '--window-name', name, '--mode', 'temp'], text=True).strip()
    (out / (label + '-screenshot.txt')).write_text(path + '\n')
    shutil.copy2(path, out / (label + '.png'))
    print(label, path, flush=True)

name = start('static', ['/usr/bin/python3', str(root / 'target/live-perf/iterm-kitty-frame/show-scene.py'), str(root / 'target/live-perf/iterm-kitty-frame/static-after.bin')])
time.sleep(1)
shot(name, 'static')
completed('static')

name = start('events', ['/usr/bin/env', 'RBIRDS_TRACE=' + str(out / 'events-trace.jsonl'), str(root / 'target/release/rbirds'), '--render', 'kitty', '--seed', '42', '--frames', '7200', '--panel', '--trails', '--depth', '--hawks', '4', '--flocks', '3', '--color', 'ember'])
events = []
started = time.monotonic()
def event(script):
    action(script)
    events.append({'action': script, 'seconds_after_start': time.monotonic() - started})

try:
    time.sleep(2)
    event('write text " " newline NO')
    time.sleep(1)
    shot(name, 'paused')
    subprocess.run([str(root / 'target/presentation-capture'), name, str(out / 'paused-presentation.json'), '3'], check=True)
    capture = subprocess.Popen([str(root / 'target/presentation-capture'), name, str(out / 'events-presentation.json'), '19'])
    for script in ['write text "." newline NO', 'write text "h" newline NO', 'set columns to 120\nset rows to 36', 'write text "h" newline NO', 'write text " " newline NO']:
        time.sleep(3)
        event(script)
    assert capture.wait(timeout=15) == 0
    shot(name, 'resumed')
finally:
    action('write text "q" newline NO')
    (out / 'events.json').write_text(json.dumps(events, indent=2) + '\n')
completed('events')
action('set columns to 100\nset rows to 32')
