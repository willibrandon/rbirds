import json, plistlib, subprocess, time
from pathlib import Path
work=Path(__file__).resolve().parent;owned=json.loads((work/'owned-window.json').read_text());pid=owned['pid'];app=str(work/'unpacked/iTerm.app')
assert not (work/'job.json').exists()
assert subprocess.check_output(['ps','-p',str(pid),'-o','comm='],text=True).strip()==app+'/Contents/MacOS/iTerm2'
(work/'stop-session').touch();time.sleep(.5)
subprocess.run(['osascript','-e',f'tell application "{app}" to quit'],check=True)
for _ in range(20):
    process=subprocess.run(['ps','-p',str(pid),'-o','comm='],capture_output=True,text=True)
    if process.returncode!=0:break
    time.sleep(.5)
assert process.returncode!=0,'Owned app did not exit'
before=plistlib.loads((work/'private-user-defaults-before.plist').read_bytes())
after=plistlib.loads(subprocess.check_output(['defaults','export','com.googlecode.iterm2','-']))
guid=json.loads((work/'setup.json').read_text())['guid'];prefix=f'NSWindow Frame iTerm Profile {guid} '
removed=[]
for key in after.keys()-before.keys():
    if key.startswith(prefix):
        subprocess.run(['defaults','delete','com.googlecode.iterm2',key],check=True);removed.append(key)
after=plistlib.loads(subprocess.check_output(['defaults','export','com.googlecode.iterm2','-']))
changed=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
report={'owned_pid':pid,'owned_app_exited':True,'removed_owned_autosave_keys':removed,'original_preferences_changed_keys':changed,'original_app':subprocess.check_output(['ps','-p','73499','-o','pid=,comm='],text=True).strip()}
(work/'cleanup.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
