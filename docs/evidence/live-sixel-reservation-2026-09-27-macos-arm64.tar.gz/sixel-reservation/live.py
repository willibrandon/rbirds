import json, shutil, subprocess, sys, time
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent
owned = json.loads((work/'owned-window.json').read_text())
app = json.loads((work/'setup.json').read_text())['app']
sys.path.insert(0, str(root/'tools'))
from process_usage import Counters

def action(script):
    subprocess.run(['osascript','-e',f'tell application "{app}" to tell current session of (first window whose id is {owned["window"]})\n{script}\nend tell'],check=True)

def start(out, name, command):
    out.mkdir(parents=True)
    job={'title':name,'completed':str(out/'completed.json'),'command':command}
    (out/'job.json').write_text(json.dumps(job,indent=2)+'\n')
    temp=work/'job.tmp';temp.write_text(json.dumps(job));temp.replace(work/'job.json')
    time.sleep(.5)
    subprocess.run(['osascript','-e',f'tell application "System Events" to tell (first application process whose unix id is {owned["pid"]})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{name}")\nend tell'],check=True)

def completed(out):
    for _ in range(60):
        if (out/'completed.json').exists():
            result=json.loads((out/'completed.json').read_text());assert result['status']==0,result;return
        time.sleep(.5)
    raise RuntimeError('Owned command did not complete')

def shot(out,name):
    path=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
    shutil.copy2(path,out/'screenshot.png');print('screenshot',out/'screenshot.png',flush=True)

def main():
    mode=sys.argv[1]
    if mode=='static':
        for scene in ['default','dense']:
            for side in ['before','after']:
                out=work/'static'/f'{scene}-{side}';name='rbirds-perf-sixel-runs-static'
                start(out,name,['/usr/bin/python3',str(root/'target/live-perf/iterm-kitty-frame/show-scene.py'),str(work/f'{scene}-{side}.frame')])
                time.sleep(1);shot(out,name);completed(out)
        return
    dense=['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']
    scenes=[('sixel','sixel',[]),('dense-sixel','sixel',dense),('sparse-sixel','sixel',['--birds','32'])]
    if len(sys.argv)>2:
        scenes=[scene for scene in scenes if scene[0] in sys.argv[2:]]
        assert len(scenes)==len(sys.argv)-2
    with Counters() as counters:
        for scene,backend,extra in scenes:
            for index,side in enumerate(['before','after','after','before'] if mode=='cpu' else ['before','after']):
                out=work/mode/f'{scene}-{index}-{side}';name=f'rbirds-perf-sixel-runs-{scene}-{side}'
                command=[str(work/(side+'-rbirds')),'--render',backend,'--seed','42','--frames','7200',*extra]
                if mode=='cpu':
                    command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(out/'cpu.json'),'--trace',str(out/'trace.jsonl'),'--terminal-pid',str(owned['pid']),'--helper-pid',str(owned['helper']),'--warmup-seconds','3','--sample-seconds','15','--note','iTerm 3.7.3 isolated suite; 100x32/1400x1088; ABBA; foreground; UFC off; no capture/build/tests/profiling; memory guard 1Hz and app focus every 5 seconds; terminal main process and its Sixel decoder helper.','--',*command]
                else:command=['/usr/bin/env','RBIRDS_TRACE='+str(out/'trace.jsonl'),*command]
                start(out,name,command);print(mode,scene,index,side,'started',flush=True)
                started=time.monotonic();observations=[];capture=None
                try:
                    if mode=='visible':
                        time.sleep(2.5);capture=subprocess.Popen([str(root/'target/presentation-capture'),name,str(out/'presentation.json'),'15'])
                    while (capture.poll() is None if capture else time.monotonic()-started<21):
                        snap=counters.snapshot(owned['pid']);sample={'seconds':time.monotonic()-started,'memory':snap.memory}
                        if len(observations)%5==0:
                            sample['owner_active']=subprocess.check_output(['osascript','-e',f'tell application "System Events" to get frontmost of (first application process whose unix id is {owned["pid"]})'],text=True).strip()=='true'
                        observations.append(sample)
                        if snap.memory['physical_footprint']>2*1024**3:raise RuntimeError('two GiB memory guard')
                        time.sleep(1)
                    if capture:
                        assert capture.returncode==0;shot(out,name)
                finally:
                    if capture and capture.poll() is None:capture.terminate();capture.wait(timeout=10)
                    action('write text "q" newline NO');(out/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
                completed(out)
                if mode=='cpu':assert json.loads((out/'cpu.json').read_text())['measurement_valid']
                print(mode,scene,index,side,'complete',flush=True)

if __name__=='__main__':main()
