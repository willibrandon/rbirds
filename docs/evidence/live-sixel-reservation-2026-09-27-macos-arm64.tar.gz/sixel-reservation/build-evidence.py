import hashlib, json, shutil, tarfile
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent
stage = work / 'evidence'
stage.mkdir()
names = [
    'binaries.json', 'setup.json', 'owned-window.json', 'app-process.json',
    'session.json', 'cleanup.json', 'before-sixel.rs', 'candidate-sixel.rs',
    'measured-sixel.rs', 'rejected-batched-candidate-sixel.rs', 'prototype.patch',
    'probe.rs', 'probe.csv', 'rejected-batched-probe.csv', 'codec-summary.json',
    'bench.py', 'bench.json', 'bench.log', 'setup.py', 'live.py', 'session.py',
    'cleanup.py', 'analyze.py', 'build-evidence.py',
    'cpu-summary.json', 'cpu-intervals.json', 'visible-summary.json',
    'phase-summary.json', 'native-debug.log', 'native-release.log',
    'rosetta-release.log', 'clippy.log', 'retained-native-debug.log',
    'retained-native-release.log', 'retained-rosetta-release.log',
]
names += [str(p.relative_to(work))
          for directory in ['cpu', 'visible']
          for p in (work / directory).rglob('*')
          if p.is_file() and p.suffix in ['.json', '.jsonl', '.png']]
assert len(names) == len(set(names))
for name in names:
    dst = stage / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(work / name, dst)
for name in ['src/render/sixel.rs', 'tests/allocation_failure.rs',
             'tools/terminal-perf.py', 'tools/process_usage.py',
             'tools/measurement_clock.py', 'tools/trace_alignment.py',
             'tools/presentation-capture.swift']:
    dst = stage / 'source' / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, dst)
manifest = {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(stage.rglob('*')) if p.is_file()}
(stage / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'docs/evidence/live-sixel-reservation-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(stage, arcname='sixel-reservation')
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        assert hashlib.sha256(tar.extractfile('sixel-reservation/' + name).read()).hexdigest() == expected, name
report = {'files': len(manifest), 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(work / 'archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(report)
