"""Summarize the two retained foreground iTerm captures (stdlib only)."""
import collections, json, math
from pathlib import Path
work = Path(__file__).resolve().parent
out = {}
for name in ['iterm-current-confirmation', 'iterm-palette-confirmation']:
    directory = work / name
    if not directory.exists(): directory = work.parent / name
    capture = json.loads((directory / 'candidate-presentation.json').read_text())
    frames = capture['frames']
    times = [frame['pts'] for frame in frames if frame['changed']]
    gaps = sorted((b-a)*1000 for a,b in zip(times,times[1:]))
    out[name] = {
        'samples': len(frames),
        'dominant': collections.Counter(str(frame['dominant_rgb']) for frame in frames),
        'changed_hz': (len(times)-1)/(times[-1]-times[0]),
        'p99_gap_ms': gaps[math.ceil(len(gaps)*.99)-1], 'max_gap_ms': max(gaps),
        'focus_samples': len(capture['focus_observations']),
        'focus': all(f['owner_active'] and f['top_normal_window'] for f in capture['focus_observations']),
        'completed': json.loads((directory / 'candidate-completed.json').read_text())}
    assert out[name]['focus'] and out[name]['completed']['status'] == 0
    assert all(frame['dominant_rgb'] == [18,18,23] for frame in frames)
(work / 'iterm-confirmation-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
