local wezterm = require 'wezterm'
wezterm.on('format-window-title', function(tab) return tab.active_pane.title end)
return {
  initial_cols = 100,
  initial_rows = 32,
  font = wezterm.font('Monaco'),
  font_size = 12,
  colors = { background = '#121217', foreground = '#e6e6e6' },
  window_padding = { left = 0, right = 0, top = 0, bottom = 0 },
  enable_tab_bar = false,
  check_for_updates = false,
  automatically_reload_config = false,
  window_close_confirmation = 'NeverPrompt',
  audible_bell = 'Disabled',
}
