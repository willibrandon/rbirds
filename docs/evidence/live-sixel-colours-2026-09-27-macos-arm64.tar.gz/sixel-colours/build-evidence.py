import hashlib, json, shutil, tarfile
from pathlib import Path
root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent
stage = work / 'evidence'
stage.mkdir()
names = ['probe.rs', 'static.py', 'static-fixed.py', 'setup.py', 'session.py', 'config.lua',
         'caps.py', 'caps-after-sync.py', 'caps-first.json', 'capabilities.json',
         'caps-completed.json', 'caps-second-completed.json', 'launch.json', 'session.json',
         'compare.py', 'analyze-iterm.py', 'build-evidence.py', 'environment.json',
         'pixel-comparison.json', 'iterm-confirmation-summary.json', 'red-test.log',
         'tests.log', 'release-tests.log', 'rosetta-tests.log', 'build.log', 'clippy.log']
names += [str(p.relative_to(work)) for folder in ['static', 'static-fixed', 'static-initial-capture-error']
          for p in sorted((work/folder).rglob('*'))
          if p.is_file() and p.suffix in ['.bin', '.png', '.json', '.txt']]
for name in names:
    dest=stage/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(work/name,dest)
for name in ['iterm-current-confirmation', 'iterm-palette-confirmation']:
    shutil.copytree(work.parent/name, stage/name)
for name in ['src/render/sixel.rs', 'tests/sixel.rs', 'src/render/compose.rs',
             'src/terminal.rs', 'tools/presentation-capture.swift',
             'target/live-perf/completion-exec.py', 'target/live-perf/run-iterm.scpt']:
    dest=stage/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,dest)
manifest={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root/'docs/evidence/live-sixel-colours-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(stage,arcname='sixel-colours')
with tarfile.open(archive,'r:gz') as tar:
    for name,expected in manifest.items():
        assert hashlib.sha256(tar.extractfile('sixel-colours/'+name).read()).hexdigest()==expected,name
result={'files':len(manifest),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(work/'archive.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
