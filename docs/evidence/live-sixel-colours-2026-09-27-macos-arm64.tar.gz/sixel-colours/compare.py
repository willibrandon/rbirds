"""Compare captured Sixel pixels against an independent RGB-percent decoder."""
import json, re
from pathlib import Path
import numpy as np
from PIL import Image
work = Path(__file__).resolve().parent

def decode(data, definitions_select):
    data = re.search(rb'\x1bP0;1q"1;1;(\d+);(\d+)(.*?)\x1b\\', data, re.S)
    width, height = map(int, data.group(1, 2))
    data = data[3]
    pixels = np.zeros((height, width, 3), dtype=np.uint8)
    covered = np.zeros((height, width), dtype=bool)
    palette = {}
    foreground = (0, 255, 0)
    x = y = at = 0
    def number():
        nonlocal at
        match = re.match(rb'\d+', data[at:])
        assert match
        at += match.end()
        return int(match[0])
    while at < len(data):
        ch = data[at]; at += 1
        if ch == 35:
            colour = number()
            if at < len(data) and data[at] == 59:
                at += 1
                assert number() == 2
                channels = []
                for _ in range(3):
                    assert data[at] == 59; at += 1
                    channels.append(number() * 255 // 100)
                palette[colour] = tuple(channels)
                if definitions_select: foreground = palette[colour]
            else: foreground = palette[colour]
        elif ch == 36: x = 0
        elif ch == 45: x = 0; y += 6
        else:
            count = 1
            if ch == 33:
                count = number(); ch = data[at]; at += 1
            assert 63 <= ch <= 126
            for bit in range(6):
                if (ch - 63) & (1 << bit):
                    assert y + bit < height and x + count <= width
                    pixels[y+bit, x:x+count] = foreground
                    covered[y+bit, x:x+count] = True
            x += count
    assert covered.all()
    return pixels

results = []
for index in [0, 2, 4, 6, 10, 12]:
    before_bytes = (work/'static'/f'{index}.bin').read_bytes()
    after_bytes = (work/'static-fixed'/f'{index}.bin').read_bytes()
    expected = decode(before_bytes, True)
    assert np.array_equal(expected, decode(after_bytes, True))
    assert np.array_equal(expected, decode(after_bytes, False))
    h,w,_ = expected.shape
    # Window captures include a shadow and title bar. Exclude the four-pixel
    # border and the rounded lower corners; retain the first Sixel band.
    mask = np.ones((h,w), dtype=bool)
    mask[:, :4] = False; mask[:, -4:] = False; mask[:2] = False
    mask[-4:] = False; mask[-40:, :40] = False; mask[-40:, -40:] = False
    record = {'index': index, 'compared_pixels': int(mask.sum())}
    for name in ['static', 'static-fixed']:
        shot = np.asarray(Image.open(work/name/f'{index}.png').convert('RGB'))
        raster = shot[132:132+h,112:112+w]
        assert raster.shape == expected.shape
        mismatch = mask & np.any(raster != expected, axis=2)
        record[name+'_mismatches'] = int(mismatch.sum())
        model = decode(before_bytes if name == 'static' else after_bytes, False)
        record[name+'_decoder_model_mismatches'] = int((mask & np.any(raster != model, axis=2)).sum())
        assert record[name+'_decoder_model_mismatches'] == 0
        if name == 'static-fixed': assert not mismatch.any()
        record[name+'_green_pixels'] = int((mask & np.all(raster == [0,255,0],axis=2)).sum())
    results.append(record)
print(json.dumps(results,indent=2))
(work/'pixel-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
