use std::{io::Write, time::{Duration, Instant}};
use rbirds::{platform, terminal::{self, Terminal}, render::{Renderer, kitty::KittyGraphics}, simulation::{Bird, RenderMode, Sim}};
fn main() -> std::io::Result<()> {
    let dir = std::path::PathBuf::from(std::env::args().nth(1).unwrap());
    platform::install_signal_handlers();
    let mut term = Terminal::enter()?;
    let negotiated = terminal::prepare_sixel()?;
    assert!(negotiated.can_position_images);
    term.enter_alt_screen();
    let reply=terminal::terminal_query("\x1b[?2026h\x1b[H\x1b[8m█\x1b[?2026l\x1b[6n".as_bytes(),128,200);
    terminal::write_all(b"\x1b[0m\x1b[2J\x1b[H");
    assert_eq!(reply,b"\x1b[1;2R");
    let mut sim = Sim::new();
    sim.render_mode = RenderMode::Sixel;
    sim.config.birds = 80;
    sim.config.trails = true;
    sim.config.hawks = 2;
    sim.config.flocks = 2;
    sim.config.palette = 1;
    sim.deep_look = true;
    sim.settle_the_bird_size();
    let mut renderer = Renderer::default();
    renderer.prepare_text_renderer(&mut sim, None, b"rbirds").unwrap();
    let mut graphics = KittyGraphics::new(1).unwrap();
    let mut birds = vec![Bird::default(); 80];
    for index in 0..14 {
        let case = index / 2;
        let size = terminal::graphics_window(platform::window_size_or_zero(1), Some(negotiated.cell_size));
        sim.legend_enabled = case == 4;
        sim.apply_screen_size(size.col.into(), size.row.into(), size.xpixel.into(), size.ypixel.into());
        let (x,y) = match case {
            0 | 6 => (370.,360.),
            1 => (f64::from(size.xpixel)-220., f64::from(size.ypixel)-130.),
            2 => (-30.,-20.),
            3 => (10000.,10000.),
            _ => (150.,240.),
        };
        for (i, bird) in birds.iter_mut().enumerate() {
            bird.x=x+(i%10) as f64*28.; bird.y=y+(i/10) as f64*28.;
            bird.frame=(i%32) as i32; bird.layer=(i%2) as i32; bird.shade=(i%2) as i32;
            bird.trail_held=1; bird.trail_at=1; bird.trail_x[0]=bird.x-35.; bird.trail_y[0]=bird.y-25.;
        }
        sim.hawks[0].x=x-20.; sim.hawks[0].y=y;
        sim.hawks[1].x=x+370.; sim.hawks[1].y=y+350.;
        renderer.erase_sixel_before_frame=true;
        renderer.crop_sixel_frames=index%2==1;
        graphics.clear();
        renderer.queue_render_frame(&mut graphics,&sim,&birds).unwrap();
        let bytes=graphics.buffer().to_vec();
        std::fs::write(dir.join(format!("{index}.bin")), &bytes)?;
        std::fs::write(dir.join(format!("{index}-geometry.txt")),format!("{} {} {} {}",size.col,size.row,size.xpixel,size.ypixel))?;
        std::io::stdout().write_all(&bytes)?;
        std::io::stdout().flush()?;
        std::thread::sleep(Duration::from_millis(400));
        std::fs::write(dir.join("ready.tmp"),index.to_string())?;
        std::fs::rename(dir.join("ready.tmp"),dir.join("ready"))?;
        let start=Instant::now();
        while std::fs::read_to_string(dir.join("ack")).ok().as_deref()!=Some(&index.to_string()) {
            assert!(start.elapsed()<Duration::from_secs(30),"capture did not acknowledge");
            std::thread::sleep(Duration::from_millis(20));
        }
    }
    term.restore();
    Ok(())
}
