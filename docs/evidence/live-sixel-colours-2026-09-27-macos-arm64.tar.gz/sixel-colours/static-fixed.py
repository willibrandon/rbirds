import json, shutil, subprocess, time
from pathlib import Path
work = Path(__file__).resolve().parent
output = work / 'static-fixed'
output.mkdir()
pid = json.loads((work / 'session.json').read_text())['terminal_pid']
title = 'rbirds-perf-wezterm-static'
assert not (work / 'child.json').exists()
(work / 'job.json').write_text(json.dumps({'title': title,
    'command': [str(work / 'probe-fixed'), str(output)], 'completed': str(output / 'completed.json')}))
time.sleep(.3)
base = f'tell application "System Events" to tell (first application process whose unix id is {pid})'
subprocess.run(['osascript', '-e', base + f'\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{title}")\nend tell'], check=True)
original = subprocess.check_output(['osascript', '-e', base + '\nget size of first window\nend tell'], text=True).strip()
width, height = map(int, original.split(', '))
for index in range(14):
    deadline = time.monotonic() + 30
    while not (output / 'ready').exists() or (output / 'ready').read_text() != str(index):
        if (output / 'completed.json').exists():
            raise RuntimeError((output / 'stderr.txt').read_text())
        if time.monotonic() > deadline:
            raise TimeoutError(f'frame {index}')
        time.sleep(.05)
    capture = subprocess.check_output(['/usr/bin/python3', '/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py',
        '--app', 'WezTerm', '--window-name', title, '--mode', 'temp'], text=True).strip()
    shutil.copy2(capture, output / f'{index}.png')
    (output / f'{index}-capture.txt').write_text(capture + '\n')
    print('captured', index, capture, flush=True)
    if index in [7, 11]:
        # Physical cells are 14x33 pixels at scale 2; reduce 20 columns and 8 rows.
        size = (width - 140, height - 132) if index == 7 else (width, height)
        subprocess.run(['osascript', '-e', base + f'\nset size of first window to {{{size[0]}, {size[1]}}}\nend tell'], check=True)
        time.sleep(.5)
    (output / 'ack.tmp').write_text(str(index))
    (output / 'ack.tmp').replace(output / 'ack')
deadline = time.monotonic() + 10
while not (output / 'completed.json').exists():
    if time.monotonic() > deadline:
        raise TimeoutError('probe exit')
    time.sleep(.1)
assert json.loads((output / 'completed.json').read_text())['status'] == 0
print('Static probe completed.', flush=True)
