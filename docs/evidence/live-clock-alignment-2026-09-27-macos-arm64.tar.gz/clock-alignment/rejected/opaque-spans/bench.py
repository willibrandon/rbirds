import hashlib,json,re,statistics,subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parent
variants={s:p/(s+'-rbirds') for s in ['before','after']};rows=[]
dense=['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']
for scene,mode,frames,extra in [('default-sixel','sixel',600,[]),('dense-sixel','sixel',400,dense),('text','braille',1000,[])]:
    command=['--render',mode,'--bench',str(frames),'--seed','42',*extra]
    for binary in variants.values():subprocess.run([str(binary),*command],stdout=subprocess.DEVNULL,check=True)
    for side in ['before','after','after','before']:
        start=time.perf_counter();raw=subprocess.check_output([str(variants[side]),*command],text=True)
        row={'scene':scene,'side':side,'command':command,'sha256':hashlib.sha256(variants[side].read_bytes()).hexdigest(),
             'wall_seconds':time.perf_counter()-start,'stdout':raw,'ms':float(re.search(r'frame time\s+(\S+)',raw)[1]),
             'bytes':re.search(r'bytes/frame\s+(\S+)',raw)[1]}
        rows.append(row);(p/'bench.json').write_text(json.dumps(rows,indent=2)+'\n')
    these=[r for r in rows if r['scene']==scene];assert len({r['bytes'] for r in these})==1
    med={side:statistics.median(r['ms'] for r in these if r['side']==side) for side in variants}
    print(scene,med,'ratio',med['after']/med['before'],flush=True)
