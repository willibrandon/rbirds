use rbirds::{simulation::Sim,render::Renderer};
fn main() {
    let mut sim=Sim::new();sim.config.palette=1;sim.settle_the_bird_size();
    let mut renderer=Renderer::default();renderer.prepare_text_renderer(&mut sim,None,b"rbirds").unwrap();
    let mut alpha=[0_u64;256];let(mut rows,mut long,mut pixels)=(0,0,0);
    for image in &renderer.sprites {
        if image.width<=0 {continue;}
        for row in image.pixels.chunks_exact(image.width as usize*4) {
            rows+=1;let(mut run,mut max_run)=(0,0);
            for p in row.chunks_exact(4) {
                alpha[p[3] as usize]+=1;
                if p[3]==255 {run+=1;max_run=max_run.max(run);}else{run=0;}
            }
            if max_run>=8 {long+=1;pixels+=max_run;}
        }
    }
    println!("rows {rows}, rows with opaque spans >=8 {long}, copied pixels {pixels}");
    println!("alpha {:?}",alpha.iter().enumerate().filter(|(_,n)|**n>0).collect::<Vec<_>>());
}
