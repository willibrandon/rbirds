import json
from collections import Counter
from pathlib import Path
p=Path(__file__).resolve().parent
summary={}
for q in sorted(p.glob('*/presentation.json')):
    d=json.loads(q.read_text());frames=d['frames'];t=[r['pts'] for r in frames if r['changed']];g=sorted(1000*(b-a) for a,b in zip(t,t[1:]))
    summary[q.parent.name]={'samples':len(frames),'changed_hz':(len(t)-1)/(t[-1]-t[0]),'p99_gap_ms':g[int(len(g)*.99)],'max_gap_ms':max(g),'gaps_over_50ms':sum(v>50 for v in g),'dominant_colors':dict(Counter(str(r['dominant_rgb']) for r in frames)),'max_dominant_fraction':max(r['dominant_fraction'] for r in frames),'capture_cpu_seconds':d['capture_cpu_seconds'],'requested_seconds':d['requested_seconds']}
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
