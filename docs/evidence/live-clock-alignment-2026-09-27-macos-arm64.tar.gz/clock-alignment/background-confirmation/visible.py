import hashlib,json,shlex,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
binary=root/'target/release/rbirds'
(work/'executable-sha256.txt').write_text(hashlib.sha256(binary.read_bytes()).hexdigest()+'\n')
cases=[('sixel',30,['--render','sixel']),('sixel-dense',15,['--render','sixel','--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']),('kitty',15,['--render','kitty'])]
for case,seconds,extra in cases:
    out=work/case;out.mkdir();name='rbirds-perf-background-'+case
    command=['/usr/bin/env','RBIRDS_TRACE='+str(out/'trace.jsonl'),str(binary),'--seed','42','--frames','7200',*extra]
    wrapped=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),*command])
    start=time.perf_counter();window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapped,name],text=True))
    (out/'window.txt').write_text(str(window)+'\n');print(case,'own window',window,flush=True)
    time.sleep(max(0,start+5-time.perf_counter()))
    subprocess.run([str(root/'target/presentation-capture'),name,str(out/'presentation.json'),str(seconds)],check=True)
    path=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
    (out/'screenshot-path.txt').write_text(path+'\n');shutil.copy2(path,out/'screenshot.png')
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'],check=True)
    for _ in range(120):
        if (out/'completed.json').exists():
            result=json.loads((out/'completed.json').read_text());assert result['status']==0,result;break
        time.sleep(.5)
    else:raise RuntimeError('retain unfinished own window')
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
    print('complete',case,flush=True)
