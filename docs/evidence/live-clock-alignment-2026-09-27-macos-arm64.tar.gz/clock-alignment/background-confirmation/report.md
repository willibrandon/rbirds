Fresh iTerm background confirmation on b804229

The committed release executable hash is b45f29d6df3e26eca9aae7b990d83f7b7a3c324290e0fe0b6af2f4826dc3679d. Seed 42, foreground owned 100x32-cell / 1400x1088-pixel windows, iTerm 3.6.6 on M4 Pro / macOS 26.5.2. No build, tests, or profiling ran during capture. UFC was off. Screenshots inspected; all owned windows closed after successful application exit.

Default Sixel: 30 seconds, 2911 samples, 59.804 visible changes/s, p99 gap 28.537 ms, maximum 37.852 ms. Dense Sixel: 15 seconds, 1390 samples, 50.582 changes/s, p99 35.962 ms, maximum 44.386 ms. Default Kitty: 15 seconds, 1269 samples, 59.974 changes/s, p99 29.823 ms, maximum 37.349 ms. All 5570 samples retained a dark dominant background. No whole-window yellow or nearly blank samples; no measured change gap exceeded 50 ms. Every screenshot was inspected.

These are ScreenCaptureKit observations at logical window resolution, not physical display scanout or proof of no future stalls. Dense Sixel remains below 60 Hz. Capture CPU cost and all raw samples are in summary.json and scene folders. This is a presentation check, not a CPU comparison.

The existing synchronized-erase fix addresses the reproduced missing-image placeholder. The precise internal iTerm scheduling race remains uninstrumented. Installed ~/.cargo/bin/rbirds was not replaced; use ./target/release/rbirds from the repository to test this build.
