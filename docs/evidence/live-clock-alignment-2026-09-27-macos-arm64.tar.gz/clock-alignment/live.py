import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
scenes=[('kitty',['--render','kitty']),('sixel',['--render','sixel']),('dense-sixel',['--render','sixel','--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember'])]
for scene,extra in scenes:
    out=work/'live'/scene;out.mkdir(parents=True);name='rbirds-perf-clock-'+scene
    command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(out/'cpu.json'),'--trace',str(out/'trace.jsonl'),'--terminal-pid','73499','--helper-pid','24604','--warmup-seconds','3','--sample-seconds','5','--sample-count','2','--sample-gap-seconds','3','--note','Clock alignment qualification; iTerm 3.6.6; visible 100x32; no capture, build, tests or profiler during intervals; shared otherwise idle iTerm; UFC off. Absolute observation, not a CPU comparison.','--',str(root/'target/release/rbirds'),'--seed','42','--frames','7200',*extra]
    wrapped=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),*command])
    start=time.perf_counter();window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapped,name],text=True))
    (out/'window.txt').write_text(str(window)+'\n');print(scene,'own window',window,flush=True)
    time.sleep(max(0,start+22-time.perf_counter()))
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'],check=True)
    for _ in range(120):
        if (out/'completed.json').exists():
            result=json.loads((out/'completed.json').read_text());assert result['status']==0,result;break
        time.sleep(.5)
    else:raise RuntimeError('retain unfinished own window')
    report=json.loads((out/'cpu.json').read_text());assert report['measurement_valid'],report
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
    print(scene,[r['trace_alignment'] for r in report['interval_samples']],flush=True)
