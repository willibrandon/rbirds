import json
from pathlib import Path
import subprocess

root = Path('/Users/brandon/src/rbirds')
out = root / 'target/live-perf/final-cpu'
out.mkdir(exist_ok=True)
for mode in ['default', 'kitty']:
    for variant, repeat in [('baseline', 1), ('candidate', 1), ('candidate', 2), ('baseline', 2)]:
        name = f'{mode}-{variant}-{repeat}'
        binary = root / 'target/live-perf' / ('baseline/rbirds' if variant == 'baseline' else 'final-rows-rbirds')
        render = [] if mode == 'default' else ['--render', mode]
        cmd = ['open', '-W', '-n', '-a', 'kitty', '--args', '--config', 'NONE',
               '--title', 'rbirds-perf-' + name,
               '--override', 'initial_window_width=800', '--override', 'initial_window_height=500',
               '--override', 'remember_window_size=no', '--override', 'macos_quit_when_last_window_closed=yes',
               '/usr/bin/env', 'RBIRDS_TRACE=' + str(out / (name + '.jsonl')),
               '/opt/homebrew/bin/python3', str(root / 'tools/terminal-perf.py'),
               '--output', str(out / (name + '.json')), '--note',
               'Visible Kitty 0.44.0; UFC off; no capture; 800x500 logical window',
               '--', str(binary), *render, '--seed', '42', '--frames', '1200']
        subprocess.run(cmd, check=True, timeout=90)
        data = json.loads((out / (name + '.json')).read_text())
        print(name, {k: data[k] for k in ['wall_seconds', 'application_cpu_ms_per_second', 'terminal_cpu_ms_per_second']}, flush=True)
