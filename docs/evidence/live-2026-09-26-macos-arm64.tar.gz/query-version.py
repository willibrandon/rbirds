import fcntl, json, os, select, struct, sys, termios, time, tty
saved=termios.tcgetattr(0)
data={'ioctl':struct.unpack('HHHH',fcntl.ioctl(1,termios.TIOCGWINSZ,b'\0'*8)), 'queries':[]}
try:
    tty.setraw(0)
    for query in [b'\x1b[>q']:
        os.write(1,query)
        end=time.monotonic()+1
        reply=b''
        while time.monotonic()<end:
            if select.select([0],[],[],max(0,end-time.monotonic()))[0]:
                reply+=os.read(0,1024)
        data['queries'].append({'query':repr(query),'reply':repr(reply)})
finally:
    termios.tcsetattr(0,termios.TCSANOW,saved)
with open(sys.argv[1],'w') as f:json.dump(data,f,indent=2)
