Read the accompanying live-2026-09-26-macos-arm64.md before comparing samples.
CPU comparisons, presentation captures, and diagnostic experiments are separate.
Only paired/ had UFC playback throughout. kitty-strip/ was occluded. final-cpu/
and visible-final/ were foreground with UFC off; observer cost is excluded only
in CPU runs. iTerm captures are diagnostics, not CPU comparisons. iterm-final/
is the accepted iTerm-specific fix. The other iterm-* directories document the
failure and rejected experiments. iterm-missing-image.png is a bad frame from
the rejected erase-one-cell experiment. Old runs with incorrect Mach timebase
assumptions are excluded. Earlier visible/ captures used an unoptimized observer.
Scripts retain the original workstation paths for provenance; adapt them before
reproduction. Test drivers create finite processes and close only their windows.
Binaries are not included; binary-hashes.json identifies the comparison copies.
No physical scanout, compositor CPU, or GPU cost was measured.
