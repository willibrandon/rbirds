import json, shlex, subprocess, time
from pathlib import Path
root = Path('/Users/brandon/src/rbirds')
out = root / 'target/live-perf/iterm-final-events'
out.mkdir(exist_ok=True)
name = 'rbirds-perf-iterm-events'
cmd = shlex.join(['/usr/bin/env', 'RBIRDS_TRACE=' + str(out/'candidate.jsonl'), '/opt/homebrew/bin/python3', str(root/'target/live-perf/completion-exec.py'), name, str(out/'completed.json'), str(root/'target/live-perf/final-iterm-rbirds'), '--render','sixel','--seed','42','--frames','1800','--trails','--depth','--hawks','4','--flocks','3','--color','ember'])
w = int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),cmd,name],text=True))
print('window', w, flush=True)
time.sleep(5)
capture = subprocess.Popen([str(root/'target/presentation-capture'),name,str(out/'presentation.json'),'18'])
events=[]
for action in ['write text "l" newline NO','set columns to 120\nset rows to 36','write text "l" newline NO']:
    time.sleep(4)
    script = f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {w})\n{action}\nend tell'
    subprocess.run(['osascript','-e',script],check=True)
    events.append({'action':action,'monotonic':time.monotonic()})
(out/'events.json').write_text(json.dumps(events,indent=2))
assert capture.wait(timeout=30)==0
for i in range(180):
    if (out/'completed.json').exists():
        assert json.loads((out/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:
    raise RuntimeError('child did not finish')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {w})'])
