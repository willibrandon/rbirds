import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent
stage = work / 'evidence'
stage.mkdir()
sources = [
    'src/lib.rs', 'src/live.rs', 'src/timing.rs', 'src/fixed_scene.rs',
    'examples/fixed-scene.rs', 'tests/pty_fixed_scene.rs',
    'tools/terminal-perf.py', 'tools/compare-fixed-scenes.py',
    'tools/test_terminal_perf.py', 'tools/process_usage.py',
    'tools/measurement_clock.py', 'tools/trace_alignment.py',
    'docs/PERFORMANCE.md',
]
patch = subprocess.check_output(['git', 'diff', '--', *sources], cwd=root)
for name in ['src/fixed_scene.rs', 'examples/fixed-scene.rs',
             'tests/pty_fixed_scene.rs', 'tools/compare-fixed-scenes.py']:
    added = subprocess.run(['git', 'diff', '--no-index', '--', '/dev/null', name],
                           cwd=root, capture_output=True, check=False)
    assert added.returncode == 1
    patch += added.stdout
(work / 'source.patch').write_bytes(patch)
names = [
    'binary.json', 'setup.json', 'owned-window.json', 'app-process.json',
    'session.json', 'cleanup.json', 'setup.py', 'live.py', 'session.py',
    'cleanup.py', 'analyze.py', 'build-evidence.py', 'summary.json',
    'source.patch', 'preliminary/binary.json',
]
names += [p.name for p in sorted(work.glob('comparison-*.json'))]
names += [str(p.relative_to(work))
          for directory in ['cpu', 'preliminary/cpu']
          for p in sorted((work / directory).rglob('*'))
          if p.is_file() and p.suffix in ['.json', '.jsonl']]
assert len(names) == len(set(names))
for name in names:
    dst = stage / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(work / name, dst)
for name in sources:
    dst = stage / 'source' / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, dst)
for path in sorted((root / 'target').glob('fixed-scene-*.log')):
    dst = stage / 'checks' / path.name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dst)
manifest = {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(stage.rglob('*')) if p.is_file()}
(stage / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'docs/evidence/live-fixed-scene-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(stage, arcname='fixed-scene')
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        assert hashlib.sha256(tar.extractfile('fixed-scene/' + name).read()).hexdigest() == expected, name
report = {'files': len(manifest), 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(work / 'archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(report)
