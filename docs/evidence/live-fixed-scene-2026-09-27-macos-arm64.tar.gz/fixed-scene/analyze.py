import importlib.util
import json
import statistics
from pathlib import Path

work = Path(__file__).resolve().parent
source = work / 'source/tools/compare-fixed-scenes.py'
if not source.exists():
    source = work.parents[2] / 'tools/compare-fixed-scenes.py'
spec = importlib.util.spec_from_file_location('comparison', source)
comparison = importlib.util.module_from_spec(spec)
spec.loader.exec_module(comparison)
rows = []
for case in ['default', 'sixel', 'kitty', 'dense-sixel']:
    directories = [work / 'cpu' / f'{case}-{i}' for i in range(2)]
    compared = comparison.compare([json.loads((d / 'cpu.json').read_text()) for d in directories])
    observations = [o for d in directories for o in json.loads((d / 'observations.json').read_text())]
    focus = [o['owner_active'] for o in observations if 'owner_active' in o]
    assert focus and all(focus)
    runs = compared['runs']
    assert len({run['binary_sha256'] for run in runs}) == 1
    assert all(run['frames'] == {'first': 181, 'last': 1080, 'count': 900} for run in runs)
    means = {name: statistics.mean(run['cpu_ms_per_frame'][name] for run in runs)
             for name in ['application', 'terminal', 'helpers', 'combined']}
    combined = [run['cpu_ms_per_frame']['combined'] for run in runs]
    rows.append({'case': case, 'binary_sha256': runs[0]['binary_sha256'],
                 'mean_cpu_ms_per_frame': means,
                 'combined_repeat_spread_percent': (max(combined) - min(combined)) / means['combined'] * 100,
                 'wall_seconds': [run['wall_seconds'] for run in runs],
                 'focus_checks': len(focus), 'focus_all_active': all(focus),
                 'observed_max_terminal_footprint_bytes': max(o['memory']['physical_footprint'] for o in observations)})
(work / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
