import json,os,plistlib,subprocess,uuid
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');w=Path(__file__).resolve().parent;old=root/'target/live-perf/iterm-stable-build';app=old/'unpacked/iTerm.app'
suite='org.rbirds.perf.iterm.fixedscene.20260927';guid=str(uuid.uuid4()).upper()
p=plistlib.loads((old/'test-preferences.plist').read_bytes());p['Default Bookmark Guid']=guid;p['New Bookmarks'][0].update(Guid=guid,Name='rbirds-perf-fixed-scene')
(w/'test-preferences.plist').write_bytes(plistlib.dumps(p));subprocess.run(['defaults','import',suite,str(w/'test-preferences.plist')],check=True)
backup=w/'private-user-defaults-before.plist';backup.write_bytes(subprocess.check_output(['defaults','export','com.googlecode.iterm2','-']));backup.chmod(0o600)
(w/'setup.json').write_text(json.dumps({'suite':suite,'guid':guid,'version':'3.7.3','app':str(app)},indent=2)+'\n')
cmd=[str(app/'Contents/MacOS/iTerm2'),'-suite',suite,'-SUEnableAutomaticChecks','NO','-SUAutomaticallyUpdate','NO','--command=/usr/bin/python3 '+str(w/'session.py')]
process=subprocess.Popen(cmd,stdout=(w/'app.stdout').open('w'),stderr=(w/'app.stderr').open('w'),start_new_session=True)
(w/'app-process.json').write_text(json.dumps({'pid':process.pid,'command':cmd},indent=2)+'\n');print(process.pid)
