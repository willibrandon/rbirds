import json,subprocess,sys,time
from pathlib import Path

root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
owned=json.loads((work/'owned-window.json').read_text());app=json.loads((work/'setup.json').read_text())['app']
sys.path.insert(0,str(root/'tools'))
from process_usage import Counters

dense=['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']
with Counters() as counters:
    for scene,args in [('default',[]),('sixel',['--render','sixel']),('kitty',['--render','kitty']),('dense-sixel',['--render','sixel',*dense])]:
        for repeat in range(2):
            out=work/'cpu'/f'{scene}-{repeat}';out.mkdir(parents=True)
            title=f'rbirds-perf-fixed-scene-{scene}-{repeat}'
            command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(out/'cpu.json'),'--trace',str(out/'trace.jsonl'),
                '--terminal-pid',str(owned['pid']),'--helper-pid',str(owned['helper']),'--fixture-frames','180:900',
                '--note','iTerm 3.7.3; isolated 100x32/1400x1088; same executable repeated; UFC off; no capture/build/tests/profiling during CPU; 1Hz memory guard and focus check every five seconds; fixed simulation inputs and frame counter barriers',
                '--',str(work/'fixture'),'--seed','42','--frames','1080',*args]
            job={'title':title,'command':command,'completed':str(out/'completed.json')}
            (out/'job.json').write_text(json.dumps(job,indent=2)+'\n')
            (work/'job.tmp').write_text(json.dumps(job));(work/'job.tmp').replace(work/'job.json')
            time.sleep(.5)
            subprocess.run(['osascript','-e',f'tell application "System Events" to tell (first application process whose unix id is {owned["pid"]})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{title}")\nend tell'],check=True)
            print(scene,repeat,'started',flush=True);start=time.monotonic();observations=[]
            try:
                while not (out/'completed.json').exists():
                    snap=counters.snapshot(owned['pid']);item={'seconds':time.monotonic()-start,'memory':snap.memory}
                    if len(observations)%5==0:
                        item['owner_active']=subprocess.check_output(['osascript','-e',f'tell application "System Events" to get frontmost of (first application process whose unix id is {owned["pid"]})'],text=True).strip()=='true'
                    observations.append(item)
                    if snap.memory['physical_footprint']>2*1024**3:raise RuntimeError('two GiB memory guard')
                    if time.monotonic()-start>90:raise RuntimeError('owned fixture deadline exceeded')
                    time.sleep(1)
            except BaseException:
                subprocess.run(['osascript','-e',f'tell application "{app}" to tell current session of (first window whose id is {owned["window"]}) to write text "q" newline NO'],check=True)
                raise
            finally:
                (out/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
            result=json.loads((out/'completed.json').read_text());assert result['status']==0,result
            result=json.loads((out/'cpu.json').read_text());assert result['measurement_valid'],result
            print(scene,repeat,'complete',flush=True)
