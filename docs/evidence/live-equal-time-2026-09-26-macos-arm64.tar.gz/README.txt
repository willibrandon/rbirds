Foreground Kitty 0.44.0 with configuration disabled, 800x500 logical pixels.
UFC off. No screen capture, builds, or local test suites ran during these runs.
Each process runs 2400 frames. Interval CPU samples cover 3 to 33 seconds after
launch rather than the full process lifetime. Baseline is 2fa8167, candidate is
8dd03da (before the later Sixel-only fix). Actual binaries are identified in each
JSON. The candidate has bounded in-memory tracing enabled; baseline predates it.
Two alternating pairs per renderer are retained, including variation. These data
do not demonstrate a robust reduction in combined application and terminal CPU.
