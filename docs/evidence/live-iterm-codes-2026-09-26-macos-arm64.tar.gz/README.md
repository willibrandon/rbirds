Source changes are based on bc462a85ab8b0495a2e93e6b369b833b233edc7a.
The final candidate is final-rbirds. Executables are excluded.

before-rbirds is the preceding fixed-Huffman encoder. prototype-rbirds is the
first dynamic-code implementation. candidate-rbirds adds cleanup, the exact
fixed/dynamic cost comparison and tree tests. final-rbirds reduces reserved
output capacity to the preceding fixed-code bound and adds a bound/format test;
its emitted format and steady encoding algorithm are the same as candidate.

cpu and small-cpu compare candidate-rbirds with before-rbirds. final-cpu
repeats the default ABBA comparison using final-rbirds. CPU summaries use the
equal 20-second interval after three seconds of warm-up, not whole-lifetime CPU.
Capture, compilation and tests were separate. Main iTerm was shared with other
sessions; the selected decoder helper remained alive. GPU and compositor work
are not counted. All finite commands exited successfully and their own windows
were closed afterward. No installed binary or terminal preferences changed.

visible captures candidate-rbirds. Screenshots contain only the owned test
windows. Presentation timestamps come from ScreenCaptureKit, not physical
scanout; a high image-change rate is insufficient without image-content checks.
Visible summaries use nearest-rank percentiles. Near-blank means dominant color
occupies over 99.9% of samples; bright background means red exceeds 70 with
over 80% occupancy for this dark profile. Neither condition occurred.

corpus-data and corpus-final-data retain all eight before/after Kitty streams.
check-final.py independently decodes with Python zlib and compares RGBA,
dimensions, image IDs and placements. analyze.py recreates the omitted raw RGBA
files from corpus-data and uses the system Python Pillow/NumPy installation.
codec-bench.rs compares the saved fixed-code source with the initial dynamic
prototype in alternating order; its timing is diagnostic, not live evidence.
Raw RGBA and duplicate compressed payloads are omitted because the Kitty
streams already contain the pixels losslessly.

The final source passed cargo test --lib in debug and release, with release
pty_kitty_raster, paused_live, steady_state_allocation, kitty_oracle, c_kitty,
and sixel suites. cargo fmt --check, cargo clippy --all-targets --all-features
-- -D warnings, and cargo build --release also passed. The initial prototype
test log is retained separately from the final debug/release logs.
