import base64,json,re,statistics,time,zlib
from pathlib import Path
import numpy as np
p=Path(__file__).parent;rows=[]
for f in sorted((p/'corpus-data').glob('*.kitty')):
 parts=[]
 for m in re.finditer(rb'\x1b_G([^\x1b]*)\x1b\\',f.read_bytes()):
  header,_,payload=m[1].partition(b';');h=dict(item.decode().split('=',1) for item in header.split(b',') if b'=' in item)
  if h.get('a')=='t':metadata=h;parts=[]
  if payload:
   parts.append(base64.b64decode(payload,validate=True))
   if h.get('m')=='0':
    current=b''.join(parts);raw=zlib.decompress(current);w=int(metadata['s']);height=int(metadata['v']);assert len(raw)==w*height*4
    f.with_suffix(f'.{w}x{height}.rgba').write_bytes(raw)
    image=np.frombuffer(raw,dtype=np.uint8).reshape(height,w*4);up=image.copy();up[1:]-=image[:-1];sub=image.copy();sub[:,4:]-=image[:,:-4]
    for label,data in [('raw',raw),('up',up.tobytes()),('sub',sub.tobytes())]:
     trials=[]
     for _ in range(4):
      start=time.process_time_ns();encoded=zlib.compress(data,1);trials.append((time.process_time_ns()-start)/1e6)
     assert zlib.decompress(encoded)==data
     rows.append({'scene':f.stem,'filter':label,'width':w,'height':height,'current_bytes':len(current),'raw_bytes':len(raw),'zlib1_bytes':len(encoded),'zlib1_cpu_ms':statistics.median(trials),'colors':int(len(np.unique(np.frombuffer(raw,dtype=np.uint32))))})
(p/'analysis.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(r['scene'],r['filter'],r['colors'],r['current_bytes'],r['zlib1_bytes'],round(r['zlib1_cpu_ms'],3))
