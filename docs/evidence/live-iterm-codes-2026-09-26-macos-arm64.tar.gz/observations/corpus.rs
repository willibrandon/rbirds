use std::{fs, time::Instant};
use rbirds::{simulation::{Sim,Bird,RenderMode}, render::{Renderer,compose::KittyRaster,kitty::KittyGraphics}, spatial_grid::SpatialGrid};
fn main(){
 let out=std::env::args().nth(1).unwrap();fs::create_dir_all(&out).unwrap();
 for dense in [false,true] {
  let label=if dense {"dense"} else {"default"};
  let mut sim=Sim::new();sim.render_mode=RenderMode::Kitty;sim.config.birds=if dense {4096}else{800};sim.config.palette=1;
  if dense {sim.config.trails=true;sim.deep_look=true;sim.config.hawks=4;sim.config.flocks=3;sim.config.pace_notch=12;}
  sim.settle_the_bird_size();sim.apply_notches();sim.apply_screen_size(100,32,1400,1088);sim.rng.seed(42);sim.set_frame_seconds(1.0/60.0);sim.hawk_sets_built=true;
  let mut renderer=Renderer::default();renderer.kitty_raster=Some(KittyRaster::default());renderer.prepare_text_renderer(&mut sim,None,b"probe").unwrap();let mut birds=vec![Bird::default();sim.config.birds as usize];let mut snapshot=birds.clone();sim.initialize_birds(&mut birds);sim.place_hawks();let mut grid=SpatialGrid::new(12).unwrap();grid.prepare(1400,1088,sim.config.birds).unwrap();
  let mut graphics=KittyGraphics::new(1).unwrap();
  for frame in 0..601 {sim.snapshot_and_build(&birds,&mut snapshot,&mut grid).unwrap();sim.advance(&mut birds,&mut snapshot,&mut grid);if ![60,180,360,600].contains(&frame){continue;}
   graphics.clear();let start=Instant::now();renderer.queue_render_frame(&mut graphics,&sim,&birds).unwrap();let elapsed=start.elapsed().as_secs_f64()*1000.;fs::write(format!("{out}/{label}-{frame:03}.kitty"),graphics.buffer()).unwrap();println!("{label} {frame} {elapsed:.4} {}",graphics.buffer().len());
  }
 }
}
