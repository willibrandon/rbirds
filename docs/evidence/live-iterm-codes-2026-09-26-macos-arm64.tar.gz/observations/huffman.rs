use std::{cmp::Reverse, collections::BinaryHeap};
#[derive(Debug)]
pub struct Codes<const N: usize> { pub frequencies:[u32;N], pub lengths:[u8;N], pub codes:[u16;N] }
impl<const N:usize> Default for Codes<N> { fn default()->Self { Self{frequencies:[0;N],lengths:[0;N],codes:[0;N]} } }
impl<const N:usize> Codes<N> {
 pub fn build(&mut self, limit:u8, heap:&mut BinaryHeap<Reverse<(u64,usize)>>) {
  let active=self.frequencies.iter().filter(|&&n|n>0).count();
  let dummy=if self.frequencies[0]==0 {0}else{1};
  let mut floor=1u64;
  loop {
   heap.clear();let mut parents=[usize::MAX;572];
   for i in 0..N {
    if self.frequencies[i]>0 || (active==0 && i<2) || (active==1 && i==dummy) {heap.push(Reverse((u64::from(self.frequencies[i]).max(floor),i)));}
   }
   let mut next=N;
   while heap.len()>1 {let Reverse((a,i))=heap.pop().unwrap();let Reverse((b,j))=heap.pop().unwrap();parents[i]=next;parents[j]=next;heap.push(Reverse((a+b,next)));next+=1;}
   self.lengths.fill(0);
   for i in 0..N {let mut node=i;while parents[node]!=usize::MAX {self.lengths[i]+=1;node=parents[node];}}
   if *self.lengths.iter().max().unwrap()<=limit {break;}
   floor*=2;
  }
  let mut counts=[0u32;16];for &len in &self.lengths {if len>0 {counts[len as usize]+=1;}}
  let mut next=[0u32;16];let mut code=0;for bits in 1..16 {code=(code+counts[bits-1])<<1;next[bits]=code;}
  self.codes.fill(0);
  for i in 0..N {let len=self.lengths[i] as usize;if len>0 {self.codes[i]=(next[len].reverse_bits()>>(32-len)) as u16;next[len]+=1;}}
 }
}
