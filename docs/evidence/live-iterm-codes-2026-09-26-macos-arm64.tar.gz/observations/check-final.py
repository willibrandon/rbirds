import base64,json,re,zlib
from pathlib import Path
p=Path(__file__).parent;report=[]
def decode(file):
 frames=[];parts=[];placements=[]
 for m in re.finditer(rb'\x1b_G([^\x1b]*)\x1b\\',file.read_bytes()):
  header,_,payload=m[1].partition(b';');h=dict(item.decode().split('=',1) for item in header.split(b',') if b'=' in item)
  if h.get('a')=='p':placements.append(header)
  if h.get('a')=='t':metadata=h;parts=[]
  if payload:
   parts.append(base64.b64decode(payload,validate=True))
   if h.get('m')=='0':
    raw=zlib.decompress(b''.join(parts));assert len(raw)==int(metadata['s'])*int(metadata['v'])*4
    frames.append((metadata['i'],metadata['s'],metadata['v'],raw))
 return frames,placements
for f in sorted((p/'corpus-final-data').glob('*.kitty')):
 assert decode(f)==decode(p/'corpus-data'/f.name),f
 report.append({'case':f.stem,'rgba_and_placements_equal':True,'bytes_before':(p/'corpus-data'/f.name).stat().st_size,'bytes_after':f.stat().st_size})
(p/'final-transport-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
