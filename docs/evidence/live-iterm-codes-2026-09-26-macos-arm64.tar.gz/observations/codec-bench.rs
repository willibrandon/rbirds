use std::{fs,time::Instant};
mod kitty {pub use rbirds::render::kitty::KittyError;}
mod image {pub use rbirds::image::Image;}
#[path="before-pixel-runs.rs"] mod before;
mod dynamic;
mod huffman;
fn main(){let dir=std::env::args().nth(1).unwrap();let mut a=before::PixelRuns::default();let mut b=dynamic::PixelRuns::default();
for path in fs::read_dir(&dir).unwrap().map(|r|r.unwrap().path()).filter(|p|p.extension().is_some_and(|e|e=="rgba")) {
let name=path.file_name().unwrap().to_str().unwrap();let dims=name.split('.').nth(1).unwrap();let (w,h)=dims.split_once('x').unwrap();let (width,height):(usize,usize)=(w.parse().unwrap(),h.parse().unwrap());let image=image::Image{width:width as i32,height:height as i32,pixels:fs::read(&path).unwrap()};
let mut ta=Vec::new();let mut tb=Vec::new();for i in 0..24 {let start=Instant::now();if i%2==0 {std::hint::black_box(a.encode_region(&image,0,0,width,height).unwrap());ta.push(start.elapsed().as_secs_f64()*1000.);}else{std::hint::black_box(b.encode_region(&image,0,0,width,height).unwrap());tb.push(start.elapsed().as_secs_f64()*1000.);}}
ta.sort_by(f64::total_cmp);tb.sort_by(f64::total_cmp);let aa=a.encode_region(&image,0,0,width,height).unwrap();let bb=b.encode_region(&image,0,0,width,height).unwrap();fs::write(path.with_extension("dynamic.zlib"),bb).unwrap();println!("{name} {} {} {:.4} {:.4}",aa.len(),bb.len(),ta[6],tb[6]);}}
