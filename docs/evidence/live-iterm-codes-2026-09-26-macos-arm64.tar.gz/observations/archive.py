from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

repo = Path('/Users/brandon/src/rbirds')
work = repo / 'target/live-perf/iterm-kitty-compression'
dest = repo / 'target/live-perf/iterm-kitty-compression-evidence'
assert not dest.exists(), 'create the evidence staging directory only once'
dest.mkdir()
for source in sorted(work.rglob('*')):
    if not source.is_file() or source.suffix not in ['.py', '.rs', '.json', '.jsonl', '.txt', '.log', '.kitty']:
        continue
    target = dest / 'observations' / source.relative_to(work)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)

shots = []
for mapping in sorted(work.rglob('*screenshot.txt')):
    for name in mapping.read_text().splitlines():
        source = Path(name)
        assert source.name.startswith('codex-shot-') and source.is_file()
        target = dest / 'screenshots' / mapping.relative_to(work).with_suffix('.png')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        shots.append({'original': str(source), 'archive': str(target.relative_to(dest))})
(dest / 'screenshots.json').write_text(json.dumps(shots, indent=2) + '\n')

changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=repo, text=True).splitlines()
changed.append('src/render/frame_codes.rs')
for name in changed:
    assert not name.endswith('.tar.gz')
    target = dest / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / name, target)
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=repo)
new = subprocess.run(['git', 'diff', '--no-index', '--', '/dev/null', 'src/render/frame_codes.rs'], cwd=repo, stdout=subprocess.PIPE)
assert new.returncode == 1
(dest / 'source.patch').write_bytes(patch + new.stdout)
for name in ['tools/terminal-perf.py', 'tools/presentation-capture.swift', 'tools/trace-report.py', 'target/live-perf/completion-exec.py', 'target/live-perf/run-iterm.scpt']:
    target = dest / 'support' / Path(name).name
    target.parent.mkdir(exist_ok=True)
    shutil.copyfile(repo / name, target)
hashes = {name: hashlib.sha256((work / name).read_bytes()).hexdigest() for name in ['before-rbirds', 'prototype-rbirds', 'candidate-rbirds', 'final-rbirds']}
hashes['target/release/rbirds'] = hashlib.sha256((repo / 'target/release/rbirds').read_bytes()).hexdigest()
assert hashes['target/release/rbirds'] == hashes['final-rbirds']
(dest / 'executable-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
(dest / 'README.md').write_text('''Source changes are based on bc462a85ab8b0495a2e93e6b369b833b233edc7a.
The final candidate is final-rbirds. Executables are excluded.

before-rbirds is the preceding fixed-Huffman encoder. prototype-rbirds is the
first dynamic-code implementation. candidate-rbirds adds cleanup, the exact
fixed/dynamic cost comparison and tree tests. final-rbirds reduces reserved
output capacity to the preceding fixed-code bound and adds a bound/format test;
its emitted format and steady encoding algorithm are the same as candidate.

cpu and small-cpu compare candidate-rbirds with before-rbirds. final-cpu
repeats the default ABBA comparison using final-rbirds. CPU summaries use the
equal 20-second interval after three seconds of warm-up, not whole-lifetime CPU.
Capture, compilation and tests were separate. Main iTerm was shared with other
sessions; the selected decoder helper remained alive. GPU and compositor work
are not counted. All finite commands exited successfully and their own windows
were closed afterward. No installed binary or terminal preferences changed.

visible captures candidate-rbirds. Screenshots contain only the owned test
windows. Presentation timestamps come from ScreenCaptureKit, not physical
scanout; a high image-change rate is insufficient without image-content checks.
Visible summaries use nearest-rank percentiles. Near-blank means dominant color
occupies over 99.9% of samples; bright background means red exceeds 70 with
over 80% occupancy for this dark profile. Neither condition occurred.

corpus-data and corpus-final-data retain all eight before/after Kitty streams.
check-final.py independently decodes with Python zlib and compares RGBA,
dimensions, image IDs and placements. analyze.py recreates the omitted raw RGBA
files from corpus-data and uses the system Python Pillow/NumPy installation.
codec-bench.rs compares the saved fixed-code source with the initial dynamic
prototype in alternating order; its timing is diagnostic, not live evidence.
Raw RGBA and duplicate compressed payloads are omitted because the Kitty
streams already contain the pixels losslessly.

The final source passed cargo test --lib in debug and release, with release
pty_kitty_raster, paused_live, steady_state_allocation, kitty_oracle, c_kitty,
and sixel suites. cargo fmt --check, cargo clippy --all-targets --all-features
-- -D warnings, and cargo build --release also passed. The initial prototype
test log is retained separately from the final debug/release logs.
''')
manifest = {str(f.relative_to(dest)): hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(dest.rglob('*')) if f.is_file()}
(dest / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
out = repo / 'docs/evidence/live-iterm-codes-2026-09-26-macos-arm64.tar.gz'
with tarfile.open(out, 'w:gz', compresslevel=9) as tar:
    for f in sorted(dest.rglob('*')):
        if f.is_file():
            tar.add(f, arcname=str(f.relative_to(dest)))
with tarfile.open(out, 'r:gz') as tar:
    assert json.load(tar.extractfile('MANIFEST.json')) == manifest
    for name, digest in manifest.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest, name
print(json.dumps({'archive': str(out), 'files': len(manifest) + 1, 'bytes': out.stat().st_size, 'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}))
