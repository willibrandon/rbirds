//! Lossless RGBA transport for composed Kitty frames. Flat sprite interiors
//! and transparent sky compress with pixel runs; no hash-chain search or PNG
//! filtering is needed. The output is a standard zlib/DEFLATE stream.

use super::kitty::KittyError;
use super::huffman::Codes;
use std::{cmp::Reverse,collections::BinaryHeap};
use crate::image::Image;

#[derive(Debug, Default)]
pub(crate) struct PixelRuns {
    bytes: Vec<u8>,
    bits: u64,
    count: u32,
    positions: Vec<(usize, usize)>,
    tokens: Vec<u64>,
    literals: Codes<286>,
    distances: Codes<30>,
    lengths: Codes<19>,
    heap: BinaryHeap<Reverse<(u64,usize)>>,
}

impl PixelRuns {
    pub(crate) fn reserve(&mut self, length: usize) -> Result<(), KittyError> {
        let capacity = length.checked_mul(2).and_then(|n|n.checked_add(1024)).ok_or(KittyError::Memory)?;
        self.bytes.try_reserve(capacity.saturating_sub(self.bytes.len())).map_err(|_|KittyError::Memory)?;
        self.tokens.try_reserve((length/4).saturating_sub(self.tokens.len())).map_err(|_|KittyError::Memory)?;
        self.heap.try_reserve(572usize.saturating_sub(self.heap.len())).map_err(|_|KittyError::Memory)
    }

    fn bits(&mut self, value: u32, count: u32) {
        self.bits |= u64::from(value) << self.count;
        self.count += count;
        while self.count >= 8 {
            self.bytes.push(self.bits as u8);
            self.bits >>= 8;
            self.count -= 8;
        }
    }

    fn run(&mut self, length: usize, distance: usize) {
        const BASE: [usize; 28] = [
            3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99,
            115, 131, 163, 195, 227,
        ];
        let symbol = BASE.partition_point(|&base| base <= length) - 1;
        let sym=257+symbol;
        let (dist,extra)=if distance<=4 {(distance-1,0)}else{
            let log=usize::BITS-1-(distance-1).leading_zeros();let bits=log-1;
            let code=2*log+(((distance-1)>>bits)&1) as u32;
            let base=1+((2+(code as usize&1))<<bits);(code as usize,distance-base)
        };
        self.literals.frequencies[sym]+=1;self.distances.frequencies[dist]+=1;
        self.tokens.push((1<<63)|(sym as u64)|(((length-BASE[symbol])as u64)<<9)|((dist as u64)<<14)|((extra as u64)<<19));
    }

    fn finish(&mut self) {
        const EXTRA:[u32;28]=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5];
        self.literals.frequencies[256]+=1;
        self.literals.build(15,&mut self.heap);self.distances.build(15,&mut self.heap);
        self.lengths.frequencies.fill(0);
        for &len in self.literals.lengths.iter().chain(&self.distances.lengths) {self.lengths.frequencies[len as usize]+=1;}
        self.lengths.build(7,&mut self.heap);
        self.bits(5,3);self.bits(29,5);self.bits(29,5);self.bits(15,4);
        for symbol in [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15] {self.bits(self.lengths.lengths[symbol] as u32,3);}
        for i in 0..316 {let len=if i<286 {self.literals.lengths[i]}else{self.distances.lengths[i-286]} as usize;self.bits(self.lengths.codes[len] as u32,self.lengths.lengths[len] as u32);}
        for i in 0..self.tokens.len() {
            let token=self.tokens[i];
            if token>>63==0 {
                for c in 0..4 {let byte=((token>>(c*8))&255) as usize;self.bits(self.literals.codes[byte] as u32,self.literals.lengths[byte] as u32);}
            } else {
                let sym=(token&511) as usize;let dist=((token>>14)&31) as usize;
                self.bits(self.literals.codes[sym] as u32,self.literals.lengths[sym] as u32);
                self.bits(((token>>9)&31) as u32,EXTRA[sym-257]);
                self.bits(self.distances.codes[dist] as u32,self.distances.lengths[dist] as u32);
                if dist>=4 {self.bits(((token>>19)&8191) as u32,dist as u32/2-1);}
            }
        }
        self.bits(self.literals.codes[256] as u32,self.literals.lengths[256] as u32);
    }

    pub(crate) fn encode_region(
        &mut self,
        image: &Image,
        left: usize,
        top: usize,
        width: usize,
        height: usize,
    ) -> Result<&[u8], KittyError> {
        let iw = usize::try_from(image.width).map_err(|_| KittyError::Argument)?;
        let ih = usize::try_from(image.height).map_err(|_| KittyError::Argument)?;
        if width == 0
            || height == 0
            || left > iw
            || top > ih
            || width > iw - left
            || height > ih - top
            || iw.checked_mul(ih).and_then(|n| n.checked_mul(4)) != Some(image.pixels.len())
        {
            return Err(KittyError::Argument);
        }
        let length = width * height * 4;
        // A literal takes at most nine bits. Runs are always shorter. Reserve
        // before encoding so no allocation can interrupt a partial stream.
        self.bytes.clear();
        self.reserve(length)?;
        self.bits = 0;
        self.count = 0;
        const SLOTS: usize = 16384;
        self.positions
            .try_reserve(SLOTS.saturating_sub(self.positions.len()))
            .map_err(|_| KittyError::Memory)?;
        self.positions.resize(SLOTS, (usize::MAX, 0));
        self.positions.fill((usize::MAX, 0));
        self.bytes.extend_from_slice(&[0x78, 0x01]);
        self.tokens.clear();self.literals.frequencies.fill(0);self.distances.frequencies.fill(0);
        let mut previous = None;
        let (mut a, mut b) = (1u32, 0u32);
        for y in top..top + height {
            let start = (y * iw + left) * 4;
            let row = &image.pixels[start..start + width * 4];
            let mut at = 0;
            while at < row.len() {
                let pixel: [u8; 4] = row[at..at + 4].try_into().unwrap();
                if previous == Some(pixel) {
                    let end = (at + 256).min(row.len());
                    let mut next = at + 4;
                    while next < end && row[next..next + 4] == pixel {
                        next += 4;
                    }
                    self.run(next - at, 4);
                    at = next;
                } else {
                    // One hash probe finds repeated sprite spans without a
                    // chain search. Store both canvas and cropped-stream
                    // offsets so distances exclude the skipped row margins.
                    if at + 8 <= row.len() {
                        let key = u64::from_le_bytes(row[at..at + 8].try_into().unwrap());
                        let slot = (key.wrapping_mul(0x9e3779b97f4a7c15) >> 50) as usize;
                        let logical = (y - top) * row.len() + at;
                        let (prior, source) = self.positions[slot];
                        self.positions[slot] = (logical, start + at);
                        if prior < logical && logical - prior <= 32768 {
                            let source_left = source % (iw * 4);
                            let limit =
                                256.min(row.len() - at).min((left + width) * 4 - source_left);
                            if limit >= 8 && image.pixels[source..source + 8] == row[at..at + 8] {
                                let mut length = 8;
                                while length < limit
                                    && image.pixels[source + length..source + length + 4]
                                        == row[at + length..at + length + 4]
                                {
                                    length += 4;
                                }
                                self.run(length, logical - prior);
                                previous =
                                    Some(row[at + length - 4..at + length].try_into().unwrap());
                                at += length;
                                continue;
                            }
                        }
                    }
                    self.tokens.push(u64::from(u32::from_le_bytes(pixel)));
                    for byte in pixel { self.literals.frequencies[byte as usize]+=1; }
                    previous = Some(pixel);
                    at += 4;
                }
            }
            // 5552 bytes bound both sums within u32 even for all-255 input.
            for chunk in row.chunks(5552) {
                for &byte in chunk {
                    a += u32::from(byte);
                    b += a;
                }
                a %= 65521;
                b %= 65521;
            }
        }
        self.finish();
        if self.count > 0 {
            self.bits(0, 8 - self.count);
        }
        self.bytes.extend_from_slice(&((b << 16) | a).to_be_bytes());
        Ok(&self.bytes)
    }
}

