import fcntl,json,os,struct,subprocess,sys,termios,time
from pathlib import Path
work=Path(__file__).resolve().parent
os.write(1,b'\x1b]0;rbirds-perf-isolated-idle\x07')
(work/'session.json').write_text(json.dumps({'pid':os.getpid(),'terminal_pid':os.environ.get('ITERM_PID'),'size':struct.unpack('HHHH',fcntl.ioctl(1,termios.TIOCGWINSZ,b'\0'*8))})+'\n')
while not (work/'stop-session').exists():
    request=work/'job.json'
    if not request.exists():time.sleep(.1);continue
    job=json.loads(request.read_text());request.unlink()
    assert job['title'].startswith('rbirds-perf-')
    os.write(1,('\x1b]0;'+job['title']+'\x07').encode())
    result=subprocess.run(job['command'],stderr=subprocess.PIPE)
    output=Path(job['completed']);temp=output.with_suffix('.tmp')
    temp.write_text(json.dumps({'status':result.returncode,'stderr':result.stderr.decode(errors='replace'),'command':job['command']})+'\n');temp.replace(output)
