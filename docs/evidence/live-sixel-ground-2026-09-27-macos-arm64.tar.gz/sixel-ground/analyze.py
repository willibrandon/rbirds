import collections, csv, json, statistics
from pathlib import Path
import numpy as np
from PIL import Image

work=Path(__file__).resolve().parent
def save(name,value):
    (work/name).write_text(json.dumps(value,indent=2)+'\n')

visible={}
for p in sorted((work/'visible').glob('*/presentation.json')):
    d=json.loads(p.read_text());f=d['frames'];focus=d['focus_observations']
    c=[x['pts'] for x in f if x['changed']];g=np.diff(c)*1000
    visible[p.parent.name]={'samples':len(f),'changes_per_second':(len(c)-1)/(c[-1]-c[0]),'p99_gap_ms':float(np.percentile(g,99)),'max_gap_ms':float(max(g)),
        'dominant_colors':dict(collections.Counter(str(x['dominant_rgb']) for x in f)),
        'max_dominant_fraction':max(x['dominant_fraction'] for x in f),
        'focus_observations':len(focus),'owner_active':sum(x['owner_active'] for x in focus),'top_content_window':sum(x['top_normal_window'] for x in focus),'capture_cpu_seconds':d['capture_cpu_seconds']}
save('visible-summary.json',visible)

cpu={};intervals=[]
for p in sorted((work/'cpu').glob('*/cpu.json')):
    d=json.loads(p.read_text());assert d['measurement_valid'];i=d['interval_sample']
    scene,index,side=p.parent.name.split('-');alignment=i['trace_alignment'];lo=alignment['submitted_frames_min'];hi=alignment['submitted_frames_max']
    app=i['application_cpu_ms_per_second'];terminal=i['terminal_cpu_ms_per_second'];helper=i['terminal_helpers']['cpu_ms_per_second']
    observations=json.loads((p.parent/'observations.json').read_text());focus=[o['owner_active'] for o in observations if 'owner_active' in o]
    intervals.append({'scene':scene,'side':side,'index':int(index),'application':app,'terminal':terminal,'decoder':helper,'combined':app+terminal+helper,'submitted_min':lo,'submitted_max':hi,
        'submitted_hz_min':lo/i['wall_seconds'],'submitted_hz_max':hi/i['wall_seconds'],'combined_ms_per_submission_min':(app+terminal+helper)*i['wall_seconds']/hi,'combined_ms_per_submission_max':(app+terminal+helper)*i['wall_seconds']/lo,
        'owner_active':sum(focus),'focus_observations':len(focus),'terminal_peak_sampled_mib':max(o['memory']['physical_footprint'] for o in observations)/2**20})
for scene in ['default','dense','sparse']:
    rows=[i for i in intervals if i['scene']==scene]
    if len(rows)!=4:continue
    cpu[scene]={}
    for side in ['before','after']:
        these=[i for i in rows if i['side']==side]
        cpu[scene][side]={k:statistics.mean(i[k] for i in these) for k in ['application','terminal','decoder','combined','submitted_hz_min','submitted_hz_max','combined_ms_per_submission_min','combined_ms_per_submission_max']}
    cpu[scene]['combined_change_percent']=(cpu[scene]['after']['combined']/cpu[scene]['before']['combined']-1)*100
save('cpu-intervals.json',intervals);save('cpu-summary.json',cpu)

rows=list(csv.reader((work/'probe.csv').read_text().splitlines()));codec={}
for scene in ['default','dense','sparse']:
    timings={side:statistics.mean(float(r[4])/int(r[5])*1000 for r in rows if r[0]=='timing' and r[1]==scene and r[3]==side) for side in ['before','after']}
    frames=[r for r in rows if r[0]=='frame' and r[1]==scene]
    old=sum(int(r[5]) for r in frames);new=sum(int(r[6]) for r in frames)
    codec[scene]={'encode_ms':timings,'encode_change_percent':(timings['after']/timings['before']-1)*100,'before_bytes':old,'after_bytes':new,'byte_change_percent':(new/old-1)*100}
save('codec-summary.json',codec)
static=[]
for scene in ['default','dense']:
    a=np.array(Image.open(work/'static'/f'{scene}-before'/'screenshot.png').convert('RGBA'))[148:1236,122:1522].astype('int16')
    b=np.array(Image.open(work/'static'/f'{scene}-after'/'screenshot.png').convert('RGBA'))[148:1236,122:1522].astype('int16')
    d=np.abs(a-b);static.append({'scene':scene,'roi':[122,148,1522,1236],'pixels':1400*1088,'differing_pixels':int(np.count_nonzero(d.max(axis=2))),'max_channel_difference':int(d.max())})
save('static-comparison.json',static)
print(json.dumps({'visible':visible,'cpu':cpu,'codec':codec},indent=2))
