import hashlib, json, shutil, tarfile
from pathlib import Path

root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
stage=work/'evidence';stage.mkdir()
names=['baseline.json','setup.json','owned-window.json','app-process.json','session.json','cleanup.json','test-preferences.plist',
       'probe.rs','probe.csv','static-probe.rs','static-probe.csv','before-sixel.rs','changes.patch','live.py','session.py','cleanup.py','analyze.py','build-evidence.py',
       'codec-summary.json','cpu-summary.json','cpu-intervals.json','visible-summary.json','static-comparison.json',
       'native-debug.log','native-release.log','rosetta-release.log','clippy.log','ci-parent-macos-arm.log']
names += [str(p.relative_to(work)) for directory in ['cpu','visible','static'] for p in (work/directory).rglob('*') if p.is_file() and p.suffix in ['.json','.png']]
names += [p.name for p in work.glob('*.frame')]
for name in names:
    src=work/name;dst=stage/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for name in ['src/render/sixel.rs','tools/test_shared_renderer.py','tools/terminal-perf.py','tools/process_usage.py','tools/measurement_clock.py','tools/trace_alignment.py','tools/presentation-capture.swift']:
    dst=stage/'source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,dst)
for path in (work/'cpu').glob('*/trace.jsonl'):
    dst=stage/path.relative_to(work);shutil.copy2(path,dst)
for path in (work/'visible').glob('*/trace.jsonl'):
    dst=stage/path.relative_to(work);shutil.copy2(path,dst)
manifest={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root/'docs/evidence/live-sixel-ground-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(stage,arcname='sixel-ground')
with tarfile.open(archive,'r:gz') as tar:
    for name,expected in manifest.items():
        assert hashlib.sha256(tar.extractfile('sixel-ground/'+name).read()).hexdigest()==expected,name
report={'files':len(manifest),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(work/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
