
use std::{ffi::OsString, time::Instant, hint::black_box};
pub use rbirds::{image, render, sprites};
use rbirds::{app::{Program,read_options}, live::LiveLoop, platform::{Timespec,WinSize}, render::kitty::KittyGraphics, simulation::Bird,spatial_grid::SpatialGrid,stdio::CStdout};
#[path="before-sixel.rs"] mod before;
fn main() {
    let mut old=before::Sixel::default();let mut new=render::sixel::Sixel::default();let mut cases=0;
    for width in [1,7,8,9,15,16,31,64] { for height in [1,5,6,7,13] { for alpha in 0..=255 {
        let mut image=image::Image::alloc(width,height).unwrap();
        for y in 0..height {for x in 0..width {let i=(y/3*101+x/8*37+alpha*13) as u32;
            let pixel=if (x+y)%7==0 {[19,19,23,255]}else{[(i*73) as u8,(i*151) as u8,(i*239) as u8,alpha as u8]};
            let at=((y*width+x)*4) as usize;image.pixels[at..at+4].copy_from_slice(&pixel);}}
        assert_eq!(decode(old.encode(&image).unwrap()),decode(new.encode(&image).unwrap()));cases+=1;
        if width>3 && height>3 {assert_eq!(decode(old.encode_region(&image,1,1,width as usize-2,height as usize-2).unwrap()),decode(new.encode_region(&image,1,1,width as usize-2,height as usize-2).unwrap()));cases+=1;}
    }}}
    println!("oracle,{cases},equal");
    for scene in ["default","dense","sparse"] {
        let mut p=Program::new();let mut args:Vec<OsString>=["rbirds","--render","sixel","--seed","42"].into_iter().map(OsString::from).collect();
        if scene=="dense" {args.extend(["--birds","4096","--speed","12","--hawks","4","--flocks","3","--depth","--trails","--color","ember"].into_iter().map(OsString::from));}
        if scene=="sparse" {args.extend(["--birds","32"].into_iter().map(OsString::from));}
        read_options(&mut p,&args,&mut CStdout::new()).unwrap();
        let sim=&mut p.sim;let renderer=&mut p.renderer;
        sim.settle_the_bird_size();sim.rng.seed(42);sim.apply_screen_size(100,32,1400,1088);
        renderer.prepare_text_renderer(sim,None,b"rbirds").unwrap();renderer.erase_sixel_before_frame=true;renderer.crop_sixel_frames=true;
        sim.set_frame_seconds(1.0/60.0);sim.hawk_sets_built=true;let count=sim.config.birds as usize;
        let mut birds=vec![Bird::default();count];let mut snapshot=birds.clone();sim.initialize_birds(&mut birds);sim.place_hawks();sim.begin_the_intro();
        let mut grid=SpatialGrid::new(12).unwrap();grid.prepare(1400,1088,count as i32).unwrap();let mut out=KittyGraphics::new(1).unwrap();let mut live=LiveLoop::new(Timespec{tv_sec:10,tv_nsec:0},count as i32);
        let mut corpus=Vec::new();
        for frame in 1..=600 {out.clear();let ns=frame*16_666_667_i64;
            live.frame(sim,renderer,&mut out,&mut birds,&mut snapshot,&mut grid,None,Timespec{tv_sec:10+ns/1_000_000_000,tv_nsec:ns%1_000_000_000},WinSize{row:32,col:100,xpixel:1400,ypixel:1088}).unwrap();
            if frame==300 {
                for side in ["before","after"] {
                    let mut data=b"\x1b[?2026h\x1b[2J\x1b[H\x1b[?80l".to_vec();
                    data.extend_from_slice(if side=="before" {old.encode(&renderer.canvas).unwrap()}else{new.encode(&renderer.canvas).unwrap()});
                    data.extend_from_slice(b"\x1b[?80h\x1b[H\x1b[?2026l");
                    std::fs::write(format!("target/live-perf/sixel-solid-ground/{scene}-{side}.frame"),data).unwrap();
                }
            }
            if [60,180,300,450,600].contains(&frame) {
                let mut bounds=(100,32,0,0);
                for (y,row) in renderer.canvas.pixels.chunks_exact(1400*4).enumerate() {for (x,pixel) in row.chunks_exact(4).enumerate() {if pixel[..3]!=sprites::PICTURE_GROUND {bounds.0=bounds.0.min(x/14);bounds.1=bounds.1.min(y/34);bounds.2=bounds.2.max(x/14+1);bounds.3=bounds.3.max(y/34+1);}}}
                let (x0,y0,x1,y1)=bounds;let r=(x0*14,y0*34,(x1-x0)*14,(y1-y0)*34);
                if r.2==0 || r.3==0 {continue;}
                let a=old.encode_region(&renderer.canvas,r.0,r.1,r.2,r.3).unwrap();let b=new.encode_region(&renderer.canvas,r.0,r.1,r.2,r.3).unwrap();
                assert_eq!(decode(a),decode(b),"{scene} frame {frame}");
                println!("frame,{scene},{frame},{},{},{},{}",r.2,r.3,a.len(),b.len());
                corpus.push((renderer.canvas.clone(),r));
            }
        }
        for (round,side) in std::iter::empty::<&str>().enumerate() {
            let mut bytes=0;let start=Instant::now();
            for _ in 0..100 {for (im,r) in &corpus {let data=if side=="before" {old.encode_region(black_box(im),r.0,r.1,r.2,r.3).unwrap()}else{new.encode_region(black_box(im),r.0,r.1,r.2,r.3).unwrap()};bytes+=black_box(data).len();}}
            println!("timing,{scene},{round},{side},{},{},{bytes}",start.elapsed().as_secs_f64(),corpus.len()*100);
        }
    }
}

fn number(bytes: &[u8], at: &mut usize) -> usize {
    let start = *at;
    while bytes.get(*at).is_some_and(u8::is_ascii_digit) {
        *at += 1;
    }
    assert!(*at > start, "missing number at {start}");
    std::str::from_utf8(&bytes[start..*at]).unwrap().parse().unwrap()
}

fn decode(bytes: &[u8]) -> (usize, usize, Vec<[u8; 3]>) {
    assert!(bytes.starts_with(b"\x1bP0;1q\"1;1;"));
    assert!(bytes.ends_with(b"\x1b\\"));
    let mut at = b"\x1bP0;1q\"1;1;".len();
    let width = number(bytes, &mut at);
    assert_eq!(bytes[at], b';');
    at += 1;
    let height = number(bytes, &mut at);
    let mut pixels = vec![None; width * height];
    let mut colours = [[0; 3]; 256];
    let (mut x, mut y, mut colour) = (0, 0, 0);
    while at < bytes.len() - 2 {
        let command = bytes[at];
        at += 1;
        match command {
            b'#' => {
                colour = number(bytes, &mut at);
                if bytes[at] == b';' {
                    at += 1;
                    assert_eq!(number(bytes, &mut at), 2);
                    for channel in &mut colours[colour] {
                        assert_eq!(bytes[at], b';');
                        at += 1;
                        *channel = ((number(bytes, &mut at) * 255 + 50) / 100) as u8;
                    }
                }
            }
            b'$' => x = 0,
            b'-' => {
                x = 0;
                y += 6;
            }
            _ => {
                let (count, bits) = if command == b'!' {
                    let count = number(bytes, &mut at);
                    let bits = bytes[at] - b'?';
                    at += 1;
                    (count, bits)
                } else {
                    assert!((b'?'..=b'~').contains(&command));
                    (1, command - b'?')
                };
                for column in x..x + count {
                    assert!(column < width);
                    for bit in 0..6 {
                        if bits & (1 << bit) != 0 {
                            assert!(y + bit < height, "paint past the final partial band");
                            pixels[(y + bit) * width + column] = Some(colours[colour]);
                        }
                    }
                }
                x += count;
            }
        }
    }
    (
        width,
        height,
        pixels.into_iter().map(|p| p.expect("every raster pixel must be repainted")).collect(),
    )
}

