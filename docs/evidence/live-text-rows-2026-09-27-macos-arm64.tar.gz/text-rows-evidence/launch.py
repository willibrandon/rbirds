import json, os, shlex, subprocess, sys, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
if len(sys.argv)>1 and sys.argv[1]=='child':
    (work/'app.pid').write_text(str(os.getpid())+'\n')
    os.execv(str(root/'target/release/rbirds'),[str(root/'target/release/rbirds'),'--seed','42','--frames','1200'])
name='rbirds-perf-text-reader-profile'
command=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,
                    str(work/'completed.json'),'/usr/bin/python3',str(Path(__file__).resolve()),'child'])
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True))
(work/'window.txt').write_text(str(window)+'\n');print('own window',window,flush=True)
time.sleep(5)
pid=int((work/'app.pid').read_text())
subprocess.run(['sample',str(pid),'3','1','-file',str(work/'application.sample.txt')],check=True)
for _ in range(100):
    if (work/'completed.json').exists():
        assert json.loads((work/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:raise RuntimeError('finite child did not finish; retain own window')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
print('complete',flush=True)
