import json, shlex, shutil, subprocess, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
out=work/'visible';out.mkdir();name='rbirds-perf-reader-visible'
command=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),
                    name,str(out/'completed.json'),'/usr/bin/env',
                    'RBIRDS_TRACE='+str(out/'trace.jsonl'),str(work/'after-rbirds'),
                    '--seed','42','--frames','3600'])
started=time.perf_counter()
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True))
(out/'window.txt').write_text(str(window)+'\n');print('own window',window,flush=True)
for label,offset in [('early',5),('later',45)]:
    time.sleep(max(0,started+offset-time.perf_counter()))
    subprocess.run([str(root/'target/presentation-capture'),name,
                    str(out/(label+'-presentation.json')),'15'],check=True)
    print(label,'complete',flush=True)
    if label=='early':
        screenshot=subprocess.check_output(['/usr/bin/python3',
            '/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py',
            '--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
        (out/'screenshot-path.txt').write_text(screenshot+'\n')
        shutil.copy2(screenshot,out/'screenshot.png')
for _ in range(100):
    if (out/'completed.json').exists():
        assert json.loads((out/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:raise RuntimeError('finite child did not finish; retain own window')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
print('complete',flush=True)
