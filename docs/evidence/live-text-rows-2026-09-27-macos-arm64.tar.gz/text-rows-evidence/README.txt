Pixel-row reader experiment and accepted local result, parent e4a8de4.

metadata.json identifies binaries and source.patch. Executables are omitted.
The prior baseline executable is also the final shared-image build; the
intervening commits changed only the measurement harness and documentation.

cpu/ holds four quiet live runs in before/after/after/before order. Every run
has an early and later 15-second window in the same unchanged session. No
capture, profiler, builds or tests ran during those windows. Summaries use
medians of two runs per build. Terminal CPU includes other idle sessions in
that process; compositor/GPU and unselected helpers are excluded.

bench and bench-shaded hold independent construction comparisons, not live
playback or terminal measurements. The shaded sprite is the earlier gradient
fixture. Byte counts matched across variants. Cell-oracle logs independently
check exact grids, escape bytes and reconstructed pixels against the C reader.

visible/ is a separate candidate-only 60-second run. Its early and later
captures were each 15 seconds, at approximately the CPU-window offsets.
The owned-window screenshot was taken between captures and inspected. These
observations do not establish a cadence improvement or physical scanout.
application.sample.txt is a separate intrusive baseline profile, not quiet CPU
evidence. Its wall-stack counts must not be read as CPU percentages.

All owned test windows finished and were closed. Original paths, process IDs
and window IDs are retained for provenance. Adapt them to fresh directories
and currently owned processes before rerunning a driver. No installed binary
or terminal preference was replaced. source/ retains the measurement helpers.
