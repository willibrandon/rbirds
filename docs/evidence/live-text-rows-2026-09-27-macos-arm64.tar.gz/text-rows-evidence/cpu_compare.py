import json, shlex, statistics, subprocess, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
out=work/'cpu';out.mkdir();results=[]
for index,side in enumerate(['before','after','after','before']):
    directory=out/(str(index)+'-'+side);directory.mkdir()
    name='rbirds-perf-reader-'+str(index)+'-'+side
    command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),
             '--output',str(directory/'cpu.json'),'--terminal-pid','73499','--helper-pid','24604',
             '--warmup-seconds','3','--sample-seconds','15','--sample-count','2',
             '--sample-gap-seconds','25','--note','iTerm 3.6.6; visible owned 100x32 window; '
             'no capture/profiler/build/tests; same shared otherwise idle iTerm process; UFC off',
             '--',str(work/(side+'-rbirds')),'--seed','42','--frames','3600']
    wrapped=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),
                        name,str(directory/'completed.json'),*command])
    window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapped,name],text=True))
    (directory/'window.txt').write_text(str(window)+'\n')
    print(index,side,'own window',window,flush=True)
    for _ in range(180):
        if (directory/'completed.json').exists():
            completed=json.loads((directory/'completed.json').read_text())
            assert completed['status']==0,completed
            break
        time.sleep(.5)
    else:raise RuntimeError('finite child did not finish; retain own window')
    report=json.loads((directory/'cpu.json').read_text())
    assert report['measurement_valid'] and report['status']==0,report
    results.append({'side':side,'report':report})
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
    print('complete',side,report['interval_samples'],flush=True)
summary={}
for phase,slot in [('early',0),('later',1)]:
    summary[phase]={}
    for side in ['before','after']:
        samples=[r['report']['interval_samples'][slot] for r in results if r['side']==side]
        summary[phase][side]={key:statistics.median(r[key] for r in samples)
                             for key in ['application_cpu_ms_per_second','terminal_cpu_ms_per_second']}
        summary[phase][side]['combined_cpu_ms_per_second']=statistics.median(
            r['application_cpu_ms_per_second']+r['terminal_cpu_ms_per_second']+
            r['terminal_helpers']['cpu_ms_per_second'] for r in samples)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
