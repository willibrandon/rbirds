#!/usr/bin/env python3
"""Measure rbirds, a terminal and selected helpers on Windows, Linux or macOS."""

import argparse
import hashlib
import json
import math
import os
import platform
import shutil
import subprocess
import threading
import time
from pathlib import Path

from process_usage import Counters, cpu_delta


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--terminal-pid", type=int, default=os.getppid(),
                        help="defaults to parent; launch this as the terminal's direct child")
    parser.add_argument("--helper-pid", type=int, action="append", default=[],
                        help="also sample this terminal helper; repeat for multiple stable processes")
    parser.add_argument("--note", default="",
                        help="terminal/version, visibility, power mode, other activity")
    parser.add_argument("--sample-seconds", type=float,
                        help="also measure all selected processes over an equal elapsed-time interval")
    parser.add_argument("--warmup-seconds", type=float, default=3,
                        help="delay before the optional interval sample (default: 3)")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.command[:1] == ["--"]:
        args.command.pop(0)
    if not args.command:
        parser.error("requires a command after --")
    if not math.isfinite(args.warmup_seconds) or args.warmup_seconds < 0:
        parser.error("warmup seconds must be finite and nonnegative")
    if args.sample_seconds is not None and (
            not math.isfinite(args.sample_seconds) or args.sample_seconds <= 0):
        parser.error("sample seconds must be finite and positive")
    pids = [args.terminal_pid, *args.helper_pid]
    if any(pid <= 0 or pid > 0x7fffffff for pid in pids) or len(set(pids)) != len(pids):
        parser.error("terminal and helper PIDs must be distinct positive process IDs")
    binary = shutil.which(args.command[0])
    if not binary:
        parser.error(f"cannot find executable: {args.command[0]}")

    with Counters() as counters:
        report = measure(args, counters, binary)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    raise SystemExit(report["status"] or (0 if report["measurement_valid"] else 1))


def measure(args, counters, binary):
    def helper_sample(before, wall):
        samples = []
        for pid, first in before.items():
            result = {"pid": pid}
            try:
                cpu = cpu_delta(first, counters.snapshot(pid))
                result.update(cpu_seconds=cpu, cpu_ms_per_second=cpu / wall * 1000)
            except (OSError, RuntimeError) as error:
                result["error"] = str(error)
            samples.append(result)
        result = {"processes": samples}
        if all("error" not in sample for sample in samples):
            cpu = sum(sample["cpu_seconds"] for sample in samples)
            result.update(cpu_seconds=cpu, cpu_ms_per_second=cpu / wall * 1000)
        return result

    # Check the units against an independent counter in this process. This
    # catches treating ARM ticks as nanoseconds (Intel often has a 1:1 ratio).
    observed = counters.snapshot(os.getpid()).cpu_seconds
    if abs(observed - time.process_time()) > .05:
        raise RuntimeError("CPU counter units disagree with process_time")

    terminal_name = counters.name(args.terminal_pid)
    helper_names = {pid: counters.name(pid) for pid in args.helper_pid}
    binary_hash = hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    helpers_before = {pid: counters.snapshot(pid) for pid in args.helper_pid}
    before = counters.snapshot(args.terminal_pid)
    for snapshot in [before, *helpers_before.values()]:
        if not snapshot.alive:
            raise RuntimeError("selected process already exited before launch")
    started = time.monotonic()
    process = subprocess.Popen(args.command)
    stopped = threading.Event()
    interval = {"error": "interval sample did not complete"} if args.sample_seconds else {}

    def sample_interval():
        try:
            if stopped.wait(args.warmup_seconds):
                raise RuntimeError("child exited during warmup")
            app_before = counters.snapshot(process.pid)
            term_before = counters.snapshot(args.terminal_pid)
            helper_before = {pid: counters.snapshot(pid) for pid in args.helper_pid}
            sample_start = time.monotonic()
            if stopped.wait(args.sample_seconds):
                raise RuntimeError("child exited before the interval sample finished")
            app_after = counters.snapshot(process.pid)
            term_after = counters.snapshot(args.terminal_pid)
            sample_wall = time.monotonic() - sample_start
            interval.update({
                "start_seconds_after_launch": sample_start - started,
                "wall_seconds": sample_wall,
                "application_cpu_ms_per_second":
                    cpu_delta(app_before, app_after) / sample_wall * 1000,
                "terminal_cpu_ms_per_second":
                    cpu_delta(term_before, term_after) / sample_wall * 1000,
            })
            if args.helper_pid:
                interval["terminal_helpers"] = helper_sample(helper_before, sample_wall)
            interval.pop("error", None)
        except Exception as error:
            # Keep worker failures in the report and fail the measurement.
            interval["error"] = f"{type(error).__name__}: {error}"

    sampler = None
    try:
        counters.prepare_child(process)
        if args.sample_seconds is not None:
            sampler = threading.Thread(target=sample_interval, daemon=True)
            sampler.start()
        application_cpu = counters.wait(process)
    finally:
        if process.returncode is None:
            process.kill()
            process.wait()
        wall = time.monotonic() - started
        stopped.set()
        if sampler:
            sampler.join()
    report = {
        "scope": "CPU during child lifetime, including startup; not presentation timing",
        "platform": platform.platform(), "note": args.note,
        "excluded_costs": ["compositor", "GPU", "unselected helper processes"],
        "command": args.command,
        "binary_sha256": binary_hash,
        "status": process.returncode, "wall_seconds": wall,
        "terminal_pid": args.terminal_pid, "terminal_process": terminal_name,
        "application_cpu_seconds": application_cpu,
        "application_cpu_ms_per_second": application_cpu / wall * 1000,
        **counters.metadata,
    }
    try:
        after = counters.snapshot(args.terminal_pid)
        terminal_cpu = cpu_delta(before, after)
        report.update(terminal_cpu_seconds=terminal_cpu,
                      terminal_cpu_ms_per_second=terminal_cpu / wall * 1000)
        if after.idle_wakes is not None:
            report["terminal_idle_wakeups"] = after.idle_wakes - before.idle_wakes
    except (OSError, RuntimeError) as error:
        report["terminal_error"] = str(error)
    if args.helper_pid:
        helpers = helper_sample(helpers_before, wall)
        for sample in helpers["processes"]:
            sample["process"] = helper_names[sample["pid"]]
        report["terminal_helpers"] = helpers
    if args.sample_seconds is not None:
        report["interval_sample"] = interval
    report["measurement_valid"] = (
        "terminal_error" not in report and "error" not in interval
        and all("cpu_seconds" in sample for sample in
                [report.get("terminal_helpers", {}), interval.get("terminal_helpers", {})]
                if "processes" in sample))
    return report


if __name__ == "__main__":
    main()
