import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).parent
stage = work.parent / 'iterm-shm-evidence'
stage.mkdir()

def copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

for folder in ('cpu', 'visible', 'events', 'final-visible'):
    shutil.copytree(work / folder, stage / 'candidate' / folder)
for source in sorted(work.iterdir()):
    if source.is_file() and source.suffix in ('.log', '.py', '.json', '.txt'):
        copy(source, stage / 'candidate' / source.name)

probe = work.parent / 'iterm-shm-probe'
for source in sorted(probe.rglob('*')):
    if source.is_file() and source.suffix in ('.log', '.py', '.json', '.txt', '.md'):
        copy(source, stage / 'probe' / source.relative_to(probe))
copy(work.parent / 'iterm-kitty-compression/corpus-data/default-060.644x748.rgba',
     stage / 'iterm-kitty-compression/corpus-data/default-060.644x748.rgba')

for source in sorted(stage.rglob('*-screenshot.txt')):
    shot = Path(source.read_text().strip())
    assert shot.is_file(), shot
    copy(shot, source.with_suffix('.png'))

changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
source_paths = sorted(p for p in set(changed + untracked) if p.startswith(('src/', 'tests/', 'tools/')))
for name in source_paths:
    copy(root / name, stage / 'source' / name)
for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'tools/presentation-capture.swift',
             'tools/process_usage.py', 'tools/terminal-perf.py', 'tools/trace-report.py',
             'target/live-perf/run-iterm.scpt', 'target/live-perf/completion-exec.py'):
    copy(root / name, stage / 'source' / name)
(stage / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', 'src', 'tests', 'tools'], cwd=root))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

metadata = {
    'parent_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'executables_sha256': {name: sha(work / name) for name in ('before-rbirds', 'candidate-rbirds', 'final-rbirds')},
    'source_files': source_paths,
    'new_source_files': sorted(set(source_paths) & set(untracked)),
    'cpu_and_initial_capture_executable': 'candidate-rbirds',
    'control_and_final_dense_capture_executable': 'final-rbirds',
    'hardware': 'Apple M4 Pro',
    'os': subprocess.check_output(['sw_vers'], text=True),
    'terminal': 'iTerm2 3.6.6',
    'rust': subprocess.check_output(['rustc', '-vV'], cwd=root, text=True),
}
(stage / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
(stage / 'README.txt').write_text('''Local iTerm shared-image transport, 2026-09-27

The companion Markdown report explains scope and limitations. This archive
contains observations, not a promise of future physical display timing.

candidate/cpu contains eight valid foreground ABBA CPU samples with 3-second
warm-up and 15-second equal intervals. No capture, build or test ran during
those intervals. Both default and dense scenes explicitly select Kitty.
candidate/visible has separate initial 10-second captures. Some builds/tests
ran during those captures; do not use their CPU traces as quiet comparisons.
candidate/final-visible repeats the dense capture with the final source while
no build or test was running. candidate/events exercises pause, single-step,
panel hiding, resize and resume; its deliberate pauses are not pacing faults.
ScreenCaptureKit compares all content pixels at the configured logical window
resolution. Color and blank-frame diagnostics use the retained sample grid.

before-rbirds is the parent commit. candidate-rbirds was measured before final
startup, reply-input and cleanup hardening. final-rbirds includes that hardening.
Hashes identify them; executables are not included. source.patch contains tracked
source changes relative to metadata.json's parent, and source/ includes every
changed and new source file. metadata.json identifies new files to copy after
applying the patch. The branch commit is the simplest way to rebuild the result.

late-reply-tests-debug.log and late-reply-tests-release.log cover final native
library, terminal, shared-image, C simulation and allocation tests. The debug
run also includes native ABI and broader terminal lifecycle/Sixel cases.
late-reply-rosetta.log covers final relevant Intel macOS release tests.
late-reply-clippy.log and late-reply-build.log record final Clippy/build success.
Earlier debug-final.log is a complete native debug run before late-reply input
filtering. verify-native.log retains the first full gate run, including a debug
fixture-label failure; its release and other gates passed. Later logs show that
fixture fixed. Initial resource and terminal-double failures are also retained.

probe/ is the earlier static capability experiment and its original notes.
Its no-production-change statement describes that earlier stage. The fixture
is in iterm-kitty-compression/corpus-data, matching the script's relative path.
Probe timing is one-shot feasibility evidence, not a CPU comparison.
xnu-source-audit.json records pinned URLs and hashes for the syscall audit;
external XNU source files are not copied here.

Drivers retain original local paths and process/window IDs for provenance.
Use fresh output directories, matching terminal geometry and currently owned
processes when adapting them. Only rbirds-perf test windows were controlled.
Screenshots contain those windows. No installed executable or terminal setting
was replaced. The final visible runs exited with status zero and closed their
owned windows.
''')
manifest = {str(p.relative_to(stage)): sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}
(stage / 'SHA256.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'docs/evidence/live-iterm-shm-2026-09-27-macos-arm64.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(stage, arcname='iterm-shm-evidence')
with tarfile.open(archive) as tar:
    for name, expected in manifest.items():
        content = tar.extractfile('iterm-shm-evidence/' + name).read()
        assert hashlib.sha256(content).hexdigest() == expected, name
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                  'sha256': sha(archive), 'files_verified': len(manifest)}, indent=2))
