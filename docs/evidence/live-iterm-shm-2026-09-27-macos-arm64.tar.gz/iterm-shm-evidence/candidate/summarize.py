import hashlib
import importlib.util
import json
from pathlib import Path
import statistics

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).parent
spec = importlib.util.spec_from_file_location('trace_report', root / 'tools/trace-report.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result = {}
for scene in ('default', 'dense'):
    rows = []
    for path in sorted((work / 'cpu' / scene).glob('*/cpu.json')):
        report = json.loads(path.read_text())
        sample = report['interval_sample']
        assert report['measurement_valid'] and report['status'] == 0
        app = sample['application_cpu_ms_per_second']
        terminal = sample['terminal_cpu_ms_per_second']
        helper = sample['terminal_helpers']['cpu_ms_per_second']
        trace = module.summarize(path.with_name('trace.jsonl'), 3)
        rows.append({'run': path.parent.name, 'application': app, 'terminal': terminal,
                     'helper': helper, 'combined': app + terminal + helper,
                     'application_cpu_ms_per_frame': trace['live_cpu_ms_per_frame'],
                     'frame_interval_ms': trace['interval_ms_after_warmup'],
                     'stage_ms': trace['stage_ms_after_warmup']})
    assert len(rows) == 4
    medians = {variant: {key: statistics.median(row[key] for row in rows if variant in row['run'])
                        for key in ('application', 'terminal', 'helper', 'combined', 'application_cpu_ms_per_frame')}
               for variant in ('before', 'after')}
    result[scene] = {'runs': rows, 'medians': medians}
(work / 'cpu-summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({scene: data['medians'] for scene, data in result.items()}, indent=2))
if (work / 'visible').exists():
    presentation = {}
    for path in sorted((work / 'visible').glob('*-presentation.json')):
        report = json.loads(path.read_text());frames = report['frames']
        times = [f['pts'] for f in frames if f['changed']]
        gaps = [(b - a) * 1000 for a, b in zip(times, times[1:])]
        presentation[path.stem] = {
            'samples': len(frames), 'changed_hz': (len(times)-1)/(times[-1]-times[0]),
            'gap_ms': module.distribution(gaps),
            'near_blank_samples': sum(f['dominant_fraction'] > .999 for f in frames),
            'bright_background_samples': sum(f['dominant_rgb'][0] > 70 and f['dominant_fraction'] > .8 for f in frames),
            'capture_cpu_seconds': report['capture_cpu_seconds']}
    (work / 'presentation-summary.json').write_text(json.dumps(presentation, indent=2) + '\n')
    print(json.dumps(presentation, indent=2))
