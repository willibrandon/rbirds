import json
import shlex
import subprocess
import time
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = root / 'target/live-perf/iterm-shm-candidate'
for scene in ['default', 'dense']:
    for index, variant in enumerate(['before', 'after', 'after', 'before']):
        out = work / 'cpu' / scene / f'{index}-{variant}'
        out.mkdir(parents=True)
        name = f'rbirds-perf-iterm-shm-candidate-{scene}-{index}-{variant}'
        binary = work / ('before-rbirds' if variant == 'before' else 'candidate-rbirds')
        extra = [] if scene == 'default' else ['--birds', '4096', '--speed', '12', '--hawks', '4', '--flocks', '3', '--depth', '--trails', '--color', 'ember']
        command = shlex.join([
            '/usr/bin/env', 'RBIRDS_TRACE=' + str(out / 'trace.jsonl'),
            '/opt/homebrew/bin/python3', str(root / 'target/live-perf/completion-exec.py'),
            name, str(out / 'completed.json'),
            '/opt/homebrew/bin/python3', str(root / 'tools/terminal-perf.py'),
            '--terminal-pid', '73499', '--helper-pid', '24604',
            '--warmup-seconds', '3', '--sample-seconds', '15',
            '--note', 'Foreground owned 100x32 iTerm 3.6.6 window; ABBA compressed inline frames versus negotiated POSIX shared RGBA images; no capture, profiler, builds or tests; shared main terminal and stable image decoder helper',
            '--output', str(out / 'cpu.json'), '--', str(binary),
            '--render', 'kitty', '--seed', '42', '--frames', '1200', *extra])
        window = int(subprocess.check_output(['osascript', str(root / 'target/live-perf/run-iterm.scpt'), command, name], text=True))
        (out / 'window.txt').write_text(str(window) + '\n')
        print(scene, index, variant, 'window', window, flush=True)
        for _ in range(600):
            if (out / 'completed.json').exists():
                completion = json.loads((out / 'completed.json').read_text())
                assert completion['status'] == 0, completion
                break
            time.sleep(.5)
        else:
            raise RuntimeError('finite child has not completed; leave its window for inspection')
        report = json.loads((out / 'cpu.json').read_text())
        assert report['measurement_valid'], report
        subprocess.run(['osascript', '-e', f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'], check=True)
        print(scene, index, variant, 'done', flush=True)
