Local iTerm shared-image transport, 2026-09-27

The companion Markdown report explains scope and limitations. This archive
contains observations, not a promise of future physical display timing.

candidate/cpu contains eight valid foreground ABBA CPU samples with 3-second
warm-up and 15-second equal intervals. No capture, build or test ran during
those intervals. Both default and dense scenes explicitly select Kitty.
candidate/visible has separate initial 10-second captures. Some builds/tests
ran during those captures; do not use their CPU traces as quiet comparisons.
candidate/final-visible repeats the dense capture with the final source while
no build or test was running. candidate/events exercises pause, single-step,
panel hiding, resize and resume; its deliberate pauses are not pacing faults.
ScreenCaptureKit compares all content pixels at the configured logical window
resolution. Color and blank-frame diagnostics use the retained sample grid.

before-rbirds is the parent commit. candidate-rbirds was measured before final
startup, reply-input and cleanup hardening. final-rbirds includes that hardening.
Hashes identify them; executables are not included. source.patch contains tracked
source changes relative to metadata.json's parent, and source/ includes every
changed and new source file. metadata.json identifies new files to copy after
applying the patch. The branch commit is the simplest way to rebuild the result.

late-reply-tests-debug.log and late-reply-tests-release.log cover final native
library, terminal, shared-image, C simulation and allocation tests. The debug
run also includes native ABI and broader terminal lifecycle/Sixel cases.
late-reply-rosetta.log covers final relevant Intel macOS release tests.
late-reply-clippy.log and late-reply-build.log record final Clippy/build success.
Earlier debug-final.log is a complete native debug run before late-reply input
filtering. verify-native.log retains the first full gate run, including a debug
fixture-label failure; its release and other gates passed. Later logs show that
fixture fixed. Initial resource and terminal-double failures are also retained.

probe/ is the earlier static capability experiment and its original notes.
Its no-production-change statement describes that earlier stage. The fixture
is in iterm-kitty-compression/corpus-data, matching the script's relative path.
Probe timing is one-shot feasibility evidence, not a CPU comparison.
xnu-source-audit.json records pinned URLs and hashes for the syscall audit;
external XNU source files are not copied here.

Drivers retain original local paths and process/window IDs for provenance.
Use fresh output directories, matching terminal geometry and currently owned
processes when adapting them. Only rbirds-perf test windows were controlled.
Screenshots contain those windows. No installed executable or terminal setting
was replaced. The final visible runs exited with status zero and closed their
owned windows.
