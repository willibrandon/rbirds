import base64
import ctypes
import errno
import json
import mmap
import os
from pathlib import Path
import select
import termios
import time
import tty
import uuid
import zlib

work = Path(__file__).parent
image = work.parent / 'iterm-kitty-compression/corpus-data/default-060.644x748.rgba'
pixels = image.read_bytes()
assert len(pixels) == 644 * 748 * 4
libc = ctypes.CDLL(None, use_errno=True)
# Darwin's declaration is variadic; Apple arm64 passes mode on the stack.
libc.shm_open.argtypes = [ctypes.c_char_p, ctypes.c_int]
libc.shm_open.restype = ctypes.c_int
libc.shm_unlink.argtypes = [ctypes.c_char_p]
libc.shm_unlink.restype = ctypes.c_int
names = []
results = []

def write(data):
    while data:
        count = os.write(1, data)
        assert count > 0
        data = data[count:]

def command(fields, payload=b''):
    write(b'\x1b_G' + fields.encode() + b';' + payload + b'\x1b\\')

def response(identifier, allow_zero=False):
    data = b''
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if select.select([0], [], [], max(0, deadline - time.monotonic()))[0]:
            data += os.read(0, 4096)
            prefix = f'\x1b_Gi={identifier};'.encode()
            if (prefix in data or (allow_zero and b'\x1b_Gi=0;' in data)) and data.endswith(b'\x1b\\'):
                return data
    raise RuntimeError(f'No complete reply for {identifier}: {data!r}')

original = termios.tcgetattr(0)
try:
    tty.setraw(0)
    write(b'\x1b[?1049h\x1b[?25l\x1b[48;2;18;18;23m\x1b[2J\x1b[H')
    for index, medium in enumerate(('direct', 'shared')):
        identifier = 8801 + index
        start = time.monotonic()
        if medium == 'direct':
            payload = base64.b64encode(zlib.compress(pixels))
            for offset in range(0, len(payload), 4096):
                chunk = payload[offset:offset + 4096]
                more = int(offset + 4096 < len(payload))
                fields = f'a=t,i={identifier},f=32,s=644,v=748,o=z,m={more}' if offset == 0 else f'm={more}'
                command(fields, chunk)
        else:
            name = ('/rb-probe-' + uuid.uuid4().hex[:16]).encode()
            names.append(name)
            fd = libc.shm_open(name, os.O_CREAT | os.O_EXCL | os.O_RDWR, ctypes.c_uint(0o600))
            if fd < 0:
                raise OSError(ctypes.get_errno(), 'shm_open')
            try:
                assert os.fstat(fd).st_mode & 0o777 == 0o600
                os.ftruncate(fd, len(pixels))
                with mmap.mmap(fd, len(pixels)) as memory:
                    memory[:] = pixels
                command(f'a=t,i={identifier},f=32,s=644,v=748,t=s', base64.b64encode(name))
            finally:
                os.close(fd)
        reply = response(identifier, allow_zero=medium == 'direct')
        row = {'medium': medium, 'reply': repr(reply), 'elapsed_seconds': time.monotonic() - start}
        if medium == 'shared':
            check = libc.shm_open(name, os.O_RDONLY, 0)
            row['terminal_unlinked'] = check < 0 and ctypes.get_errno() == errno.ENOENT
            if check >= 0:
                os.close(check)
        results.append(row)
        (work / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        accepted = [f'\x1b_Gi={identifier};OK\x1b\\'.encode()]
        if medium == 'direct':
            accepted.append(b'\x1b_Gi=0;OK\x1b\\')
        assert reply in accepted, reply
        write(b'\x1b[?2026h')
        if index:
            command(f'a=d,d=I,i={identifier - 1},q=2')
        write(b'\x1b[H')
        command(f'a=p,i={identifier},p=1,C=1,z=1,q=2')
        write(b'\x1b[?2026l')
        (work / (medium + '-ready')).touch()
        deadline = time.monotonic() + 30
        while not (work / (medium + '-continue')).exists():
            if time.monotonic() >= deadline:
                raise RuntimeError('Screenshot driver timed out')
            time.sleep(.05)
finally:
    for name in names:
        libc.shm_unlink(name)
    write(b'\x1b_Ga=d,d=A,q=2;\x1b\\\x1b[0m\x1b[?25h\x1b[?1049l')
    termios.tcsetattr(0, termios.TCSANOW, original)
