import json
from pathlib import Path
import shlex
import subprocess
import time

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).parent
title = 'rbirds-perf-iterm-shm-probe'
command = shlex.join(['/opt/homebrew/bin/python3', str(root / 'target/live-perf/completion-exec.py'), title,
                     str(work / 'completed.json'), '/opt/homebrew/bin/python3', str(work / 'probe.py')])
window = int(subprocess.check_output(['osascript', str(root / 'target/live-perf/run-iterm.scpt'), command, title], text=True))
(work / 'window.txt').write_text(str(window) + '\n')
print('own window', window, flush=True)
for phase in ('direct', 'shared'):
    deadline = time.monotonic() + 35
    while not (work / (phase + '-ready')).exists():
        assert not (work / 'completed.json').exists(), (work / 'completed.json').read_text()
        assert time.monotonic() < deadline, 'probe timed out'
        time.sleep(.1)
    time.sleep(1)
    screenshot = subprocess.check_output(['/opt/homebrew/bin/python3', '/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py',
                                         '--app', 'iTerm2', '--window-name', title, '--mode', 'temp'], text=True)
    (work / (phase + '-screenshot.txt')).write_text(screenshot)
    print(phase, screenshot.strip(), flush=True)
    (work / (phase + '-continue')).touch()
for _ in range(100):
    if (work / 'completed.json').exists():
        result = json.loads((work / 'completed.json').read_text())
        assert result['status'] == 0, result
        subprocess.run(['osascript', '-e', f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'], check=True)
        print((work / 'results.json').read_text(), flush=True)
        break
    time.sleep(.1)
else:
    raise RuntimeError('probe did not finish')
