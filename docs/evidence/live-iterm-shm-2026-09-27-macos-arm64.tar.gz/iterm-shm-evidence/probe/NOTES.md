# iTerm shared-memory capability probe

The corrected Python probe succeeds on iTerm2 3.6.6. A raw RGBA surface of
644 by 748 pixels is accepted with `a=t,t=s,f=32,i=8802,s=644,v=748`; the
payload is the base64-encoded POSIX object name. The terminal replies `OK`
and unlinks the object after reading it. The created object has mode 0600.
The probe closes all descriptors, unmaps its writer, and attempts final unlink
on exit. Own windows 22130, 22132 and 22136 were closed after their finite runs.

The screenshot comparison against the same surface sent through compressed
inline Kitty commands found zero differing content pixels. The direct screenshot
was visually inspected. This establishes static transport feasibility only.
The reported one-frame elapsed times are not a live CPU or pacing comparison.

Two initial probe failures are retained. Chunked inline uploads receive i=0 in
the reply from iTerm's final continuation command, despite storing the image
under its original ID. The second failure was in the probe: Darwin declares
shm_open as variadic. Declaring its mode argument as fixed in ctypes passes it
incorrectly on Apple arm64 and created an object with wrong permissions. With
only the first two argument types declared and an explicit variadic c_uint mode,
creation has the expected permissions and iTerm can read it. This was not an
iTerm access restriction. The SDK sys/mman.h declaration was checked directly.

The installed iTerm source is cached in ../iterm-kitty-ids/KittyImageController.swift
from tag v3.6.6. Its shared-memory and file paths pass bytes straight to raw/PNG
decoding, without the inline path's inflation. Send raw RGBA on this version.
The cached NSFileManager+iTerm.m wrapper simply calls shm_open.
The official protocol documents negotiation with a=q and requires terminals to
unlink a POSIX shared-memory object after reading it:
https://sw.kovidgoyal.net/kitty/graphics-protocol/#the-transmission-medium

No production source uses shared memory yet. A candidate would need a successful
startup query with an owned object, the existing inline fallback for remote or
unsupported terminals, bounded outstanding objects, and cleanup on errors,
interrupted output and signals. Existing signal handlers call _exit directly,
so Rust Drop alone would not cover them. Do not put an unreviewed non-async-safe
cleanup routine on that path. Preserve the alternating image IDs that avoid
invalidating the displayed frame. Confirm moving-scene pixels, presentation,
CPU and resource cleanup before retaining the candidate.

The pushed output-cursor change is 3f324d32f6e727af32613cf293a68c4a4db2a701.
Its CI run is 36304326729. Both macOS pixel-comparison self-tests passed while
the broader jobs were still running. Earlier head be3bdc5 passed all seven jobs.
