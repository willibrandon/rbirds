import hashlib,json,shutil,tarfile
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
stage=work/'evidence';stage.mkdir()
names=[str(p.relative_to(work)) for p in work.iterdir() if p.is_file() and p.suffix in ['.py','.rs','.json','.lua','.log','.diff']]
names += [str(p.relative_to(work)) for name in ['static','corner','replay','replay2','replay3','cpu','visible','iterm-confirmation']
          for p in sorted((work/name).rglob('*')) if p.is_file() and p.suffix in ['.bin','.png','.json','.jsonl','.txt','.text','.err']]
for name in names:
    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(work/name,target)
for name in ['src/render/sixel.rs','src/render/compose.rs','src/render/mod.rs','src/terminal.rs','src/live.rs',
             'src/platform/windows_tests.rs','tests/sixel.rs','tests/pty_sixel.rs','examples/fixed-scene.rs',
             'tools/terminal-perf.py','tools/process_usage.py','tools/presentation-capture.swift',
             'target/live-perf/completion-exec.py','target/live-perf/run-iterm.scpt']:
    target=stage/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target)
for index in [8,9]:
    target=stage/'previous-static'/f'{index}.bin';target.parent.mkdir(exist_ok=True)
    shutil.copy2(work.parent/'wezterm-crop/static-fixed'/f'{index}.bin',target)
manifest={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root/'docs/evidence/live-wezterm-placement-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(stage,arcname='wezterm-placement')
with tarfile.open(archive,'r:gz') as tar:
    for name,expected in manifest.items():assert hashlib.sha256(tar.extractfile('wezterm-placement/'+name).read()).hexdigest()==expected,name
result={'files':len(manifest),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(work/'archive.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
