import json,os,shutil,subprocess,time
from pathlib import Path
work=Path(__file__).resolve().parent;output=work/'replay';output.mkdir()
session=json.loads((work/'session.json').read_text());pid=session['terminal_pid']
title='rbirds-perf-wezterm-replay'
assert not(work/'child.json').exists()
(work/'job.json').write_text(json.dumps({'title':title,'command':['/usr/bin/python3',str(work/'replay.py')],'completed':str(output/'completed.json')}))
time.sleep(.3)
subprocess.run(['osascript','-e',f'tell application "System Events" to tell (first application process whose unix id is {pid})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{title}")\nend tell'],check=True)
for index in range(7):
    deadline=time.monotonic()+30
    while not(output/'ready').exists() or (output/'ready').read_text()!=str(index):
        if time.monotonic()>deadline:raise TimeoutError(index)
        time.sleep(.05)
    path=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','WezTerm','--window-name',title,'--mode','temp'],text=True).strip()
    shutil.copy2(path,output/f'{index}.png')
    env=os.environ.copy();env['WEZTERM_UNIX_SOCKET']=session['socket']
    result=subprocess.run(['/Applications/WezTerm.app/Contents/MacOS/wezterm','cli','get-text','--escapes','--pane-id',session['pane_id']],env=env,capture_output=True)
    (output/f'{index}.text').write_bytes(result.stdout);(output/f'{index}.err').write_bytes(result.stderr)
    print(index,path,'get-text',result.returncode,flush=True)
    (output/'ack').write_text(str(index))
