"""Compare captured Sixel pixels against an independent RGB-percent decoder."""
import json, re
from pathlib import Path
import numpy as np
from PIL import Image

def decode(data, definitions_select):
    data = re.search(rb'\x1bP0;1q"1;1;(\d+);(\d+)(.*?)\x1b\\', data, re.S)
    width, height = map(int, data.group(1, 2))
    data = data[3]
    pixels = np.zeros((height, width, 3), dtype=np.uint8)
    covered = np.zeros((height, width), dtype=bool)
    palette = {}
    foreground = (0, 255, 0)
    x = y = at = 0
    def number():
        nonlocal at
        match = re.match(rb'\d+', data[at:])
        assert match
        at += match.end()
        return int(match[0])
    while at < len(data):
        ch = data[at]; at += 1
        if ch == 35:
            colour = number()
            if at < len(data) and data[at] == 59:
                at += 1
                assert number() == 2
                channels = []
                for _ in range(3):
                    assert data[at] == 59; at += 1
                    channels.append(number() * 255 // 100)
                palette[colour] = tuple(channels)
                if definitions_select: foreground = palette[colour]
            else: foreground = palette[colour]
        elif ch == 36: x = 0
        elif ch == 45: x = 0; y += 6
        else:
            count = 1
            if ch == 33:
                count = number(); ch = data[at]; at += 1
            assert 63 <= ch <= 126
            for bit in range(6):
                if (ch - 63) & (1 << bit):
                    assert y + bit < height and x + count <= width
                    pixels[y+bit, x:x+count] = foreground
                    covered[y+bit, x:x+count] = True
            x += count
    assert covered.all()
    return pixels

