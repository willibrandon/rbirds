import os, re, termios, tty, time
from pathlib import Path
work = Path(__file__).resolve().parent
output = work / 'replay3'
source = work.parent / 'wezterm-crop/static-fixed'
full = (source / '8.bin').read_bytes()
crop = (source / '9.bin').read_bytes()
marker = b'\x1b[?80h\x1b[H'
start = crop.index(b'\x1bP')
# Replace just the opaque ground-fill commands, keeping the positioned raster.
position = re.search(rb'\x1b\[\?80l\x1b\[(\d+);(\d+)H$', crop[:start])
assert position
params = re.search(rb'\x1bP0;1q"1;1;(\d+);(\d+)', crop)
width,height = map(int, params.group(1,2))
row,col = map(int, position.group(1,2))
clear = b''.join(f'\x1b[{r};{col}H\x1b[{width//14}X'.encode() for r in range(row,row+height//33))
floor = crop.replace(b'38;2;18;18;23m', b'38;2;17;17;22m')
finish = floor.replace(b'\x1b[79b', '\x1b[78b█'.encode())
variants = [full, floor, finish]
original = termios.tcgetattr(0)
try:
    tty.setraw(0)
    os.write(1,b'\x1b[?1049h\x1b[?25l')
    for i,data in enumerate(variants):
        os.write(1,b'\x1b[0m'+data)
        (output/f'{i}.bin').write_bytes(data)
        time.sleep(.5)
        (output/'ready').write_text(str(i))
        until=time.monotonic()+30
        while not (output/'ack').exists() or (output/'ack').read_text()!=str(i):
            if time.monotonic()>until: raise TimeoutError(i)
            time.sleep(.05)
finally:
    os.write(1,b'\x1b[?2026l\x1b[?80l\x1b[0m\x1b[?25h\x1b[?1049l')
    termios.tcsetattr(0,termios.TCSANOW,original)
