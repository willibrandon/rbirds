import collections, importlib.util, json, math, statistics
from pathlib import Path
import numpy as np
from PIL import Image
from decode import decode
work=Path(__file__).resolve().parent
def save(name,value): (work/name).write_text(json.dumps(value,indent=2)+'\n')
result=[]
for i in range(0,14,2):
    a=np.asarray(Image.open(work/'static'/f'{i}.png').convert('RGBA'))
    b=np.asarray(Image.open(work/'static'/f'{i+1}.png').convert('RGBA'))
    diff=np.any(a!=b,axis=2);yy,xx=np.where(diff)
    row={'full':i,'crop':i+1,'different_pixels':int(diff.sum()),
         'bounds':None if not diff.any() else [int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]}
    if i==2:
        # Inspect an unobscured part of the bottom-right cell separately from
        # the macOS rounded window corner. The full raster leaves it blank.
        expected=decode((work/'static'/'2.bin').read_bytes(),False)
        area=expected[1023:1033,1386:1394]
        row['corner_interior_pixels']=int(area.shape[0]*area.shape[1])
        for key,shot in [('full',a),('crop',b)]:
            row[key+'_corner_mismatches']=int(np.any(shot[1155:1165,1498:1506,:3]!=area,axis=2).sum())
        assert row['crop_corner_mismatches']==0 and row['full_corner_mismatches']==80
        assert row['different_pixels']==333
    else: assert not diff.any()
    result.append(row)
save('static-summary.json',result)
spec=importlib.util.spec_from_file_location('compare',work/'compare-fixed-scenes.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
out={}
for case in ['normal','dense']:
    paths=sorted((work/'cpu').glob(case+'-*/cpu.json'))
    comparison=mod.compare([json.loads(path.read_text()) for path in paths])
    groups={v:[r for p,r in zip(paths,comparison['runs']) if v in p.parent.name] for v in ['baseline','candidate']}
    summary={v:{'combined_ms_per_frame':statistics.mean(r['cpu_ms_per_frame']['combined'] for r in rows),
                'application_ms_per_frame':statistics.mean(r['cpu_ms_per_frame']['application'] for r in rows),
                'terminal_ms_per_frame':statistics.mean(r['cpu_ms_per_frame']['terminal'] for r in rows),
                'combined_cpu_percent':statistics.mean(r['cpu_ms_per_second']['combined']/10 for r in rows),
                'submitted_hz':statistics.mean(600/r['wall_seconds'] for r in rows)} for v,rows in groups.items()}
    summary['cpu_per_frame_change_percent']=(summary['candidate']['combined_ms_per_frame']/summary['baseline']['combined_ms_per_frame']-1)*100
    out[case]={'comparison':comparison,'summary':summary}
save('cpu-summary.json',out)
out={}
paths=sorted((work/'visible').glob('*/presentation.json'))+[work/'iterm-confirmation/candidate-presentation.json']
for path in paths:
    capture=json.loads(path.read_text());frames=capture['frames']
    times=[f['pts'] for f in frames if f['changed']]
    gaps=sorted((b-a)*1000 for a,b in zip(times,times[1:]))
    row={'samples':len(frames),'dominant_rgb':collections.Counter(str(f['dominant_rgb']) for f in frames),
         'visible_hz':(len(times)-1)/(times[-1]-times[0]),'p99_gap_ms':gaps[math.ceil(len(gaps)*.99)-1],
         'max_gap_ms':max(gaps),'gaps_over_50_ms':sum(g>50 for g in gaps),
         'focus_samples':len(capture['focus_observations']),
         'focus':all(f['owner_active'] and f['top_normal_window'] for f in capture['focus_observations'])}
    assert row['focus']
    out[str(path.relative_to(work))]=row
save('presentation-summary.json',out)
print(json.dumps({'cpu':{k:v['summary'] for k,v in json.loads((work/'cpu-summary.json').read_text()).items()},'presentation':out},indent=2))
