import fcntl, json, os, struct, subprocess, time
from pathlib import Path
work = Path(__file__).resolve().parent
os.write(1, b'\x1b]0;rbirds-perf-wezterm-idle\x07')
(work / 'session.json').write_text(json.dumps({'pid': os.getpid(), 'terminal_pid': os.getppid(),
    'socket': os.environ.get('WEZTERM_UNIX_SOCKET'), 'pane_id': os.environ.get('WEZTERM_PANE'), 'size': struct.unpack('HHHH', fcntl.ioctl(1, __import__('termios').TIOCGWINSZ, b'\0' * 8))}) + '\n')
while not (work / 'stop-session').exists():
    request = work / 'job.json'
    if not request.exists():
        time.sleep(.1)
        continue
    job = json.loads(request.read_text())
    request.unlink()
    assert job['title'].startswith('rbirds-perf-')
    os.write(1, ('\x1b]0;' + job['title'] + '\x07').encode())
    output = Path(job['completed'])
    with (output.parent / 'stderr.txt').open('w') as errors:
        child = subprocess.Popen(job['command'], stderr=errors)
        (work / 'child.json').write_text(json.dumps({'pid': child.pid, 'command': job['command']}) + '\n')
        status = child.wait()
    (work / 'child.json').unlink()
    temp = output.with_suffix('.tmp')
    temp.write_text(json.dumps({'status': status, 'command': job['command']}) + '\n')
    temp.replace(output)
