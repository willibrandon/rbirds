import json, subprocess, time
from pathlib import Path
work = Path(__file__).resolve().parent
command = ['/Applications/WezTerm.app/Contents/MacOS/wezterm-gui', '--config-file', str(work / 'config.lua'),
           'start', '--always-new-process', '--no-auto-connect', '--position', 'main:40,40',
           '--', '/usr/bin/python3', str(work / 'session.py')]
with (work / 'gui.stdout').open('w') as out, (work / 'gui.stderr').open('w') as err:
    process = subprocess.Popen(command, stdout=out, stderr=err)
    (work / 'launch.json').write_text(json.dumps({'pid': process.pid, 'command': command}, indent=2) + '\n')
    deadline = time.monotonic() + 20
    while not (work / 'session.json').exists():
        if process.poll() is not None or time.monotonic() >= deadline:
            raise RuntimeError('owned WezTerm did not start')
        time.sleep(.1)
session = json.loads((work / 'session.json').read_text())
print(session)
pid = session['terminal_pid']
assert subprocess.check_output(['ps', '-p', str(pid), '-o', 'comm='], text=True).strip().endswith('/wezterm-gui')
subprocess.run(['osascript', '-e', f'tell application "System Events" to tell (first application process whose unix id is {pid})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "rbirds-perf-wezterm-idle")\nend tell'], check=True)
(work / 'job.json').write_text(json.dumps({'title': 'rbirds-perf-wezterm-capabilities', 'command': ['/usr/bin/python3', str(work / 'caps.py')], 'completed': str(work / 'caps-completed.json')}))
deadline = time.monotonic() + 10
while not (work / 'caps-completed.json').exists():
    if time.monotonic() > deadline:
        raise TimeoutError('capability check')
    time.sleep(.1)
print((work / 'capabilities.json').read_text(), flush=True)
raise SystemExit(process.wait())
