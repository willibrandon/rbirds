import os, re, termios, tty, time
from pathlib import Path
work = Path(__file__).resolve().parent
output = work / 'corner'
source = work / 'static'
full=(source/'2.bin').read_bytes();crop=(source/'3.bin').read_bytes()
blank=(source/'6.bin').read_bytes();ground=(source/'7.bin').read_bytes()
# Preserve raw frames; then isolate cursor movement and the last cell.
variants=[full,crop,blank,ground,
 ground.replace(b'\x1b[0m\x1b[H',b'\x1b[H\x1b[0m'),
 ground.replace(b'\x1b[?2026l', '\x1b[32;100H█\x1b[H\x1b[?2026l'.encode()),
 full.replace(b'\x1b[?2026l',b'\x1b[10;10H\x1b[?2026l'),
 crop.replace(b'\x1b[?2026l',b'\x1b[10;10H\x1b[?2026l')]
original = termios.tcgetattr(0)
try:
    tty.setraw(0)
    os.write(1,b'\x1b[?1049h\x1b[?25l')
    for i,data in enumerate(variants):
        os.write(1,b'\x1b[0m'+data)
        (output/f'{i}.bin').write_bytes(data)
        time.sleep(.5)
        (output/'ready').write_text(str(i))
        until=time.monotonic()+30
        while not (output/'ack').exists() or (output/'ack').read_text()!=str(i):
            if time.monotonic()>until: raise TimeoutError(i)
            time.sleep(.05)
finally:
    os.write(1,b'\x1b[?2026l\x1b[?80l\x1b[0m\x1b[?25h\x1b[?1049l')
    termios.tcsetattr(0,termios.TCSANOW,original)
