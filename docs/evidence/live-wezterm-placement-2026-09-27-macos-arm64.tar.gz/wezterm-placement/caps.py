import fcntl, json, os, select, struct, termios, time, tty
from pathlib import Path
work = Path(__file__).resolve().parent
before = termios.tcgetattr(0)
report = {'geometry': struct.unpack('HHHH', fcntl.ioctl(1, termios.TIOCGWINSZ, b'\0' * 8)), 'queries': []}
def query(request):
    os.write(1, request)
    deadline = time.monotonic() + .3
    reply = b''
    while time.monotonic() < deadline:
        if select.select([0], [], [], max(0, deadline - time.monotonic()))[0]:
            reply += os.read(0, 1024)
    report['queries'].append({'query': repr(request), 'reply': repr(reply)})
try:
    tty.setraw(0)
    for request in [b'\x1b[c', b'\x1b[16t', b'\x1b[>q', b'\x1b[?80$p', b'\x1b[?2026$p']:
        query(request)
    os.write(1, b'\x1b[?1049h\x1b[?2026h\x1b[H\x1b[8m')
    query('█\x1b[6n'.encode())
finally:
    os.write(1, b'\x1b[0m\x1b[2J\x1b[H\x1b[?2026l\x1b[?1049l')
    termios.tcsetattr(0, termios.TCSANOW, before)
(work / 'capabilities.json').write_text(json.dumps(report, indent=2) + '\n')
