Static Sixel captures and the transparency probe.

- [0-after-screenshot](/var/folders/gl/8s1nx14n53j_b_stzr2pvv6r0000gn/T/codex-shot-2026-09-26_21-46-32.png)
- [0-before-screenshot](/var/folders/gl/8s1nx14n53j_b_stzr2pvv6r0000gn/T/codex-shot-2026-09-26_21-46-21.png)
- [0.5-after-screenshot](/var/folders/gl/8s1nx14n53j_b_stzr2pvv6r0000gn/T/codex-shot-2026-09-26_21-46-53.png)
- [0.5-before-screenshot](/var/folders/gl/8s1nx14n53j_b_stzr2pvv6r0000gn/T/codex-shot-2026-09-26_21-46-43.png)
- [Opaque backdrop probe](/var/folders/gl/8s1nx14n53j_b_stzr2pvv6r0000gn/T/codex-shot-2026-09-26_21-42-15.png)
