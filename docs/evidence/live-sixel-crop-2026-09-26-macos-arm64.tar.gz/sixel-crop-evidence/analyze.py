import importlib.util,json,statistics
from collections import Counter
from pathlib import Path
from PIL import Image
root=Path('/Users/brandon/src/rbirds');work=root/'target/live-perf/sixel-crop'
spec=importlib.util.spec_from_file_location('trace_report',root/'tools/trace-report.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
results={}
for directory in ['cpu','final-cpu','busy-cpu','opaque-cpu','opaque-busy-cpu','opaque-busy-repeat']:
 rows=[]
 for p in sorted((work/directory).glob('*/cpu.json')):
  full=json.loads(p.read_text());d=full['interval_sample'];r={'name':p.parent.name,'side':p.parent.name.split('-')[1],'app':d['application_cpu_ms_per_second'],'terminal':d['terminal_cpu_ms_per_second'],'helper':d['terminal_helpers']['cpu_ms_per_second'],'hash':full['binary_sha256']};r['combined']=r['app']+r['terminal']+r['helper'];r['trace']=mod.summarize(p.parent/'trace.jsonl',3);rows.append(r)
 results[directory]={'rows':rows,'medians':{side:{k:statistics.median(r[k] for r in rows if r['side']==side) for k in ['app','terminal','helper','combined']} for side in ['before','after']}}
for directory,filename in [('presentation','candidate-presentation.json'),('final-presentation','candidate-presentation.json'),('events','presentation.json'),('full-blocks-presentation','candidate-presentation.json'),('opaque-events','presentation.json')]:
 d=json.loads((work/directory/filename).read_text());f=d['frames'];t=[x['pts'] for x in f if x['changed']];g=sorted((b-a)*1000 for a,b in zip(t,t[1:]));results[directory]={'frames':len(f),'changed':len(t),'changed_hz':(len(t)-1)/(t[-1]-t[0]),'p99_ms':g[int(len(g)*.99)],'max_ms':max(g),'over50ms':sum(x>50 for x in g),'backgrounds':{str(k):v for k,v in Counter(tuple(x['dominant_rgb']) for x in f).items()},'min_dominant_fraction':min(x['dominant_fraction'] for x in f),'capture_cpu_seconds':d['capture_cpu_seconds']}
for parent in ['watched','busy-watched','contrast-watched']:
 for path in sorted((work/parent).glob('*/presentation.json')):
  d=json.loads(path.read_text());f=d['frames'];t=[x['pts'] for x in f if x['changed']];g=sorted((b-a)*1000 for a,b in zip(t,t[1:]));colours={str(c['rgb']):max(next(w['samples'] for w in x['watched_colours'] if w['rgb']==c['rgb'])/x['sampled_pixels'] for x in f) for c in f[0]['watched_colours']}
  results[str(path.parent.relative_to(work))]={'frames':len(f),'changed':len(t),'changed_hz':(len(t)-1)/(t[-1]-t[0]),'p99_ms':g[int(len(g)*.99)],'max_ms':max(g),'over50ms':sum(x>50 for x in g),'maximum_watched_fraction':colours,'maximum_translucent_fraction':max(x['translucent_samples']/x['sampled_pixels'] for x in f),'backgrounds':{str(k):v for k,v in Counter(tuple(x['dominant_rgb']) for x in f).items()},'capture_cpu_seconds':d['capture_cpu_seconds']}
static=[]
for transparency in [0,0.5]:
 images=[Image.open((work/'static-captures'/f'{transparency}-{side}-screenshot.txt').read_text().strip()).convert('RGBA').crop((122,148,1522,1236)) for side in ['before','after']]
 changed=[(i%1400,i//1400,a,b) for i,(a,b) in enumerate(zip(images[0].getdata(),images[1].getdata())) if a!=b]
 static.append({'transparency':transparency,'roi':[122,148,1522,1236],'changed_pixels':len(changed),'maximum_channel_delta':max(max(abs(a-b) for a,b in zip(x[2],x[3])) for x in changed) if changed else 0,'outside_panel_changes':sum(x>=532 or y>=374 for x,y,_,_ in changed),'changes':changed})
results['static']=static
(work/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
for k,v in results.items():
 if isinstance(v,dict) and 'rows' in v:print(k,v['medians'])
 elif k=='static':print(k,[{key:value for key,value in r.items() if key!='changes'} for r in v])
 else:print(k,v)
