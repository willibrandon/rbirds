import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');out=root/'target/live-perf/sixel-crop'
name='rbirds-perf-sixel-block-probe'
cmd=shlex.join(['/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'block-probe-completed.json'),'/opt/homebrew/bin/python3',str(out/'block-probe.py')])
w=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),cmd,name],text=True))
print('window',w,flush=True)
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to set transparency of current session of (first window whose id is {w}) to 0.5'],check=True)
time.sleep(5)
shot=subprocess.check_output(['/opt/homebrew/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
(out/'block-probe-screenshot.txt').write_text(shot+'\n');print(shot,flush=True)
for _ in range(40):
 if (out/'block-probe-completed.json').exists():
  assert json.loads((out/'block-probe-completed.json').read_text())['status']==0
  break
 time.sleep(.5)
else:raise RuntimeError('probe did not finish')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {w})'],check=True)
