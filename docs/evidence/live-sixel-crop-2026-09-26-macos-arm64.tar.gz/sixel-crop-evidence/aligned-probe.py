import os,time
try:
 os.write(1,b'\x1b[?1049h\x1b[?25l\x1b[?80l\x1b[48;2;18;18;23m\x1b[2J\x1b[6;21H')
 image=b'\x1bP0;1q"1;1;420;272#0;2;7;7;9'+b'-'.join([b'!420~']*45+[b'!420B'])+b'\x1b\\'
 os.write(1,image)
 time.sleep(12)
finally:
 os.write(1,b'\x1b[0m\x1b[?80h\x1b[?25h\x1b[?1049l')
