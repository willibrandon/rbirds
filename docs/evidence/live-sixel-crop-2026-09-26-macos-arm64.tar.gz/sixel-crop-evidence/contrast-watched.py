import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=root/'target/live-perf/sixel-crop';out=work/'contrast-watched';out.mkdir(exist_ok=True)
for label,binary,transparency in [('contrast-before','before-rbirds',0),('contrast-after','opaque-rbirds',0)]:
 d=out/label;d.mkdir(exist_ok=True);name='rbirds-perf-sixel-watch-'+label
 cmd=shlex.join(['/usr/bin/env','RBIRDS_TRACE='+str(d/'trace.jsonl'),'/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(d/'completed.json'),str(work/binary),'--render','sixel','--seed','42','--frames','1200'])
 w=int(subprocess.check_output(['osascript',str(work/'run-profile.scpt'),cmd,name,'rbirds-perf-contrast-probe'],text=True));print(label,'window',w,flush=True)
 subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to set transparency of current session of (first window whose id is {w}) to {transparency}'],check=True)
 time.sleep(5)
 subprocess.run([str(root/'target/presentation-capture'),name,str(d/'presentation.json'),'10','121217','15191e'],check=True)
 shot=subprocess.check_output(['/opt/homebrew/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip();(d/'screenshot.txt').write_text(shot+'\n');print(shot,flush=True)
 for _ in range(80):
  if (d/'completed.json').exists():
   assert json.loads((d/'completed.json').read_text())['status']==0
   break
  time.sleep(.5)
 else:raise RuntimeError('run did not finish')
 subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {w})'],check=True)
