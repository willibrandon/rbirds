import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=root/'target/live-perf/sixel-crop';stage=root/'target/live-perf/sixel-crop-evidence';stage.mkdir(exist_ok=True)
for p in sorted(work.rglob('*')):
 if not p.is_file() or p.name.endswith('-rbirds') or p.name in ['static','static-final'] or p.suffix=='.pid':continue
 dst=stage/p.relative_to(work);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
 if p.name.endswith('screenshot.txt'):
  shutil.copy2(Path(p.read_text().strip()),dst.with_suffix('.png'))
for name in ['terminal-perf.py','trace-report.py','presentation-capture.swift']:
 shutil.copy2(root/'tools'/name,stage/name)
for name in ['completion-exec.py','run-iterm.scpt']:
 shutil.copy2(root/'target/live-perf'/name,stage/name)
(stage/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','src/render/compose.rs','src/render/sixel.rs','tests/sixel.rs','tests/steady_state_allocation.rs','tests/pty_sixel.rs','tools/presentation-capture.swift']))
meta={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binaries':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in work.glob('*-rbirds')},'host':subprocess.check_output(['sw_vers'],text=True),'rustc':subprocess.check_output(['/Users/brandon/.cargo/bin/rustc','--version'],text=True).strip(),'scope':'Serial 20-second CPU intervals after 3-second warmup, separate foreground captures and static pixel comparisons. Main iTerm process and selected decoder helper; excludes compositor and GPU. Existing iTerm process may include other sessions.','variants':{'prototype-rbirds':'Rejected text-background variant: transparency changes outside the raster. cpu/ and presentation/ are prototype data, not the final result.','block-rbirds':'Rejected opaque backdrop only outside crop. Static captures use this rendering logic; later moving checks revealed defects.','final-rbirds':'Rejected backdrop only outside crop: moving default-background rectangles. final-cpu/, busy-cpu/, final-presentation/, and events/ use this executable.', 'full-blocks-rbirds':'Full opaque backdrop prototype, thirty-second presentation capture.', 'opaque-rbirds':'Full opaque backdrop, simplified loop and positive geometry guards. opaque-cpu/, opaque-busy-cpu/, opaque-busy-repeat/, opaque-events/, watched/opaque and watched/transparent, busy-watched/after and contrast-watched/contrast-after use this executable.','post-rbirds':'Rejected backdrop outside crop after image: moving background holes and missing birds. watched/post and watched/post-transparent use this executable.', 'before-rbirds':'Accepted dcbfd4c code, unchanged by documentation commit 81e0417.'}}
(stage/'provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
files={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(stage/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
archive=root/'docs/evidence/live-sixel-crop-2026-09-26-macos-arm64.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(stage,arcname='sixel-crop-evidence')
with tarfile.open(archive) as tar:
 manifest=json.load(tar.extractfile('sixel-crop-evidence/manifest.json'))
 for name,expected in manifest.items():assert hashlib.sha256(tar.extractfile('sixel-crop-evidence/'+name).read()).hexdigest()==expected,name
print(archive.name,archive.stat().st_size,'bytes;',len(files),'verified files')
