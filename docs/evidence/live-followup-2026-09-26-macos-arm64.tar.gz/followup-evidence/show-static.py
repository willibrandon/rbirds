import os,sys,time
from pathlib import Path
os.write(1, b'\x1b[?25l\x1b[2J\x1b[H')
data=Path(sys.argv[1]).read_bytes()
while data:
    data=data[os.write(1,data):]
os.write(1, b'\x1b[5;1H\x1b[38;2;255;255;255m' + b'Layer and edge check ' * 5 + b'\x1b[0m')
time.sleep(7)
