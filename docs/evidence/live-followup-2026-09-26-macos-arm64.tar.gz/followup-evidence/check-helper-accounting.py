import json,os,subprocess,sys,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');out=root/'target/live-perf/helper-checks';out.mkdir(exist_ok=True)
base=[sys.executable,str(root/'tools/terminal-perf.py'),'--terminal-pid',str(os.getpid()),'--warmup-seconds','0.1','--sample-seconds','2']
helper=subprocess.Popen([sys.executable,'-c','import time\nend=time.process_time()+1\nwhile time.process_time()<end: pass\ntime.sleep(20)'])
try:
    subprocess.run(base+['--helper-pid',str(helper.pid),'--output',str(out/'busy.json'),'--',sys.executable,'-c','import time;time.sleep(3)'],check=True)
    report=json.loads((out/'busy.json').read_text());observed=report['terminal_helpers']['cpu_seconds']
    assert .8<observed<1.1,observed
    assert report['interval_sample']['terminal_helpers']['cpu_seconds']>.65
finally:
    helper.terminate()
    _,status,usage=os.wait4(helper.pid,0)
    helper.returncode=os.waitstatus_to_exitcode(status)
assert abs(observed-usage.ru_utime-usage.ru_stime)<.15,(observed,usage)
(out/'independent.json').write_text(json.dumps({'harness_helper_cpu_seconds':observed,'wait4_helper_cpu_seconds':usage.ru_utime+usage.ru_stime},indent=2)+'\n')
helper=subprocess.Popen([sys.executable,'-c','import time;time.sleep(.8)'])
try:
    subprocess.run(base+['--helper-pid',str(helper.pid),'--output',str(out/'exited.json'),'--',sys.executable,'-c','import time;time.sleep(3)'],check=True)
    report=json.loads((out/'exited.json').read_text())
    for group in [report['terminal_helpers'],report['interval_sample']['terminal_helpers']]:
        assert 'error' in group['processes'][0] and 'cpu_seconds' not in group,group
finally:helper.wait()
for args in [['--helper-pid','-1'],['--helper-pid',str(os.getpid())]]:
    r=subprocess.run(base+args+['--output',str(out/'invalid.json'),'--',sys.executable,'-c','pass'],capture_output=True)
    assert r.returncode==2,r
print('helper accounting: independent CPU counter, exited helper, invalid PID checks passed',flush=True)
