import json,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds')
out=root/'target/live-perf/grid-static'
out.mkdir(exist_ok=True)
for variant,scene in [('before','target/live-perf/strip-static-64.bin'),('after','target/kitty-atlas-check/scene-after-64.bin')]:
    title='rbirds-perf-grid-static-'+variant
    cmd=['open','-W','-n','-a','kitty','--args','--config','NONE','--title',title,'--override','initial_window_width=800','--override','initial_window_height=500','--override','remember_window_size=no','--override','macos_quit_when_last_window_closed=yes','/opt/homebrew/bin/python3',str(root/'target/live-perf/show-static.py'),str(root/scene)]
    p=subprocess.Popen(cmd)
    time.sleep(3)
    result=subprocess.check_output(['/opt/homebrew/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','kitty','--window-name',title,'--mode','temp'],text=True)
    (out/(variant+'-screenshot.txt')).write_text(result)
    print(variant,result.strip(),flush=True)
    if p.wait(timeout=30): raise RuntimeError('Kitty failed')
