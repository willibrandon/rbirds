import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds')
out=root/'target/live-perf/iterm-helper-cpu'
out.mkdir(exist_ok=True)
name='rbirds-perf-iterm-helper-cpu'
command=shlex.join(['/usr/bin/env','RBIRDS_TRACE='+str(out/'candidate.jsonl'),'/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),'/opt/homebrew/bin/python3',str(root/'tools/terminal-perf.py'),'--terminal-pid','73499','--helper-pid','24604','--warmup-seconds','3','--sample-seconds','20','--note','Visible iTerm2 3.6.6, own 100x32 test window, UFC off, no capture or profiler; main process and stable sandboxed image worker only','--output',str(out/'cpu.json'),'--',str(root/'target/release/rbirds'),'--render','sixel','--seed','42','--frames','1800'])
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True))
(out/'window.txt').write_text(str(window)+'\n')
print('own window',window,flush=True)
for _ in range(100):
    if (out/'completed.json').exists():
        assert json.loads((out/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:
    raise RuntimeError('Command did not complete')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
