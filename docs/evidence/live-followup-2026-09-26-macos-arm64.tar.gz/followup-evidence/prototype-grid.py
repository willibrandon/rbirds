from pathlib import Path
p=Path('src/render/atlas.rs')
s=p.read_text().replace('use crate::config::ROTATION_FRAMES;','use std::ops::Range;')
a=s.index('fn pack(');b=s.index('\nimpl Atlas',a)
s=s[:a]+'''const MAX_TEXTURE_EDGE: i32 = 2048;

fn pack(frames: &[Image], image: u32, regions: &mut [Region]) -> Result<(Image, usize), KittyError> {
    let (mut x, mut y, mut row_height, mut width, mut count) = (0, 0, 0, 0, 0);
    for (frame, region) in frames.iter().zip(regions.iter_mut()) {
        if frame.is_empty() {
            count += 1;
            continue;
        }
        let tile_width = frame.width.checked_add(2).ok_or(KittyError::Argument)?;
        let tile_height = frame.height.checked_add(2).ok_or(KittyError::Argument)?;
        if tile_width > MAX_TEXTURE_EDGE || tile_height > MAX_TEXTURE_EDGE {
            return Err(KittyError::Argument);
        }
        let (next_x, next_y, next_height) = if x + tile_width > MAX_TEXTURE_EDGE {
            (0, y + row_height, tile_height)
        } else {
            (x, y, row_height.max(tile_height))
        };
        if next_y + next_height > MAX_TEXTURE_EDGE {
            break;
        }
        *region = Region {
            image, x: next_x + 1, y: next_y + 1,
            width: frame.width, height: frame.height, texture_width: 0,
        };
        x = next_x + tile_width;
        y = next_y;
        row_height = next_height;
        width = width.max(x);
        count += 1;
    }
    if width == 0 {
        return Ok((Image::empty(), count));
    }
    let mut atlas = Image::alloc(width, y + row_height).map_err(|_| KittyError::Memory)?;
    for (frame, region) in frames[..count].iter().zip(regions[..count].iter_mut()) {
        if frame.is_empty() {
            continue;
        }
        region.texture_width = width;
        // Repeat all four edges and corners so filtering a crop behaves like
        // the original texture's clamp-to-edge, including nontransparent edges.
        for dy in -1..=frame.height {
            for dx in -1..=frame.width {
                let from = frame.offset(dx.clamp(0, frame.width - 1), dy.clamp(0, frame.height - 1));
                let to = atlas.offset(region.x + dx, region.y + dy);
                atlas.pixels[to..to + 4].copy_from_slice(&frame.pixels[from..from + 4]);
            }
        }
    }
    Ok((atlas, count))
}
''' + s[b:]
s=s.replace('pub fn upload(graphics: &mut KittyGraphics, frames: &[Image]) -> Result<Self, KittyError> {','pub fn upload(graphics: &mut KittyGraphics, frames: &[Image], below_text: Range<usize>) -> Result<Self, KittyError> {').replace('Self::queue_upload(graphics, frames)?','Self::queue_upload(graphics, frames, below_text)?')
s=s.replace('        frames: &[Image],\n    ) -> Result<Self, KittyError> {','        frames: &[Image],\n        below_text: Range<usize>,\n    ) -> Result<Self, KittyError> {\n        if below_text.start > below_text.end || below_text.end > frames.len() {\n            return Err(KittyError::Argument);\n        }')
a=s.index('        for (set, rotations)');b=s.index('        graphics.delete_all_placements()',a)
s=s[:a]+'''        // Kitty groups consecutive placements sharing an image. Keep below-
        // text sprites separate so no group crosses its text drawing boundary.
        for range in [0..below_text.start, below_text.clone(), below_text.end..frames.len()] {
            let mut offset = range.start;
            while offset < range.end {
                let (atlas, count) = pack(&frames[offset..range.end], image, &mut regions[offset..range.end])?;
                offset += count;
                if atlas.is_empty() {
                    continue;
                }
                let encoded = png::encode(&atlas).map_err(|_| KittyError::Memory)?;
                graphics.upload_png(image, &encoded)?;
                image += 1;
            }
        }
''' + s[b:]
s=s.replace('2 + rotation % 7, 3 + rotation % 5','17 + rotation % 71, 13 + rotation % 53').replace('let packed = pack(&frames, 7, &mut regions).unwrap();','let (packed, count) = pack(&frames, 7, &mut regions).unwrap();\n        assert_eq!(count, frames.len());\n        assert!(regions.iter().any(|region| region.y > 1));').replace('for x in 0..region.texture_width {','for x in -1..=frame.width {')
p.write_text(s)
p=Path('src/simulation/mod.rs');s=p.read_text();a=s.index('    /// `sprite_image_id`.');s=s[:a]+'''    /// Sprite-frame indices drawn below text by the Kitty renderer.
    pub fn far_sprite_frames(&self) -> std::ops::Range<usize> {
        (self.flock_set(0, 0, 1) * ROTATION_FRAMES) as usize
            ..(self.hawk_set(0) * ROTATION_FRAMES) as usize
    }

'''+s[a:];p.write_text(s)
for f in ['src/live.rs','tools/oracle/kitty_atlas_scene.rs']:
 p=Path(f);s=p.read_text();needle='&renderer.sprites[..(sim.sprite_set_count() * ROTATION_FRAMES) as usize],';s=s.replace(needle,needle+'\n                sim.far_sprite_frames(),');p.write_text(s)
p=Path('tests/steady_state_allocation.rs');s=p.read_text().replace('Atlas::queue_upload(&mut graphics, &renderer.sprites)','Atlas::queue_upload(&mut graphics, &renderer.sprites, sim.far_sprite_frames())');p.write_text(s)
