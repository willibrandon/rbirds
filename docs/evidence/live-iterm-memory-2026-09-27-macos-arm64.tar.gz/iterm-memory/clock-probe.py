import ctypes, json
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
lib.sysctlbyname.argtypes=[ctypes.c_char_p,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.c_void_p,ctypes.c_size_t]
for key in [b'hw.tbfrequency',b'hw.cpufrequency',b'sysctl.proc_translated']:
    value=ctypes.c_uint64();size=ctypes.c_size_t(ctypes.sizeof(value))
    result=lib.sysctlbyname(key,ctypes.byref(value),ctypes.byref(size),None,0)
    print(key, result,value.value,size.value)
