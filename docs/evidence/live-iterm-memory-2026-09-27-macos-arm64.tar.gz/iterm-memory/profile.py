import json, shlex, subprocess, time
from pathlib import Path
root = Path('/Users/brandon/src/rbirds')
out = Path(__file__).resolve().parent
name = 'rbirds-perf-kitty-one-bird-profile'
args = [str(root/'target/release/rbirds'), '--render', 'kitty', '--birds', '1', '--seed', '42', '--frames', '3600']
command = shlex.join(['/usr/bin/env', 'RBIRDS_TRACE='+str(out/'trace.jsonl'), '/usr/bin/python3', str(root/'target/live-perf/completion-exec.py'), name, str(out/'completed.json'), *args])
window = int(subprocess.check_output(['osascript', str(root/'target/live-perf/run-iterm.scpt'), command, name], text=True))
(out/'window.txt').write_text(str(window)+'\n')
print('Owned window', window, flush=True)
time.sleep(7)
subprocess.run(['/usr/bin/sample', '73499', '10', '1', '-file', str(out/'iterm-sample.txt')], check=True)
subprocess.run(['osascript', '-e', f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'], check=True)
for _ in range(120):
    if (out/'completed.json').exists():
        completed = json.loads((out/'completed.json').read_text())
        assert completed['status'] == 0, completed
        break
    time.sleep(.5)
else:
    raise RuntimeError('Retaining unfinished owned window')
subprocess.run(['osascript', '-e', f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'], check=True)
print('Profile complete; owned window closed.', flush=True)
