import json, shlex, subprocess, sys, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from process_usage import Counters
with Counters() as counters:
    for backend,warmup,seconds,gap in [('kitty',1.5,1.5,1),('sixel',3,10,10)]:
        out=work/'live-memory'/backend;out.mkdir(parents=True)
        name='rbirds-perf-memory-'+backend
        observations=[]
        def observe(label):
            record={'label':label,'time':time.monotonic(),'memory':counters.snapshot(73499).memory}
            observations.append(record);(out/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
            return record['memory']['physical_footprint']
        initial=observe('before')
        command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(out/'cpu.json'),'--trace',str(out/'trace.jsonl'),'--terminal-pid','73499','--helper-pid','24604','--warmup-seconds',str(warmup),'--sample-seconds',str(seconds),'--sample-count','2','--sample-gap-seconds',str(gap),'--note','Memory qualification only: shared idle iTerm 3.6.6, owned visible 100x32/1400x1088, native memory guard once per second, UFC off, no builds/capture/profile/tests.','--',str(root/'target/release/rbirds'),'--render',backend,'--seed','42','--frames','7200']
        wrapper=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),*command])
        window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapper,name],text=True));(out/'window.txt').write_text(str(window)+'\n')
        start=time.monotonic();duration=2+warmup+2*seconds+gap+.5;print(backend,'owned window',window,flush=True)
        try:
            while time.monotonic()-start<duration:
                time.sleep(min(1,duration-(time.monotonic()-start)))
                footprint=observe('during')
                if footprint>min(initial+1.2*1024**3,2*1024**3):
                    (out/'stopped-for-memory.txt').write_text(str(footprint)+'\n');break
        finally:
            subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'],check=True)
        for _ in range(120):
            if (out/'completed.json').exists():break
            time.sleep(.5)
        else:raise RuntimeError('Retaining unfinished owned window')
        observe('after-quit')
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
        for _ in range(10):time.sleep(1);observe('after-close')
        completed=json.loads((out/'completed.json').read_text());report=json.loads((out/'cpu.json').read_text())
        print(backend,'status',completed['status'],'valid',report['measurement_valid'],flush=True)
        for interval in report.get('interval_samples',[]):print(json.dumps({k:interval[k] for k in ['application_memory','terminal_memory'] if k in interval}),flush=True)
