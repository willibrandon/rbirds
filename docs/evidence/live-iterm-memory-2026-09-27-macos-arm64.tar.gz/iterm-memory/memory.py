import json, re, shlex, subprocess, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds'); out=Path(__file__).resolve().parent/'memory'; out.mkdir()
records=[]
def sample(label):
    start=time.monotonic()
    raw=subprocess.check_output(['vmmap','-summary','73499'],text=True,timeout=15)
    (out/(label+'.txt')).write_text(raw)
    match=re.search(r'^Physical footprint:\s+([\d.]+)([KMG])',raw,re.M)
    value=float(match.group(1))*{'K':1024,'M':1024**2,'G':1024**3}[match.group(2)]
    records.append({'label':label,'start':start,'end':time.monotonic(),'physical_footprint_bytes':value})
    (out/'samples.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,round(value/1024**2,1),'MiB',flush=True)
    return value
sample('before')
name='rbirds-perf-kitty-memory'
command=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),str(root/'target/release/rbirds'),'--render','kitty','--seed','42','--frames','3600'])
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True));(out/'window.txt').write_text(str(window)+'\n')
start=time.monotonic();print('Owned window',window,flush=True)
try:
    for seconds in [5,10,15,20,25]:
        time.sleep(max(0,start+seconds-time.monotonic()))
        if sample('during-'+str(seconds))>2*1024**3:
            print('Stopping at the two-GiB footprint bound.',flush=True);break
finally:
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'],check=True)
for _ in range(100):
    if (out/'completed.json').exists():
        assert json.loads((out/'completed.json').read_text())['status']==0;break
    time.sleep(.5)
else:raise RuntimeError('Retaining unfinished owned window')
sample('after-quit')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
time.sleep(2)
sample('after-close')
