import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds')
out=root/'target/live-perf/iterm-kitty-ids/profile'
out.mkdir(exist_ok=True)
name='rbirds-perf-iterm-kitty-profile'
command=shlex.join(['/usr/bin/env','RBIRDS_TRACE='+str(out/'candidate.jsonl'),'/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),str(root/'target/live-perf/iterm-kitty-ids/prototype-rbirds'),'--render','kitty','--seed','42','--frames','300'])
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True))
(out/'window.txt').write_text(str(window)+'\n')
print('own window',window,flush=True)
time.sleep(4)
subprocess.run(['/usr/bin/sample','73499','4','1','-file',str(out/'iterm-sample.txt')],check=True)
for _ in range(100):
    if (out/'completed.json').exists():
        assert json.loads((out/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:
    raise RuntimeError('Command did not complete')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
