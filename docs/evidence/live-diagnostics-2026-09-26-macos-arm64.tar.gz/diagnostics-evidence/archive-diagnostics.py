import hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
root = Path('/Users/brandon/src/rbirds')
work = root / 'target/live-perf'
stage = work / 'diagnostics-evidence'
stage.mkdir(exist_ok=True)
sources = {}
for directory in ['iterm-kitty-ids', 'neighbor-cache', 'iterm-dcbfd4c-confirmation']:
    for src in sorted((work / directory).rglob('*')):
        if not src.is_file() or src.name.endswith('-rbirds') or src.suffix == '.pid':
            continue
        if directory == 'iterm-kitty-ids' and src.suffix in ['.swift', '.m']:
            version = 'v3.6.11' if src.name.startswith('v3.6.11-') else 'v3.6.6'
            basename = src.name.removeprefix('v3.6.11-')
            sources[str(src.relative_to(work))] = {'sha256': hashlib.sha256(src.read_bytes()).hexdigest(), 'url': f'https://raw.githubusercontent.com/gnachman/iTerm2/{version}/sources/{basename}'}
            continue
        dst = stage / src.relative_to(work)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        if src.name == 'screenshot.txt':
            shutil.copy2(Path(src.read_text().strip()), dst.with_suffix('.png'))
for name in ['run-iterm.scpt', 'completion-exec.py', 'run-iterm-dcbfd4c-confirmation.py', 'iterm-dcbfd4c-confirmation.log', 'capture-colours.swift', 'archive-diagnostics.py', 'iterm-confirmation-tests.log']:
    shutil.copy2(work / name, stage / name)
for name in ['trace-report.py', 'live-perf.py', 'presentation-capture.swift']:
    shutil.copy2(root / 'tools' / name, stage / name)
meta = {
    'accepted_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'source_state': 'Both experiments rejected and restored to the accepted commit. Documentation is the only tracked change.',
    'scope': 'Serial construction comparison, separate intrusive diagnostic profiles, and foreground captures. No claim of improved live CPU from either prototype.',
    'host': subprocess.check_output(['sw_vers'], text=True),
    'toolchain': subprocess.check_output(['/Users/brandon/.cargo/bin/rustc', '--version'], text=True).strip(),
    'binaries': {str(p.relative_to(work)): hashlib.sha256(p.read_bytes()).hexdigest() for directory in ['iterm-kitty-ids', 'neighbor-cache'] for p in sorted((work / directory).glob('*-rbirds'))},
    'upstream_sources': sources
}
(stage / 'provenance.json').write_text(json.dumps(meta, indent=2) + '\n')
files = {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
(stage / 'manifest.json').write_text(json.dumps(files, indent=2) + '\n')
archive = root / 'docs/evidence/live-diagnostics-2026-09-26-macos-arm64.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(stage, arcname='diagnostics-evidence')
with tarfile.open(archive) as tar:
    manifest = json.load(tar.extractfile('diagnostics-evidence/manifest.json'))
    for name, expected in manifest.items():
        assert hashlib.sha256(tar.extractfile('diagnostics-evidence/' + name).read()).hexdigest() == expected, name
print(archive.name, archive.stat().st_size, 'bytes;', len(files), 'verified files')
