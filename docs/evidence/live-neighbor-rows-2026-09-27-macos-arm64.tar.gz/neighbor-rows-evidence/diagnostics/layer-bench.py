import hashlib,json,re,statistics,subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parent
variants={s:p/(s+'-rbirds') for s in ['before','after']};rows=[]
cases=[('default',1500,[]),('depth',1500,['--depth']),
       ('dense-flat',400,['--birds','4096']),
       ('dense-depth',400,['--birds','4096','--depth']),
       ('dense-busy',400,['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember'])]
for scene,frames,extra in cases:
    command=['--render','kitty','--bench',str(frames),'--seed','42',*extra]
    for binary in variants.values():subprocess.run([str(binary),*command],stdout=subprocess.DEVNULL,check=True)
    for side in ['before','after','after','before']:
        start=time.perf_counter();raw=subprocess.check_output([str(variants[side]),*command],text=True)
        row={'scene':scene,'side':side,'command':command,'sha256':hashlib.sha256(variants[side].read_bytes()).hexdigest(),
             'wall_seconds':time.perf_counter()-start,'stdout':raw,'ms':float(re.search(r'frame time\s+(\S+)',raw)[1]),
             'bytes':re.search(r'bytes/frame\s+(\S+)',raw)[1]}
        rows.append(row);(p/'bench.json').write_text(json.dumps(rows,indent=2)+'\n')
    these=[r for r in rows if r['scene']==scene];assert len({r['bytes'] for r in these})==1
    med={side:statistics.median(r['ms'] for r in these if r['side']==side) for side in variants}
    print(scene,med,'ratio',med['after']/med['before'],flush=True)
