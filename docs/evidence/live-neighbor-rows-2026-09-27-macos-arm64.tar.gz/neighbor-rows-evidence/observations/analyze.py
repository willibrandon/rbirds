import json,statistics
from collections import Counter
from pathlib import Path
p=Path(__file__).resolve().parent
visible={}
for path in sorted((p/'visible').glob('*/*-presentation.json')):
    d=json.loads(path.read_text());f=d['frames'];t=[x['pts'] for x in f if x['changed']]
    g=sorted(1000*(b-a) for a,b in zip(t,t[1:]))
    visible[str(path.relative_to(p/'visible'))]={'samples':len(f),'hz':(len(t)-1)/(t[-1]-t[0]),
        'p99_ms':g[int(.99*len(g))],'max_ms':max(g),
        'dominant_colors':dict(Counter(str(x['dominant_rgb']) for x in f)),
        'maximum_dominant_fraction':max(x['dominant_fraction'] for x in f),
        'capture_cpu_seconds':d['capture_cpu_seconds']}
(p/'visible/summary.json').write_text(json.dumps(visible,indent=2)+'\n')
pooled={}
for side in ['before','after']:
    samples=[]
    for root in ['cpu/kitty','cpu-kitty-repeat/kitty']:
        for path in (p/root).glob('*'+side+'/cpu.json'):
            report=json.loads(path.read_text());assert report['measurement_valid']
            samples.append(report['interval_sample'])
    assert len(samples)==4
    pooled[side]={key:statistics.median(s[key] for s in samples) for key in ['application_cpu_ms_per_second','terminal_cpu_ms_per_second']}
    pooled[side]['combined_cpu_ms_per_second']=statistics.median(s['application_cpu_ms_per_second']+s['terminal_cpu_ms_per_second']+s['terminal_helpers']['cpu_ms_per_second'] for s in samples)
(p/'kitty-pooled.json').write_text(json.dumps(pooled,indent=2)+'\n')
print(json.dumps({'visible':visible,'kitty_pooled':pooled},indent=2))
