import json,shlex,statistics,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
scenes=[('text',[],2),('kitty',['--render','kitty'],1),('sixel',['--render','sixel'],1),
    ('dense-sixel',['--render','sixel','--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember'],1)]
results=[]
for scene,extra,count in scenes:
    for index,side in enumerate(['before','after','after','before']):
        out=work/'cpu'/scene/(str(index)+'-'+side);out.mkdir(parents=True)
        name='rbirds-perf-row-'+scene+'-'+str(index)+'-'+side
        command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(out/'cpu.json'),
            '--terminal-pid','73499','--helper-pid','24604','--warmup-seconds','3','--sample-seconds','15',
            '--sample-count',str(count),'--sample-gap-seconds','25' if count==2 else '0',
            '--note','iTerm 3.6.6, visible owned 100x32 window; no capture/profiler/tests/builds; UFC off; '
            'shared otherwise idle iTerm. Before and after both have corrected Sixel positioning.',
            '--',str(work/(side+'-rbirds')),'--seed','42','--frames','7200',*extra]
        command=['/usr/bin/env','RBIRDS_TRACE='+str(out/'trace.jsonl'),*command]
        wrapped=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),*command])
        start=time.perf_counter();window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapped,name],text=True))
        (out/'window.txt').write_text(str(window)+'\n');print(scene,index,side,'own window',window,flush=True)
        time.sleep(max(0,start+(63 if count==2 else 23)-time.perf_counter()))
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'],check=True)
        for _ in range(120):
            if (out/'completed.json').exists():
                completed=json.loads((out/'completed.json').read_text());assert completed['status']==0,completed;break
            time.sleep(.5)
        else:raise RuntimeError('retain unfinished own window')
        report=json.loads((out/'cpu.json').read_text());assert report['measurement_valid'],report
        results.append({'scene':scene,'side':side,'report':report})
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
        samples=report.get('interval_samples',[report.get('interval_sample')])
        print('complete',scene,side,[(r['application_cpu_ms_per_second'],r['terminal_cpu_ms_per_second'],r['terminal_helpers']['cpu_ms_per_second']) for r in samples],flush=True)
summary={}
for scene,_,count in scenes:
    summary[scene]={}
    for slot in range(count):
        summary[scene][slot]={}
        for side in ['before','after']:
            samples=[r['report'].get('interval_samples',[r['report'].get('interval_sample')])[slot] for r in results if r['scene']==scene and r['side']==side]
            row={key:statistics.median(r[key] for r in samples) for key in ['application_cpu_ms_per_second','terminal_cpu_ms_per_second']}
            row['helper_cpu_ms_per_second']=statistics.median(r['terminal_helpers']['cpu_ms_per_second'] for r in samples)
            row['combined_cpu_ms_per_second']=sum(row.values())
            summary[scene][slot][side]=row
(work/'cpu/summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
