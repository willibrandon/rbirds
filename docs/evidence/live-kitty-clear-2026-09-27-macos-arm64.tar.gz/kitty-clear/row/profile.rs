use std::{ffi::OsString, io::Write};
use rbirds::{app::{Program, read_options}, live::LiveLoop, platform::{Timespec, WinSize},
    render::kitty::KittyGraphics, simulation::Bird, spatial_grid::SpatialGrid,
    stdio::CStdout, timing::FrameProfile};
fn main() {
    let extra:Vec<OsString>=std::env::args_os().skip(1).collect();
    let mut p=Program::new();
    let mut args:Vec<OsString>=["rbirds","--render","kitty","--seed","42"].into_iter().map(OsString::from).collect();
    args.extend(extra);
    read_options(&mut p,&args,&mut CStdout::new()).unwrap();
    let sim=&mut p.sim; let renderer=&mut p.renderer;
    sim.settle_the_bird_size(); sim.rng.seed(42); sim.apply_screen_size(100,32,1400,1088);
    renderer.kitty_raster=Some(Default::default());
    renderer.prepare_text_renderer(sim,None,b"rbirds").unwrap();
    sim.set_frame_seconds(1.0/60.0); sim.hawk_sets_built=true;
    let count=sim.config.birds;
    let mut birds=vec![Bird::default();count as usize]; let mut snapshot=birds.clone();
    sim.initialize_birds(&mut birds); sim.place_hawks(); sim.begin_the_intro();
    let mut grid=SpatialGrid::new(12).unwrap(); grid.prepare(1400,1088,count).unwrap();
    let mut output=KittyGraphics::new(1).unwrap(); let mut live=LiveLoop::new(Timespec{tv_sec:10,tv_nsec:0},count);
    let mut saved=std::env::var_os("SAVE_FRAMES").map(|p| std::io::BufWriter::new(std::fs::File::create(p).unwrap()));
    let mut stages=[0u128;3]; let mut bytes=0usize;
    for frame in 1..=600 {
        output.clear(); renderer.profile=Some(FrameProfile::new());
        let ns=frame*16_666_667_i64;
        live.frame(sim,renderer,&mut output,&mut birds,&mut snapshot,&mut grid,None,
            Timespec{tv_sec:10+ns/1_000_000_000,tv_nsec:ns%1_000_000_000},
            WinSize{row:32,col:100,xpixel:1400,ypixel:1088}).unwrap();
        let profile=renderer.profile.as_ref().unwrap();
        if frame>180 {
            stages[0]+=profile.updated.duration_since(profile.started).as_nanos();
            stages[1]+=profile.composed.duration_since(profile.updated).as_nanos();
            stages[2]+=profile.rendered.duration_since(profile.composed).as_nanos();
            bytes+=output.buffer().len();
        }
        if let Some(file)=saved.as_mut() {
            if (300..316).contains(&frame) {
                file.write_all(&(output.buffer().len() as u64).to_le_bytes()).unwrap();
                file.write_all(output.buffer()).unwrap();
            }
        }
    }
    println!("{{\"frames\":420,\"update_us\":{},\"compose_us\":{},\"encode_us\":{},\"bytes\":{}}}",
        stages[0] as f64/420000.0,stages[1] as f64/420000.0,stages[2] as f64/420000.0,bytes);
}
