import hashlib,json,os,statistics,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
rows=[]
dense=['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']
for scene,args in [('kitty',[]),('kitty-dense',dense)]:
    for side in ['before','after']:
        env=os.environ.copy();env['SAVE_FRAMES']=str(p/(scene+'-'+side+'.frames'))
        subprocess.run([str(p/(side+'-profile')),*args],stdout=subprocess.DEVNULL,env=env,check=True)
    assert (p/(scene+'-before.frames')).read_bytes()==(p/(scene+'-after.frames')).read_bytes(),scene
    for side in ['before','after','after','before']:
        row=json.loads(subprocess.check_output([str(p/(side+'-profile')),*args],text=True))
        row.update(scene=scene,side=side,args=args,sha256=hashlib.sha256((p/(side+'-profile')).read_bytes()).hexdigest());rows.append(row)
        (p/'bench.json').write_text(json.dumps(rows,indent=2)+'\n')
    selected=[r for r in rows if r['scene']==scene];assert len({r['bytes'] for r in selected})==1
    print(scene,{side:{key:statistics.median(r[key] for r in selected if r['side']==side) for key in ['update_us','compose_us','encode_us']} for side in ['before','after']},flush=True)
