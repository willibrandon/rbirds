import hashlib,json,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
for side in ['before','after']:
    subprocess.run(['rustc','--edition=2024','-C','opt-level=3',str(p/'validate.rs'),'--extern','rbirds='+str(p/('librbirds-'+side+'.rlib')),'-L','dependency=target/release/deps','-o',str(p/(side+'-validate'))],check=True)
results=[]
for case,args in [('fallback',[]),('dense',['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember'])]:
    for side in ['before','after']:
        process=subprocess.Popen([str(p/(side+'-validate')),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        digest=hashlib.sha256();length=0
        while True:
            data=process.stdout.read(1024*1024)
            if not data:break
            digest.update(data);length+=len(data)
        error=process.stderr.read();assert process.wait()==0,error
        results.append({'case':case,'side':side,'frames':600,'bytes':length,'sha256':digest.hexdigest()})
    assert results[-2]['sha256']==results[-1]['sha256'],case
(p/'full-streams.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2),flush=True)
