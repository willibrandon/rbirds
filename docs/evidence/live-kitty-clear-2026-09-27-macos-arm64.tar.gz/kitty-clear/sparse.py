import hashlib,json,shlex,statistics,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
variants={'before':work/'before-rbirds','band':work/'band/after-rbirds'}
scenes=[('sparse',['--birds','1'])]
results=[]
for scene,extra in scenes:
    for index,side in enumerate(['before','band','band','before']):
        out=work/'live-sparse'/scene/(str(index)+'-'+side);out.mkdir(parents=True);name=f'rbirds-perf-clear-{scene}-{index}-{side}'
        command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(out/'cpu.json'),'--trace',str(out/'trace.jsonl'),'--terminal-pid','73499','--helper-pid','24604','--warmup-seconds','3','--sample-seconds','15','--note','iTerm 3.6.6; owned foreground 100x32 /1400x1088; no capture, profiling, tests or builds during intervals; UFC off; shared otherwise idle iTerm; baseline and contiguous clear ABBA, one bird.','--',str(variants[side]),'--render','kitty','--seed','42','--frames','7200',*extra]
        wrapped=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),*command])
        start=time.perf_counter();window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapped,name],text=True))
        (out/'window.txt').write_text(str(window)+'\n');print(scene,index,side,'own window',window,flush=True)
        time.sleep(max(0,start+23-time.perf_counter()))
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'],check=True)
        for _ in range(120):
            if (out/'completed.json').exists():
                completed=json.loads((out/'completed.json').read_text());assert completed['status']==0,completed;break
            time.sleep(.5)
        else:raise RuntimeError('retain unfinished own window')
        report=json.loads((out/'cpu.json').read_text());assert report['measurement_valid'],report
        results.append({'scene':scene,'side':side,'index':index,'report':report})
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
        sample=report['interval_sample'];print('complete',scene,side,sample['application_cpu_ms_per_second'],sample['trace_alignment'],flush=True)
summary={}
for scene,_ in scenes:
    summary[scene]={}
    for side in variants:
        samples=[r['report']['interval_sample'] for r in results if r['scene']==scene and r['side']==side]
        row={key:statistics.median(r[key] for r in samples) for key in ['application_cpu_ms_per_second','terminal_cpu_ms_per_second']}
        row['helper_cpu_ms_per_second']=statistics.median(r['terminal_helpers']['cpu_ms_per_second'] for r in samples)
        row['combined_cpu_ms_per_second']=sum(row.values())
        row['frame_counts']=[[r['trace_alignment']['submitted_frames_min'],r['trace_alignment']['submitted_frames_max']] for r in samples]
        row['combined_cpu_ms_per_submitted_frame_ranges']=[r['trace_alignment']['cpu_ms_per_submitted_frame']['combined'] for r in samples]
        summary[scene][side]=row
(work/'sparse-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
