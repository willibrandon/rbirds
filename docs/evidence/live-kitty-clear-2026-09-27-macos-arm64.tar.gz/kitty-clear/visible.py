import json,shlex,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
for scene,seconds,extra in [('default',15,[]),('dense',15,['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']),('controls',20,['--birds','5','--depth','--trails','--hawks','4','--flocks','3'])]:
    out=work/'visible'/scene;out.mkdir(parents=True);name='rbirds-perf-clear-'+scene
    command=['/usr/bin/env','RBIRDS_TRACE='+str(out/'trace.jsonl'),str(work/'band/after-rbirds'),'--render','kitty','--seed','42','--frames','7200',*extra]
    wrapped=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),*command])
    start=time.perf_counter();window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapped,name],text=True));(out/'window.txt').write_text(str(window)+'\n');print(scene,'own window',window,flush=True)
    def tell(script):
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window})\n'+script+'\nend tell'],check=True)
    time.sleep(max(0,start+5-time.perf_counter()))
    capture=subprocess.Popen([str(root/'target/presentation-capture'),name,str(out/'presentation.json'),str(seconds)])
    if scene=='controls':
        beginning=time.perf_counter();events=[]
        for at,script in [(3,'write text "h" newline NO'),(6,'set columns to 80\nset rows to 24'),(9,'write text "h" newline NO'),(12,'set columns to 100\nset rows to 32'),(15,'write text "h" newline NO')]:
            time.sleep(max(0,beginning+at-time.perf_counter()));tell(script);events.append({'elapsed':time.perf_counter()-beginning,'action':script})
        (out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
    assert capture.wait(timeout=seconds+15)==0
    path=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
    (out/'screenshot-path.txt').write_text(path+'\n');shutil.copy2(path,out/'screenshot.png')
    tell('write text "q" newline NO')
    for _ in range(120):
        if (out/'completed.json').exists():
            result=json.loads((out/'completed.json').read_text());assert result['status']==0,result;break
        time.sleep(.5)
    else:raise RuntimeError('retain unfinished own window')
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True);print('complete',scene,flush=True)
