import hashlib, json, shutil, subprocess, tarfile
from pathlib import Path

work = Path(__file__).resolve().parent
root = work.parents[2]
stage = work / 'evidence'
stage.mkdir(exist_ok=True)
files = [
    'analyze.py', 'build-evidence.py', 'session.py', 'visible.py', 'sustained.py',
    'qualify.py', 'setup.py', 'setup.json', 'test-preferences.plist',
    'test-preferences-light.plist', 'session.json', 'app-process.json',
    'app-process-light.json', 'owned-window.json', 'verification.json',
    'cleanup.json', 'preference-key-comparison.json', 'self-test.txt',
    'prior-ci.json', 'visible-summary.json', 'sustained-summary.json',
    'focus-probe.json', 'focus-content-probe.json',
    'main.m', 'iTermUserDefaults.m', 'NSFileManager+iTerm.m'
]
for name in files:
    shutil.copy2(work / name, stage / name)
for directory in ['visible', 'visible-light', 'visible-background', 'visible-titlebar-probe', 'sustained', 'qualification']:
    shutil.copytree(work / directory, stage / directory, dirs_exist_ok=True)
sources = stage / 'sources'
sources.mkdir(exist_ok=True)
for name in ['presentation-capture.swift', 'process_usage.py', 'terminal-perf.py']:
    shutil.copy2(root / 'tools' / name, sources / name)
for name in ['show-scene.py', 'static-after.bin']:
    shutil.copy2(root / 'target/live-perf/iterm-kitty-frame' / name, sources / name)
(stage / 'capture.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', 'tools/presentation-capture.swift'], cwd=root))
manifest = {str(p.relative_to(stage)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(stage.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
assert not any('private-user' in name or name.endswith('.zip') or '/unpacked/' in name for name in manifest)
(stage / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'docs/evidence/live-iterm-fixed-build-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name in [*manifest, 'manifest.json']:
        tar.add(stage / name, arcname=name)
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(manifest) | {'manifest.json'}
    for name, entry in manifest.items():
        data = tar.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'archive': str(archive), 'manifested_files': len(manifest), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}))
