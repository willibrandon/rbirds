//
//  iTermUserDefaults.m
//  iTerm2SharedARC
//
//  Created by George Nachman on 4/16/19.
//

#import "iTermUserDefaults.h"

#import "DebugLogging.h"
#import "iTermAdvancedSettingsModel.h"
#import "NSArray+iTerm.h"
#import "NSObject+iTerm.h"

NSString *const kSelectionRespectsSoftBoundariesKey = @"Selection Respects Soft Boundaries";
static NSString *gCustomSuiteName = nil;
static BOOL gUserDefaultsInitialized = NO;
static NSString *const iTermSecureKeyboardEntryEnabledUserDefaultsKey = @"Secure Input";
// Set to YES after warning the user about respecting the dock setting to prefer tabs over windows.
static NSString *const kPreferenceKeyHaveBeenWarnedAboutTabDockSetting = @"NoSyncHaveBeenWarnedAboutTabDockSetting";

static NSString *const iTermUserDefaultsKeyBuggySecureKeyboardEntry = @"NoSyncSearchHistory";  // DEPRECATED - See issue 8118
static NSString *const iTermUserDefaultsKeySearchHistory = @"NoSyncSearchHistory2";

static NSString *const iTermUserDefaultsKeyEnableAutomaticProfileSwitchingLogging = @"NoSyncEnableAutomaticProfileSwitchingLogging";

static NSString *const iTermUserDefaultsKeyRequireAuthenticationAfterScreenLocks = @"RequireAuthenticationAfterScreenLocks";
static NSString *const iTermUserDefaultsKeyOpenTmuxDashboardIfHiddenWindows = @"OpenTmuxDashboardIfHiddenWindows";
static NSString *const iTermUserDefaultsKeyClaudeCodeWorkgroupUpsellSuppressed = @"ClaudeCodeWorkgroupUpsellSuppressed";
static NSString *const iTermUserDefaultsKeyClaudeCodeHooksInstalled = @"NoSyncClaudeCodeHooksInstalled";
static NSString *const iTermUserDefaultsKeyClaudeCodeTriggersInstalled = @"ClaudeCodeTriggersInstalled";
static NSString *const iTermUserDefaultsKeyClaudeCodeConfigDirPath = @"NoSyncClaudeCodeConfigDirPath";
static NSString *const iTermUserDefaultsKeyClaudeCodeIntegrationCompleted = @"NoSyncClaudeCodeIntegrationCompleted";
static NSString *const iTermUserDefaultsKeyShowSessionStatusInTabSubtitle = @"ShowSessionStatusInTabSubtitle";
NSString *const iTermShowSessionStatusInTabSubtitleDidChange = @"iTermShowSessionStatusInTabSubtitleDidChange";
static NSString *const iTermUserDefaultsKeyHaveExplainedHowToAddTouchbarControls = @"NoSyncHaveExplainedHowToAddTouchbarControls";
static NSString *const iTermUserDefaultsKeyHaveWarnedAboutUndoCloseShortcutChange = @"NoSyncHaveWarnedAboutUndoCloseShortcutChange";
static NSString *const iTermUserDefaultsKeyHaveWarnedAboutUndoKeyChange = @"NoSyncHaveWarnedAboutUndoKeyChange";
static NSString *const iTermUserDefaultsKeyIgnoreSystemWindowRestoration = @"NoSyncIgnoreSystemWindowRestoration";
static NSString *const iTermUserDefaultsKeyGlobalSearchMode = @"NoSyncGlobalSearchMode";
static NSString *const iTermUserDefaultsKeyAddTriggerInstant = @"NoSyncAddTriggerInstant";
static NSString *const iTermUserDefaultsKeyAddTriggerUpdateProfile = @"NoSyncAddTriggerUpdateProfile";
static NSString *const iTermUserDefaultsKeyLastSystemPythonVersionRequirement = @"NoSyncLastSystemPythonVersionRequirement";
static NSString *const iTermUserDefaultsKeyProbeForPassword = @"ProbeForPassword";
static NSString *const iTermUserDefaultsKeyImportPath = @"ImportPath";
static NSString *const iTermUserDefaultsKeyShouldSendReturnAfterPassword = @"ShouldSendReturnAfterPassword";
static NSString *const iTermUserDefaultsKeyWindowCornerRadiusCache = @"NoSyncWindowCornerRadiusCache";
static NSString *const iTermUserDefaultsKeyLastShutdownWasClean = @"NoSyncLastShutdownWasClean";
static NSString *const iTermUserDefaultsKeyWorkgroupsData = @"Workgroups";
static NSString *const iTermUserDefaultsKeyWorkgroupShortcutsBackfilled = @"NoSyncWorkgroupShortcutsBackfilled";
static NSString *const iTermUserDefaultsKeyClaudeCodeDiffModeBackfilled = @"NoSyncClaudeCodeDiffModeBackfilled";
static NSString *const iTermUserDefaultsKeyClaudeCodeReviewSystemPromptCommandBackfilled = @"NoSyncClaudeCodeReviewSystemPromptCommandBackfilled";
static NSString *const iTermUserDefaultsKeyClaudeCodeAutoSendClippingsBackfilled = @"NoSyncClaudeCodeAutoSendClippingsBackfilled";
static NSString *const iTermUserDefaultsKeyClaudeCodeAutoRequestReviewBackfilled = @"NoSyncClaudeCodeAutoRequestReviewBackfilled";
static NSString *const iTermUserDefaultsKeySuppressPhysicalKeyBindingSuggestion = @"NoSyncSuppressPhysicalKeyBindingSuggestion";
static NSString *const iTermUserDefaultsKeyAIModelCatalogUpdateConsent = @"NoSyncAIModelCatalogUpdateConsent";
static NSString *const iTermUserDefaultsKeyAutoProvideConsent = @"NoSyncAutoProvideConsent";
static NSString *const iTermUserDefaultsKeyHaveShownMacOS13RequirementNotice = @"NoSyncHaveShownMacOS13RequirementNotice";

@implementation iTermUserDefaults

+ (void)setCustomSuiteName:(NSString *)suiteName {
    ITAssertWithMessage(!gUserDefaultsInitialized, @"setCustomSuiteName: called after userDefaults was already accessed");
    gCustomSuiteName = [suiteName copy];
}

+ (NSString *)customSuiteName {
    return gCustomSuiteName;
}

static NSArray *iTermUserDefaultsGetTypedArray(NSUserDefaults *userDefaults, Class objectClass, NSString *key) {
    return [[NSArray castFrom:[userDefaults objectForKey:key]] mapWithBlock:^id(id anObject) {
        return [objectClass castFrom:anObject];
    }];
}

static void iTermUserDefaultsSetTypedArray(NSUserDefaults *userDefaults, Class objectClass, NSString *key, id value) {
    NSArray *array = [[NSArray castFrom:value] mapWithBlock:^id(id anObject) {
        return [objectClass castFrom:anObject];
    }];
    [userDefaults setObject:array forKey:key];
}

static NSUserDefaults *iTermPrivateUserDefaults(void) {
    static dispatch_once_t onceToken;
    static NSUserDefaults *privateUserDefaults;
    dispatch_once(&onceToken, ^{
        NSString *suiteName;
        if (gCustomSuiteName) {
            suiteName = [gCustomSuiteName stringByAppendingString:@".private"];
        } else {
            suiteName = @"com.googlecode.iterm2.private";
        }
        privateUserDefaults = [[NSUserDefaults alloc] initWithSuiteName:suiteName];
    });
    return privateUserDefaults;
}

+ (NSUserDefaults *)userDefaults {
    static NSUserDefaults *userDefaults;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gUserDefaultsInitialized = YES;
        if (gCustomSuiteName) {
            userDefaults = [[NSUserDefaults alloc] initWithSuiteName:gCustomSuiteName];
        } else {
            userDefaults = [NSUserDefaults standardUserDefaults];
        }
        [userDefaults registerDefaults:@{ iTermUserDefaultsKeyOpenTmuxDashboardIfHiddenWindows: @YES,
                                          iTermUserDefaultsKeyShouldSendReturnAfterPassword: @YES,
                                          iTermUserDefaultsKeyShowSessionStatusInTabSubtitle: @YES }];
    });
    return userDefaults;
}

+ (void)performMigrations {
    [self performMigrationsInUserDefaults:self.userDefaults];
}

+ (void)performMigrationsInUserDefaults:(NSUserDefaults *)userDefaults {
    // Migrate the renamed alt-screen bidi setting here rather than from
    // +[iTermAdvancedSettingsModel initialize]. +initialize fires the first time
    // anything touches the advanced settings model, which is well before
    // -applicationDidFinishLaunching reaches iTermPreferences initializeUserDefaults,
    // where a user’s custom-folder (e.g. Dropbox) prefs are copied down into local
    // defaults. Running the migration too early would miss a copied-down opt-out and
    // silently revert it. performMigrations runs after that copy, so the migration
    // sees the real value. Keep it first so the early return below never skips it.
    [iTermAdvancedSettingsModel migrateAlternateScreenBidiSettingInUserDefaults:userDefaults];

    id obj = [userDefaults objectForKey:iTermUserDefaultsKeySearchHistory];
    if (!obj) {
        return;
    }
    [self setSearchHistory:obj];
    [userDefaults removeObjectForKey:iTermUserDefaultsKeySearchHistory];

    id maybeSearchHistory = [userDefaults objectForKey:iTermUserDefaultsKeyBuggySecureKeyboardEntry];
    if (maybeSearchHistory && ![maybeSearchHistory isKindOfClass:[NSNumber class]]) {
        [userDefaults removeObjectForKey:iTermUserDefaultsKeyBuggySecureKeyboardEntry];
    }
}

+ (NSArray<NSString *> *)searchHistory {
    return iTermUserDefaultsGetTypedArray(iTermPrivateUserDefaults(), [NSString class], iTermUserDefaultsKeySearchHistory) ?: @[];
}

+ (void)setSearchHistory:(NSArray<NSString *> *)objects {
    iTermUserDefaultsSetTypedArray(iTermPrivateUserDefaults(), [NSString class], iTermUserDefaultsKeySearchHistory, objects);
}

+ (BOOL)secureKeyboardEntry {
    NSNumber *buggy = [NSNumber castFrom:[self.userDefaults objectForKey:iTermUserDefaultsKeyBuggySecureKeyboardEntry]];
    if (buggy) {
        // If the buggy one exists and is a number, then it was your secure keyboard setting as
        // written by version 3.3.0 or 3.3.1. Prefer it because updating the secure keyboard entry
        // setting in 3.3.2 or later will remove the buggy value.
        // If it exists and is not a number then it may have been set in an earlier
        // (non-buggy) version.
        return [buggy boolValue];
    }
    return [self.userDefaults boolForKey:iTermSecureKeyboardEntryEnabledUserDefaultsKey];
}

+ (void)setSecureKeyboardEntry:(BOOL)secureKeyboardEntry {
    // See comment in +secureKeyboardEntry.
    [self.userDefaults removeObjectForKey:iTermUserDefaultsKeyBuggySecureKeyboardEntry];
    [self.userDefaults setBool:secureKeyboardEntry
                        forKey:iTermSecureKeyboardEntryEnabledUserDefaultsKey];
}

+ (iTermAppleWindowTabbingMode)appleWindowTabbingMode {
    static NSUserDefaults *globalDomain;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // We overwrite this key in the app domain to fool Cocoa, so we need to
        // read it from the global domain. You can't create an instance of
        // NSUserDefaults with the suite NSGlobalDefaults because AppKit is not
        // good, so instead we have to lie to it.
        globalDomain = [[NSUserDefaults alloc] initWithSuiteName:@"com.iterm2.fake"];
    });
    NSString *value = [globalDomain objectForKey:@"AppleWindowTabbingMode"];
    if ([value isEqualToString:@"always"]) {
        return iTermAppleWindowTabbingModeAlways;
    }
    if ([value isEqualToString:@"manual"]) {
        return iTermAppleWindowTabbingModeManual;
    }
    return iTermAppleWindowTabbingModeFullscreen;
}

+ (BOOL)haveBeenWarnedAboutTabDockSetting {
    return [self.userDefaults boolForKey:kPreferenceKeyHaveBeenWarnedAboutTabDockSetting];
}

+ (void)setHaveBeenWarnedAboutTabDockSetting:(BOOL)haveBeenWarnedAboutTabDockSetting {
    [self.userDefaults setBool:haveBeenWarnedAboutTabDockSetting forKey:kPreferenceKeyHaveBeenWarnedAboutTabDockSetting];
}

+ (BOOL)enableAutomaticProfileSwitchingLogging {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyEnableAutomaticProfileSwitchingLogging];
}

+ (void)setEnableAutomaticProfileSwitchingLogging:(BOOL)enableAutomaticProfileSwitchingLogging {
    [self.userDefaults setBool:enableAutomaticProfileSwitchingLogging
                        forKey:iTermUserDefaultsKeyEnableAutomaticProfileSwitchingLogging];
}

+ (BOOL)requireAuthenticationAfterScreenLocks {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyRequireAuthenticationAfterScreenLocks];
}

+ (void)setRequireAuthenticationAfterScreenLocks:(BOOL)requireAuthenticationAfterScreenLocks {
    [self.userDefaults setBool:requireAuthenticationAfterScreenLocks
                        forKey:iTermUserDefaultsKeyRequireAuthenticationAfterScreenLocks];
}
+ (BOOL)openTmuxDashboardIfHiddenWindows {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyOpenTmuxDashboardIfHiddenWindows];
}

+ (void)setOpenTmuxDashboardIfHiddenWindows:(BOOL)openTmuxDashboardIfHiddenWindows {
    [self.userDefaults setBool:openTmuxDashboardIfHiddenWindows
                        forKey:iTermUserDefaultsKeyOpenTmuxDashboardIfHiddenWindows];
}

+ (BOOL)claudeCodeWorkgroupUpsellSuppressed {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyClaudeCodeWorkgroupUpsellSuppressed];
}

+ (void)setClaudeCodeWorkgroupUpsellSuppressed:(BOOL)suppressed {
    [self.userDefaults setBool:suppressed
                        forKey:iTermUserDefaultsKeyClaudeCodeWorkgroupUpsellSuppressed];
}

+ (BOOL)claudeCodeHooksInstalled {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyClaudeCodeHooksInstalled];
}

+ (void)setClaudeCodeHooksInstalled:(BOOL)installed {
    [self.userDefaults setBool:installed
                        forKey:iTermUserDefaultsKeyClaudeCodeHooksInstalled];
}

+ (BOOL)claudeCodeTriggersInstalled {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyClaudeCodeTriggersInstalled];
}

+ (void)setClaudeCodeTriggersInstalled:(BOOL)installed {
    [self.userDefaults setBool:installed
                        forKey:iTermUserDefaultsKeyClaudeCodeTriggersInstalled];
}

+ (nullable NSString *)claudeCodeConfigDirPath {
    return [self.userDefaults stringForKey:iTermUserDefaultsKeyClaudeCodeConfigDirPath];
}

+ (void)setClaudeCodeConfigDirPath:(nullable NSString *)path {
    if (path) {
        [self.userDefaults setObject:path forKey:iTermUserDefaultsKeyClaudeCodeConfigDirPath];
    } else {
        [self.userDefaults removeObjectForKey:iTermUserDefaultsKeyClaudeCodeConfigDirPath];
    }
}

+ (BOOL)claudeCodeIntegrationCompleted {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyClaudeCodeIntegrationCompleted];
}

+ (void)setClaudeCodeIntegrationCompleted:(BOOL)completed {
    [self.userDefaults setBool:completed
                        forKey:iTermUserDefaultsKeyClaudeCodeIntegrationCompleted];
}

+ (BOOL)showSessionStatusInTabSubtitle {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyShowSessionStatusInTabSubtitle];
}

+ (void)setShowSessionStatusInTabSubtitle:(BOOL)show {
    if (show == [self showSessionStatusInTabSubtitle]) {
        return;
    }
    [self.userDefaults setBool:show
                        forKey:iTermUserDefaultsKeyShowSessionStatusInTabSubtitle];
    [[NSNotificationCenter defaultCenter] postNotificationName:iTermShowSessionStatusInTabSubtitleDidChange
                                                        object:nil];
}

+ (BOOL)haveExplainedHowToAddTouchbarControls {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyHaveExplainedHowToAddTouchbarControls];
}

+ (void)setHaveExplainedHowToAddTouchbarControls:(BOOL)haveExplainedHowToAddTouchbarControls {
    [self.userDefaults setBool:haveExplainedHowToAddTouchbarControls
                        forKey:iTermUserDefaultsKeyHaveExplainedHowToAddTouchbarControls];
}

+ (BOOL)haveWarnedAboutUndoCloseShortcutChange {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyHaveWarnedAboutUndoCloseShortcutChange];
}

+ (BOOL)haveWarnedAboutUndoKeyChange {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyHaveWarnedAboutUndoKeyChange];
}

+ (void)setHaveWarnedAboutUndoKeyChange:(BOOL)haveWarnedAboutUndoKeyChange {
    [self.userDefaults setBool:haveWarnedAboutUndoKeyChange
                        forKey:iTermUserDefaultsKeyHaveWarnedAboutUndoKeyChange];
}

+ (void)setHaveWarnedAboutUndoCloseShortcutChange:(BOOL)haveWarnedAboutUndoCloseShortcutChange {
    [self.userDefaults setBool:haveWarnedAboutUndoCloseShortcutChange
                        forKey:iTermUserDefaultsKeyHaveWarnedAboutUndoCloseShortcutChange];
}

+ (BOOL)haveShownMacOS13RequirementNotice {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyHaveShownMacOS13RequirementNotice];
}

+ (void)setHaveShownMacOS13RequirementNotice:(BOOL)haveShownMacOS13RequirementNotice {
    [self.userDefaults setBool:haveShownMacOS13RequirementNotice
                        forKey:iTermUserDefaultsKeyHaveShownMacOS13RequirementNotice];
}

+ (BOOL)ignoreSystemWindowRestoration {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyIgnoreSystemWindowRestoration];
}

+ (void)setIgnoreSystemWindowRestoration:(BOOL)ignoreSystemWindowRestoration {
    [self.userDefaults setBool:ignoreSystemWindowRestoration
                        forKey:iTermUserDefaultsKeyIgnoreSystemWindowRestoration];
}

+ (NSUInteger)globalSearchMode {
    return [[self.userDefaults objectForKey:iTermUserDefaultsKeyGlobalSearchMode] unsignedIntegerValue];
}

+ (void)setGlobalSearchMode:(NSUInteger)globalSearchMode {
    [self.userDefaults setObject:@(globalSearchMode) forKey:iTermUserDefaultsKeyGlobalSearchMode];
}

+ (BOOL)addTriggerInstant {
    return [[self.userDefaults objectForKey:iTermUserDefaultsKeyAddTriggerInstant] boolValue];
}

+ (void)setAddTriggerInstant:(BOOL)addTriggerInstant {
    [self.userDefaults setObject:@(addTriggerInstant) forKey:iTermUserDefaultsKeyAddTriggerInstant];
}

+ (BOOL)addTriggerUpdateProfile {
    return [[self.userDefaults objectForKey:iTermUserDefaultsKeyAddTriggerUpdateProfile] boolValue];
}

+ (void)setAddTriggerUpdateProfile:(BOOL)addTriggerUpdateProfile {
    [self.userDefaults setObject:@(addTriggerUpdateProfile) forKey:iTermUserDefaultsKeyAddTriggerUpdateProfile];
}

+ (NSString *)lastSystemPythonVersionRequirement {
    return [self.userDefaults objectForKey:iTermUserDefaultsKeyLastSystemPythonVersionRequirement];
}

+ (void)setLastSystemPythonVersionRequirement:(NSString *)lastSystemPythonVersionRequirement {
    [self.userDefaults setObject:lastSystemPythonVersionRequirement forKey:iTermUserDefaultsKeyLastSystemPythonVersionRequirement];
}

+ (BOOL)probeForPassword {
    NSNumber *n = [self.userDefaults objectForKey:iTermUserDefaultsKeyProbeForPassword] ?: @YES;
    return n.boolValue;
}

+ (void)setProbeForPassword:(BOOL)probeForPassword {
    if (probeForPassword && [iTermAdvancedSettingsModel echoProbeDuration] == 0) {
        // Revert legacy setting when user demonstrates intent to turn probe on.
        [iTermAdvancedSettingsModel setEchoProbeDuration:0.5];
    }
    [self.userDefaults setBool:probeForPassword forKey:iTermUserDefaultsKeyProbeForPassword];
}

+ (NSString *)importPath {
    return [self.userDefaults objectForKey:iTermUserDefaultsKeyImportPath];
}

+ (void)setImportPath:(NSString *)importPath {
    [self.userDefaults setObject:importPath forKey:iTermUserDefaultsKeyImportPath];
}

+ (BOOL)shouldSendReturnAfterPassword {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyShouldSendReturnAfterPassword];
}

+ (void)setShouldSendReturnAfterPassword:(BOOL)shouldSendReturnAfterPassword {
    [self.userDefaults setBool:shouldSendReturnAfterPassword
                        forKey:iTermUserDefaultsKeyShouldSendReturnAfterPassword];
}

+ (NSDictionary<NSString *, NSNumber *> *)windowCornerRadiusCache {
    return [self.userDefaults objectForKey:iTermUserDefaultsKeyWindowCornerRadiusCache];
}

+ (void)setWindowCornerRadiusCache:(NSDictionary<NSString *, NSNumber *> *)windowCornerRadiusCache {
    [self.userDefaults setObject:windowCornerRadiusCache
                          forKey:iTermUserDefaultsKeyWindowCornerRadiusCache];
}

+ (NSData *)workgroupsData {
    return [self.userDefaults objectForKey:iTermUserDefaultsKeyWorkgroupsData];
}

+ (void)setWorkgroupsData:(NSData *)workgroupsData {
    [self.userDefaults setObject:workgroupsData
                          forKey:iTermUserDefaultsKeyWorkgroupsData];
}

+ (BOOL)workgroupShortcutsBackfilled {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyWorkgroupShortcutsBackfilled];
}

+ (void)setWorkgroupShortcutsBackfilled:(BOOL)value {
    [self.userDefaults setBool:value
                        forKey:iTermUserDefaultsKeyWorkgroupShortcutsBackfilled];
}

+ (BOOL)suppressPhysicalKeyBindingSuggestion {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeySuppressPhysicalKeyBindingSuggestion];
}

+ (void)setSuppressPhysicalKeyBindingSuggestion:(BOOL)value {
    [self.userDefaults setBool:value
                        forKey:iTermUserDefaultsKeySuppressPhysicalKeyBindingSuggestion];
}

+ (BOOL)claudeCodeDiffModeBackfilled {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyClaudeCodeDiffModeBackfilled];
}

+ (void)setClaudeCodeDiffModeBackfilled:(BOOL)value {
    [self.userDefaults setBool:value
                        forKey:iTermUserDefaultsKeyClaudeCodeDiffModeBackfilled];
}

+ (BOOL)claudeCodeReviewSystemPromptCommandBackfilled {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyClaudeCodeReviewSystemPromptCommandBackfilled];
}

+ (void)setClaudeCodeReviewSystemPromptCommandBackfilled:(BOOL)value {
    [self.userDefaults setBool:value
                        forKey:iTermUserDefaultsKeyClaudeCodeReviewSystemPromptCommandBackfilled];
}

+ (BOOL)claudeCodeAutoSendClippingsBackfilled {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyClaudeCodeAutoSendClippingsBackfilled];
}

+ (void)setClaudeCodeAutoSendClippingsBackfilled:(BOOL)value {
    [self.userDefaults setBool:value
                        forKey:iTermUserDefaultsKeyClaudeCodeAutoSendClippingsBackfilled];
}

+ (BOOL)claudeCodeAutoRequestReviewBackfilled {
    return [self.userDefaults boolForKey:iTermUserDefaultsKeyClaudeCodeAutoRequestReviewBackfilled];
}

+ (void)setClaudeCodeAutoRequestReviewBackfilled:(BOOL)value {
    [self.userDefaults setBool:value
                        forKey:iTermUserDefaultsKeyClaudeCodeAutoRequestReviewBackfilled];
}

+ (iTermAIModelCatalogUpdateConsent)aiModelCatalogUpdateConsent {
    return [self.userDefaults integerForKey:iTermUserDefaultsKeyAIModelCatalogUpdateConsent];
}

+ (void)setAiModelCatalogUpdateConsent:(iTermAIModelCatalogUpdateConsent)value {
    [self.userDefaults setInteger:value
                           forKey:iTermUserDefaultsKeyAIModelCatalogUpdateConsent];
}

+ (iTermAutoProvideConsent)autoProvideConsent {
    return [self.userDefaults integerForKey:iTermUserDefaultsKeyAutoProvideConsent];
}

+ (void)setAutoProvideConsent:(iTermAutoProvideConsent)value {
    [self.userDefaults setInteger:value
                           forKey:iTermUserDefaultsKeyAutoProvideConsent];
}

+ (BOOL)lastShutdownWasClean {
    static BOOL cachedValue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cachedValue = [self.userDefaults boolForKey:iTermUserDefaultsKeyLastShutdownWasClean];
        // Immediately clear the flag so that a crash between now and the next
        // +markShutdownAsClean is correctly reported as unclean on next launch.
        [self.userDefaults setBool:NO forKey:iTermUserDefaultsKeyLastShutdownWasClean];
        [self.userDefaults synchronize];
    });
    return cachedValue;
}

+ (void)markShutdownAsClean {
    [self.userDefaults setBool:YES forKey:iTermUserDefaultsKeyLastShutdownWasClean];
}

@end
