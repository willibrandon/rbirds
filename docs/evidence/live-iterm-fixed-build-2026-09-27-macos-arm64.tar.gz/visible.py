import json,shutil,subprocess,sys,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from process_usage import Counters
app=str(work/'unpacked/iTerm.app');owned=json.loads((work/'owned-window.json').read_text());window=owned['window'];pid=owned['pid']

def tell(script):
    subprocess.run(['osascript','-e',f'tell application "{app}" to tell current session of (first window whose id is {window})\n'+script+'\nend tell'],check=True)
with Counters() as counters:
    for scene,extra in [('default',[]),('dense',['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember'])]:
        out=work/'visible'/scene;out.mkdir(parents=True);name='rbirds-perf-fixed-'+scene
        request={'title':name,'completed':str(out/'completed.json'),'command':['/usr/bin/env','RBIRDS_TRACE='+str(out/'trace.jsonl'),str(root/'target/release/rbirds'),'--render','kitty','--seed','42','--frames','7200',*extra]}
        (out/'job.json').write_text(json.dumps(request,indent=2)+'\n');temp=work/'job.tmp';temp.write_text(json.dumps(request));temp.replace(work/'job.json')
        time.sleep(3)
        subprocess.run(['osascript','-e',f'tell application "System Events" to tell (first application process whose unix id is {pid})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{name}")\nend tell'],check=True)
        capture=subprocess.Popen([str(root/'target/presentation-capture'),name,str(out/'presentation.json'),'15'])
        memory=[]
        try:
            while capture.poll() is None:
                footprint=counters.snapshot(pid).memory['physical_footprint'];memory.append(footprint)
                if footprint>2*1024**3:raise RuntimeError('two-GiB memory guard')
                time.sleep(1)
            assert capture.returncode==0
            screenshot=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
            (out/'screenshot-path.txt').write_text(screenshot+'\n');shutil.copy2(screenshot,out/'screenshot.png')
        finally:
            if capture.poll() is None:capture.terminate();capture.wait(timeout=10)
            (out/'memory.json').write_text(json.dumps(memory)+'\n');tell('write text "q" newline NO')
        for _ in range(120):
            if (out/'completed.json').exists():
                completed=json.loads((out/'completed.json').read_text());assert completed['status']==0,completed;break
            time.sleep(.5)
        else:raise RuntimeError('owned command did not complete')
        print(scene,'capture done; peak sampled footprint MiB',max(memory)/1024**2,flush=True)
