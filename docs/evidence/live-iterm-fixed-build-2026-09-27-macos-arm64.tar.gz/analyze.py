import collections, json, statistics
from pathlib import Path
import numpy as np
from PIL import Image

work = Path(__file__).resolve().parent
def write(name, data):
    (work / name).write_text(json.dumps(data, indent=2) + '\n')

sustained = {}
for name in ['default', 'dense']:
    out = work / 'sustained' / name
    cpu = json.loads((out / 'cpu.json').read_text())
    obs = json.loads((out / 'observations.json').read_text())
    intervals = cpu['interval_samples']
    assert cpu['measurement_valid'] and len(intervals) == 6
    wall = sum(i['wall_seconds'] for i in intervals)
    summary = {
        'wall_seconds': cpu['wall_seconds'], 'cpu_intervals': len(intervals),
        'application_cpu_ms_per_second': sum(i['application_cpu_seconds'] for i in intervals) * 1000 / wall,
        'terminal_cpu_ms_per_second': sum(i['terminal_cpu_seconds'] for i in intervals) * 1000 / wall,
        'submitted_frames': [[i['trace_alignment']['submitted_frames_min'], i['trace_alignment']['submitted_frames_max']] for i in intervals],
        'terminal_peak_sampled_mib': max(i['memory']['physical_footprint'] for i in obs) / 2**20,
        'owner_active_observations': sum(i.get('owner_active', False) for i in obs),
        'owner_observations': sum('owner_active' in i for i in obs), 'observation_count': len(obs)
    }
    for label, start, end in [('first_minute', 5, 60), ('last_minute', 110, 180)]:
        m = [i['memory']['physical_footprint'] / 2**20 for i in obs if start <= i['elapsed'] < end]
        summary[label + '_footprint_mib'] = {'min': min(m), 'max': max(m), 'mean': statistics.mean(m)}
    summary['app_footprint_first_mib'] = intervals[0]['application_memory']['physical_footprint']['before_bytes'] / 2**20
    summary['app_footprint_last_mib'] = intervals[-1]['application_memory']['physical_footprint']['after_bytes'] / 2**20
    sustained[name] = summary
write('sustained-summary.json', sustained)

visible = {}
for name, path in [('default', 'visible/default/presentation.json'), ('dense', 'visible/dense/presentation.json'), ('paused', 'qualification/paused-presentation.json'), ('events', 'qualification/events-presentation.json')]:
    data = json.loads((work / path).read_text())
    frames = data['frames']; focus = data['focus_observations']
    changed = [f['pts'] for f in frames if f['changed']]
    gaps = np.diff(changed) * 1000
    summary = {
        'samples': len(frames), 'changed_samples': len(changed),
        'dominant_colors': dict(collections.Counter(str(f['dominant_rgb']) for f in frames)),
        'max_dominant_fraction': max(f['dominant_fraction'] for f in frames),
        'focus_observations': len(focus), 'owner_active': sum(f['owner_active'] for f in focus),
        'top_content_window': sum(f['top_normal_window'] for f in focus),
        'capture_cpu_seconds': data['capture_cpu_seconds']
    }
    if len(gaps) and name in ['default', 'dense']:
        summary.update(changes_per_second=(len(changed)-1)/(changed[-1]-changed[0]), p99_gap_ms=float(np.percentile(gaps, 99)), max_gap_ms=float(gaps.max()))
    visible[name] = summary
write('visible-summary.json', visible)

p = work / 'qualification'
a = np.array(Image.open(p / 'static-reference.png').convert('RGBA'))[148:1236, 122:1522].astype(np.int16)
b = np.array(Image.open(p / 'static.png').convert('RGBA'))[148:1236, 122:1522].astype(np.int16)
assert a.shape == b.shape == (1088, 1400, 4)
d = np.max(np.abs(a-b), axis=2)
values, counts = np.unique(d[d != 0], return_counts=True)
y, x = np.nonzero(d)
write('qualification/static-comparison.json', {
    'reference': 'static-reference.png', 'candidate': 'static.png', 'roi': [122, 148, 1522, 1236],
    'differing_pixels': int(np.count_nonzero(d)), 'maximum_channel_difference': int(d.max()),
    'difference_bounds': [int(x.min()), int(y.min()), int(x.max())+1, int(y.max())+1],
    'difference_histogram': dict(zip(map(int, values), map(int, counts))),
    'outside_panel_differing_pixels': int(np.count_nonzero(d)) - int(np.count_nonzero(d[:374, :532])),
    'panel_interior_roi': [15, 21, 520, 350],
    'panel_interior_differing_pixels': int(np.count_nonzero(d[21:350, 15:520])),
    'panel_interior_maximum_channel_difference': int(d[21:350, 15:520].max())
})
