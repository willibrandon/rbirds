import hashlib,json,os,plistlib,subprocess,uuid
from pathlib import Path
work=Path(__file__).resolve().parent
suite='org.rbirds.perf.iterm.20260927'
assert not (Path.home()/'Library/Preferences'/(suite+'.plist')).exists()
raw=subprocess.check_output(['defaults','export','com.googlecode.iterm2','-'])
private=work/'private-user-defaults-before.plist'
fd=os.open(private,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb') as f:f.write(raw)
prefs=plistlib.loads(raw)
profiles=prefs['New Bookmarks'];source=next(p for p in profiles if p['Guid']==prefs['Default Bookmark Guid'])
keys={'Normal Font','Non Ascii Font','Horizontal Spacing','Vertical Spacing','Use Non-ASCII Font','ASCII Anti Aliased','Non-ASCII Anti Aliased','Transparency','Blur','Blur Radius','Blend','Use Bold Font','Use Bright Bold','Minimum Contrast','Use Italic Font','Thin Strokes'}
profile={k:v for k,v in source.items() if k in keys or k.endswith(' Color') or k.startswith('Ansi ') and k.endswith('Color')}
guid=str(uuid.uuid4()).upper()
profile.update({'Guid':guid,'Name':'rbirds-perf-isolated','Rows':32,'Columns':100,'Custom Command':'No','Close Sessions On End':False,'Prompt Before Closing 2':False,'Terminal Type':'xterm-256color'})
owned={'New Bookmarks':[profile],'Default Bookmark Guid':guid,'PromptOnQuit':False,'SUEnableAutomaticChecks':False,'SUAutomaticallyUpdate':False,'SUHasLaunchedBefore':True,'NoSyncIgnoreSystemWindowRestoration':True,'LoadPrefsFromCustomFolder':False,'NoSyncHaveShownMacOS13RequirementNotice':True}
config=work/'test-preferences.plist';config.write_bytes(plistlib.dumps(owned))
subprocess.run(['defaults','import',suite,str(config)],check=True)
info=plistlib.loads((work/'unpacked/iTerm.app/Contents/Info.plist').read_bytes())
(work/'setup.json').write_text(json.dumps({'suite':suite,'bundle_version':info['CFBundleVersion'],'version':info['CFBundleShortVersionString'],'profile_keys':sorted(profile),'user_preferences_sha256':hashlib.sha256(raw).hexdigest(),'zip_sha256':hashlib.sha256((work/'iTerm2-3_7_20260926-nightly.zip').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'suite':suite,'version':info['CFBundleShortVersionString'],'font':profile.get('Normal Font'),'size':[profile['Columns'],profile['Rows']]},indent=2))
