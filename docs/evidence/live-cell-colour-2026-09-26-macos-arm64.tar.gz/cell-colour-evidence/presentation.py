import json
import time
import hashlib
from pathlib import Path
import subprocess

root = Path('/Users/brandon/src/rbirds')
out = root / 'target/live-perf/cell-colour/presentation'
out.mkdir(exist_ok=True)
for mode in ['default', 'blocks']:
    for variant, repeat in [('candidate', 1)]:
        name = f'{mode}-{variant}-{repeat}'
        binary = root / 'target/live-perf' / 'cell-colour/after-rbirds'
        render = [] if mode == 'default' else ['--render', mode]
        cmd = ['open', '-W', '-n', '-a', 'kitty', '--args', '--config', 'NONE',
               '--title', 'rbirds-perf-colour-view-' + name,
               '--override', 'initial_window_width=800', '--override', 'initial_window_height=500',
               '--override', 'remember_window_size=no', '--override', 'macos_quit_when_last_window_closed=yes',
               '/usr/bin/env', 'RBIRDS_TRACE=' + str(out / (name + '.jsonl')),
               '/opt/homebrew/bin/python3', str(root / 'tools/terminal-perf.py'),
               '--output', str(out / (name + '.json')), '--note',
               'Visible Kitty 0.44.0; UFC off; optimized ScreenCaptureKit capture during run; 800x500 logical window',
               '--', str(binary), *render, '--seed', '42', '--frames', '1200']
        process = subprocess.Popen(cmd)
        time.sleep(3)
        capture = out / (name + '-presentation.json')
        subprocess.run([str(root / 'target/presentation-capture'), 'rbirds-perf-colour-view-' + name, str(capture), '12'], check=True)
        shot = subprocess.check_output(['/opt/homebrew/bin/python3', '/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py', '--app', 'kitty', '--window-name', 'rbirds-perf-colour-view-' + name, '--mode', 'temp'], text=True)
        (out / (name + '-screenshot.txt')).write_text(shot)
        report = json.loads(capture.read_text())
        report['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        capture.write_text(json.dumps(report, indent=2) + '\n')
        if process.wait(timeout=90):
            raise RuntimeError('Terminal failed')
        data = json.loads((out / (name + '.json')).read_text())
        print(name, {k: data[k] for k in ['wall_seconds', 'application_cpu_ms_per_second', 'terminal_cpu_ms_per_second']}, flush=True)
