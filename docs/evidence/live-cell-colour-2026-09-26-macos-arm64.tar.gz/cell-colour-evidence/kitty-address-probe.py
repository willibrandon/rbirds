import base64,json,os,select,sys,termios,time,tty
saved=termios.tcgetattr(0);events=[]
def query(label,data):
 os.write(1,data);reply=b'';end=time.monotonic()+.5
 while time.monotonic()<end:
  if select.select([0],[],[],max(0,end-time.monotonic()))[0]:reply+=os.read(0,65536)
 events.append({'label':label,'command':repr(data[:110]),'reply':repr(reply)})
try:
 tty.setraw(0)
 os.write(1,b'\x1b[?1049h\x1b[2J\x1b[H')
 for key,number,color in [('i',71001,bytes([255,0,0,255])),('I',71002,bytes([0,255,0,255]))]:
  payload=base64.b64encode(color*16*16)
  query(key+' upload',f'\x1b_Ga=t,f=32,s=16,v=16,{key}={number};'.encode()+payload+b'\x1b\\')
  column=5 if key=='i' else 20
  query(key+' place',f'\x1b[5;{column}H\x1b_Ga=p,{key}={number},c=8,r=4,C=1\x1b\\'.encode())
  query(key+' crop',f'\x1b[12;{column}H\x1b_Ga=p,{key}={number},x=2,y=2,w=8,h=8,c=8,r=4,C=1\x1b\\'.encode())
 with open(sys.argv[1],'w') as f:json.dump(events,f,indent=2)
 time.sleep(5)
finally:
 os.write(1,b'\x1b_Ga=d,d=I,i=71001\x1b\\\x1b_Ga=d,d=N,I=71002\x1b\\\x1b[?1049l')
 termios.tcsetattr(0,termios.TCSANOW,saved)
