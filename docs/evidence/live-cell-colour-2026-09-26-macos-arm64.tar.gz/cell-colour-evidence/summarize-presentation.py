import json,math
from pathlib import Path
out=Path(__file__).resolve().parent
reports={}
for directory in ['presentation','iterm-kitty']:
 for path in (out/directory).glob('*presentation.json'):
  d=json.loads(path.read_text());fs=d['frames'];points=[f['pts'] for f in fs if f['changed']];ints=[(b-a)*1000 for a,b in zip(points,points[1:])];s=sorted(ints)
  r={'samples':len(fs),'changed':len(points),'visible_updates_per_second':(len(points)-1)/(points[-1]-points[0]) if len(points)>1 else 0,'p99_ms':s[math.ceil(len(s)*.99)-1] if s else None,'max_ms':max(s) if s else None,'gaps_over_25':sum(t>25 for t in ints),'gaps_over_50':sum(t>50 for t in ints),'capture_cpu_seconds':d['capture_cpu_seconds']}
  reports[str(path.relative_to(out))]=r;print(path.name,r)
(out/'presentation-report.json').write_text(json.dumps(reports,indent=2)+'\n')
