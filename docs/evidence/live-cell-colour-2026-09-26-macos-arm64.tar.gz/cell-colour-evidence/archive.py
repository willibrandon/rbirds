import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');src=root/'target/live-perf/cell-colour';stage=root/'target/live-perf/cell-colour-evidence'
stage.mkdir(exist_ok=True)
for p in sorted(src.rglob('*')):
 if not p.is_file() or p.name.endswith('-rbirds') or p.suffix=='.pid':continue
 dst=stage/p.relative_to(src);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
for p in src.rglob('*screenshot.txt'):
 shot=Path(p.read_text().strip());dst=stage/p.relative_to(src).with_suffix('.png');shutil.copy2(shot,dst)
(stage/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','src/render/cells.rs','tests/cells_oracle.rs']))
for name in ['terminal-perf.py','trace-report.py','live-perf.py','presentation-capture.swift']:
 shutil.copy2(root/'tools'/name,stage/name)
for name in ['run-iterm.scpt','completion-exec.py']:
 shutil.copy2(root/'target/live-perf'/name,stage/name)
meta={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binary_sha256':{side:hashlib.sha256((src/(side+'-rbirds')).read_bytes()).hexdigest() for side in ['before','after']},'scope':'Text color selection, exact C comparisons, serial CPU comparisons, separate presentation samples. iTerm Kitty addressing probes are compatibility observations, not CPU comparisons.','host':subprocess.check_output(['sw_vers'],text=True),'build_toolchain':subprocess.check_output(['/Users/brandon/.cargo/bin/rustc','--version'],text=True).strip(),'profile_scope':'Intrusive application stack sample; not performance-comparison evidence','validation_note':'cell-tests.log covers the first deferred-mean prototype; cell-tests-final.log and final-validation.log cover the final early-exit implementation. debug-cell-tests.log includes the focused boundary case.'}
(stage/'provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
files={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(stage/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
archive=root/'docs/evidence/live-cell-colour-2026-09-26-macos-arm64.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(stage,arcname='cell-colour-evidence')
with tarfile.open(archive) as tar:
 manifest=json.load(tar.extractfile('cell-colour-evidence/manifest.json'))
 for name,expected in manifest.items():assert hashlib.sha256(tar.extractfile('cell-colour-evidence/'+name).read()).hexdigest()==expected,name
print(archive.name,archive.stat().st_size,'bytes;',len(files),'verified files')
