import json, re, subprocess, statistics, time, hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
variants={side:out/(side+'-rbirds') for side in ['before','after']}
results=[]
for mode in ['braille','sextants','blocks']:
 command=['--render',mode,'--bench','1000','--seed','42','--sprite',str(out/'shaded.png')]
 for binary in variants.values():subprocess.run([str(binary),*command],stdout=subprocess.DEVNULL,check=True)
 for side in ['before','after','after','before']:
  start=time.monotonic(); raw=subprocess.check_output([str(variants[side]),*command],text=True)
  row={'mode':mode,'variant':side,'command':command,'sha256':hashlib.sha256(variants[side].read_bytes()).hexdigest(),'wall':time.monotonic()-start,'stdout':raw}
  row['ms']=float(re.search(r'frame time\s+(\S+)',raw)[1]);row['bytes']=re.search(r'bytes/frame\s+(\S+)',raw)[1]
  results.append(row)
  (out/'bench-shaded.json').write_text(json.dumps(results,indent=2)+'\n')
 items=[r for r in results if r['mode']==mode]
 assert len({r['bytes'] for r in items})==1
 med={side:statistics.median(r['ms'] for r in items if r['variant']==side) for side in variants}
 print(mode,med,'ratio',med['after']/med['before'],flush=True)
