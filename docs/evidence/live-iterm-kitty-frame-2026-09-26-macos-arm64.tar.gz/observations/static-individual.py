import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=root/'target/live-perf/iterm-kitty-frame';out=work/'static-individual-captures';out.mkdir(exist_ok=True)
for alpha in [0,0.5]:
 for side in ['individual']:
  label=f'{alpha}-{side}';name='rbirds-perf-kitty-static-'+label;complete=out/(label+'-completed.json')
  cmd=shlex.join(['/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(complete),'/opt/homebrew/bin/python3',str(work/'show-scene.py'),str(work/f'static-{side}.bin')])
  w=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),cmd,name],text=True))
  print(label,'window',w,flush=True)
  subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to set transparency of current session of (first window whose id is {w}) to {alpha}'],check=True)
  time.sleep(5)
  shot=subprocess.check_output(['/opt/homebrew/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
  (out/(label+'-screenshot.txt')).write_text(shot+'\n');print(shot,flush=True)
  for _ in range(50):
   if complete.exists():
    assert json.loads(complete.read_text())['status']==0
    break
   time.sleep(.5)
  else:raise RuntimeError('scene did not finish')
  subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {w})'],check=True)
