import json,os,sys,termios,time,tty
from pathlib import Path
root=Path(sys.argv[1]);out=Path(sys.argv[2]);frames=[p.read_bytes() for p in sorted(root.glob('frame-*.bin'))];assert frames
original=termios.tcgetattr(0);tty.setraw(0);samples=[];started=time.monotonic();cpu=time.process_time();deadline=started
try:
 os.write(1,b'\x1b[?1049h\x1b[?25l\x1b[2J\x1b[H')
 i=0
 while time.monotonic()-started<20:
  at=time.monotonic();data=frames[i%len(frames)];sent=0
  while sent<len(data):sent+=os.write(1,data[sent:])
  samples.append({'start':at-started,'write_ms':(time.monotonic()-at)*1000,'bytes':len(data)});i+=1
  deadline=max(deadline+1/60,time.monotonic());time.sleep(max(0,deadline-time.monotonic()))
finally:
 os.write(1,b'\x1b[?2026l\x1b_Ga=d,d=A\x1b\\\x1b[?25h\x1b[?1049l');termios.tcsetattr(0,termios.TCSANOW,original)
 out.write_text(json.dumps({'scope':'Precomputed diagnostic loop, not live simulation or visual equivalence','wall':time.monotonic()-started,'cpu':time.process_time()-cpu,'frames':samples},indent=2)+'\n')
