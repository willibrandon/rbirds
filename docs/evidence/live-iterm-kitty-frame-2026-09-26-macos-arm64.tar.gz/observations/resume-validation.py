import json,subprocess
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');out=root/'target/live-perf/iterm-kitty-frame'
names=sorted(f.stem for f in (root/'tests').glob('*.rs') if f.stem>='pty_kitty_raster')
commands=[]
for mode in ['debug','release']:
 command=['cargo','test']+(['--release'] if mode=='release' else [])+['--all-features','--locked','--offline']
 for name in names:command+=['--test',name]
 commands.append(command)
 with (out/('resumed-'+mode+'.log')).open('w') as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
for name,command in [('final-format',['cargo','fmt','--all','--','--check']),('final-clippy',['cargo','clippy','--all-targets','--all-features','--locked','--offline','--','-D','warnings'])]:
 commands.append(command)
 with (out/(name+'.log')).open('w') as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
(out/'resumed-validation.json').write_text(json.dumps({'status':'passed','reason':'The initial suite stopped at an outdated Kitty startup assertion. The new XTVERSION query is now required explicitly for rbirds; the C prefix is unchanged. Rerun from the affected PTY suites through every later suite in both profiles. Earlier suites already passed and production code did not change.','commands':commands},indent=2)+'\n')
