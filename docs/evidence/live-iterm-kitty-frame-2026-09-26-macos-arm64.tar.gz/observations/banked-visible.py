import json
from pathlib import Path
import shlex
import subprocess
import time

root = Path('/Users/brandon/src/rbirds')
out = root / 'target/live-perf/iterm-kitty-frame/banked-visible'
out.mkdir(exist_ok=True)
for variant in ['default', 'dense']:
    name = 'rbirds-perf-iterm-kitty-frame-' + variant
    binary = root / 'target/live-perf' / 'iterm-kitty-frame/banked-rbirds'
    trace = out / (variant + '.jsonl')
    command = shlex.join(['/usr/bin/env', 'RBIRDS_TRACE=' + str(trace),
                          '/opt/homebrew/bin/python3', str(root / 'target/live-perf/completion-exec.py'),
                          name, str(out / (variant + '-completed.json')), str(binary), '--render', 'kitty', '--seed', '42', '--frames', ('1200' if variant == 'default' else '600')] + ([] if variant == 'default' else ['--birds', '4096', '--speed', '12', '--hawks', '4', '--flocks', '3', '--depth', '--trails', '--color', 'ember']))
    window = subprocess.check_output(['osascript', str(root / 'target/live-perf/run-iterm.scpt'), command, name], text=True).strip()
    print(name, 'window', window, flush=True)
    time.sleep(5)
    subprocess.run([str(root / 'target/presentation-capture'), name, str(out / (variant + '-presentation.json')), '10'], check=True)
    shot=subprocess.check_output(['/opt/homebrew/bin/python3', '/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py', '--app', 'iTerm2', '--window-name', name, '--mode', 'temp'],text=True); (out/(variant+'-screenshot.txt')).write_text(shot)
    for _ in range(160):
        completion = out / (variant + '-completed.json')
        if completion.exists():
            assert json.loads(completion.read_text())['status'] == 0
            break
        time.sleep(.5)
    else:
        raise RuntimeError('command did not finish')
    # Only this newly created test window, after its finite command has ended.
    subprocess.run(['osascript', '-e', f'tell application "/Applications/iTerm.app" to close (every window whose id is {int(window)})'], check=False)
