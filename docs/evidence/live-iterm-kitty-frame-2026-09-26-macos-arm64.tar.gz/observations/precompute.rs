use std::{fs, time::Instant};
use rbirds::{simulation::{Sim,Bird,RenderMode}, image::{Image,png}, render::{Renderer,compose::compose_onto,kitty::KittyGraphics}, spatial_grid::SpatialGrid};
fn main(){
 let out=std::env::args().nth(1).unwrap();fs::create_dir_all(&out).unwrap();
 let mut sim=Sim::new();sim.render_mode=RenderMode::Kitty;sim.config.birds=800;sim.config.palette=1;sim.settle_the_bird_size();sim.apply_notches();sim.apply_screen_size(100,32,1400,1088);sim.rng.seed(42);sim.set_frame_seconds(1.0/60.0);sim.hawk_sets_built=true;
 let mut renderer=Renderer::default();renderer.prepare_text_renderer(&mut sim,None,b"probe").unwrap();let mut canvas=Image::alloc(1400,1088).unwrap();let mut birds=vec![Bird::default();800];let mut snapshot=birds.clone();sim.initialize_birds(&mut birds);sim.place_hawks();let mut grid=SpatialGrid::new(12).unwrap();grid.prepare(1400,1088,800).unwrap();
 let mut timings=Vec::new();let mut graphics=KittyGraphics::new(1).unwrap();
 for frame in 0..720 {sim.snapshot_and_build(&birds,&mut snapshot,&mut grid).unwrap();sim.advance(&mut birds,&mut snapshot,&mut grid);if frame<600 {continue;}
  let start=Instant::now();compose_onto(&sim,&mut canvas,&renderer.sprites,&birds,true);let composed=start.elapsed().as_secs_f64();let encoded=png::encode(&canvas).unwrap();let encoding=start.elapsed().as_secs_f64()-composed;
  graphics.clear();graphics.begin_synchronized_update().unwrap();graphics.delete_all_placements().unwrap();graphics.upload_png(1,&encoded).unwrap();let mut packet=graphics.buffer().to_vec();let at=packet.windows(4).position(|x|x==b",I=1").unwrap();packet[at+1]=b'i';packet.extend_from_slice(b"\x1b[H\x1b_Ga=p,i=1,c=100,r=32,C=1,q=2\x1b\\\x1b[?2026l");fs::write(format!("{out}/frame-{:03}.bin",frame-600),&packet).unwrap();
  timings.push(format!("{{\"compose_ms\":{},\"encode_ms\":{},\"png_bytes\":{},\"protocol_bytes\":{}}}",composed*1000.,encoding*1000.,encoded.len(),packet.len()));
 }
 fs::write(format!("{out}/timings.json"),format!("[{}]\n",timings.join(",\n"))).unwrap();
}
