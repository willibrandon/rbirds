import os,sys,time
from pathlib import Path
try:
 os.write(1,b'\x1b[?1049h\x1b[?25l\x1b[?80l\x1b[0m\x1b[2J\x1b[H')
 data=Path(sys.argv[1]).read_bytes()
 while data:data=data[os.write(1,data):]
 time.sleep(8)
finally:os.write(1,b'\x1b_Ga=d,d=A\x1b\\\x1b[0m\x1b[?80h\x1b[?25h\x1b[?1049l')
