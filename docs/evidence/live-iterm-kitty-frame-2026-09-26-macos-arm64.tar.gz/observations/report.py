import json,statistics
from pathlib import Path
root=Path(__file__).parent
report={'cpu':[],'presentation':[],'traces':[]}
for f in sorted((root/'cpu').glob('*/cpu.json')):
 d=json.loads(f.read_text());s=d['interval_sample'];a=s['application_cpu_ms_per_second'];t=s['terminal_cpu_ms_per_second'];h=s['terminal_helpers']['cpu_ms_per_second'];report['cpu'].append({'case':f.parent.name,'app':a,'terminal':t,'helper':h,'combined':a+t+h})
for p in ['live-prototype','final-visible','events','banked-visible','banked-events','matched-visible','matched-events']:
 for f in sorted((root/p).glob('*presentation.json')):
  d=json.loads(f.read_text());fs=d['frames'];ts=[x['pts'] for x in fs if x['changed']];g=sorted((b-a)*1000 for a,b in zip(ts,ts[1:]));report['presentation'].append({'case':p+'/'+f.name,'samples':len(fs),'changed_rate_hz':(len(ts)-1)/(ts[-1]-ts[0]),'p99_gap_ms':g[int(.99*(len(g)-1))],'max_gap_ms':max(g),'mostly_blank_samples':sum(x['dominant_fraction']>.999 for x in fs),'bright_background_samples':sum(x['dominant_rgb'][0]>70 and x['dominant_fraction']>.8 for x in fs)})
 for f in sorted((root/p).glob('*.jsonl')):
  rows=[json.loads(x) for x in f.read_text().splitlines()]
  if not rows:continue
  s=rows[0];frames=[x for x in rows[1:] if x.get('drawn',True) and x['start_us']>=3000000];
  def metric(k):
   values=sorted(x[k]/1000 for x in frames);return {'p50':statistics.median(values),'p99':values[int(.99*(len(values)-1))],'max':max(values)}
  if not frames:continue
  report['traces'].append({'case':p+'/'+f.name,'summary':s,'stages':{k:metric(k) for k in ['update_us','compose_us','encode_us','flush_us']}})
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['presentation'],indent=2))
