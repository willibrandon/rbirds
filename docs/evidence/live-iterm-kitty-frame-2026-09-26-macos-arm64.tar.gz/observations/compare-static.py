import json
from pathlib import Path
from PIL import Image
import numpy as np
p=Path(__file__).parent;report=[]
for alpha in ['0','0.5']:
 reference=Path((p/'static-individual-z-captures'/f'{alpha}-individual-z-screenshot.txt').read_text().strip())
 candidate=Path((p/'static-captures'/f'{alpha}-after-screenshot.txt').read_text().strip())
 a=np.array(Image.open(reference).convert('RGBA'))[148:1236,122:1522].astype(np.int16)
 b=np.array(Image.open(candidate).convert('RGBA'))[148:1236,122:1522].astype(np.int16)
 assert a.shape==b.shape==(1088,1400,4)
 d=np.max(np.abs(a-b),axis=2);values,counts=np.unique(d[d!=0],return_counts=True)
 report.append({'transparency':float(alpha),'reference':str(reference),'candidate':str(candidate),'roi':[122,148,1522,1236],'differing_pixels':int(np.count_nonzero(d)),'outside_panel_differing_pixels':int(np.count_nonzero(d))-int(np.count_nonzero(d[:374,:532])),'maximum_channel_difference':int(d.max()),'maximum_channel_difference_histogram':dict(zip(map(int,values),map(int,counts)))})
(p/'static-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
