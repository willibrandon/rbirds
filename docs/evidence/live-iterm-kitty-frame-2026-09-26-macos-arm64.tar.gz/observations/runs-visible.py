import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=root/'target/live-perf/iterm-kitty-frame';out=work/'runs-visible';out.mkdir(exist_ok=True);name='rbirds-perf-iterm-kitty-runs'
cmd=shlex.join(['/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),'/opt/homebrew/bin/python3',str(work/'playback.py'),str(work/'precomputed-runs'),str(out/'playback.json')])
w=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),cmd,name],text=True));(out/'window.txt').write_text(str(w));print('window',w,flush=True)
time.sleep(5)
subprocess.run([str(root/'target/presentation-capture'),name,str(out/'presentation.json'),'10'],check=True)
shot=subprocess.check_output(['/opt/homebrew/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py','--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip();(out/'screenshot.txt').write_text(shot+'\n');print(shot,flush=True)
for _ in range(80):
 if (out/'completed.json').exists():assert json.loads((out/'completed.json').read_text())['status']==0;break
 time.sleep(.5)
else:raise RuntimeError('playback did not complete')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {w})'],check=True)
