use rbirds::simulation::{Bird,RenderMode,Sim};
use rbirds::render::{Renderer,compose::KittyRaster,kitty::KittyGraphics};
fn main(){
 let dir=std::env::args().nth(1).unwrap();
 let mut sim=Sim::new(); sim.render_mode=RenderMode::Kitty;sim.config.birds=80;sim.config.trails=true;sim.config.hawks=2;sim.config.flocks=2;sim.config.palette=1;sim.deep_look=true;sim.legend_enabled=true;sim.settle_the_bird_size();sim.apply_screen_size(100,32,1400,1088);
 let mut renderer=Renderer::default();renderer.prepare_text_renderer(&mut sim,None,b"rbirds").unwrap();
 let mut birds=vec![Bird::default();80];
 for (i,bird) in birds.iter_mut().enumerate(){bird.x=370.+(i%10)as f64*28.;bird.y=260.+(i/10)as f64*28.;bird.frame=(i%32)as i32;bird.layer=(i%2)as i32;bird.shade=(i%2)as i32;bird.trail_held=1;bird.trail_at=1;bird.trail_x[0]=bird.x-35.;bird.trail_y[0]=bird.y-25.;}
 sim.hawks[0].x=350.;sim.hawks[0].y=360.;sim.hawks[1].x=740.;sim.hawks[1].y=710.;
 let mut g=KittyGraphics::new(1).unwrap();for (index,sprite) in renderer.sprites.iter().enumerate(){if !sprite.is_empty(){let png=rbirds::image::png::encode(sprite).unwrap();g.upload_png(index as u32+1,&png).unwrap();}}renderer.queue_render_frame(&mut g,&sim,&birds).unwrap();
 let mut protocol=g.buffer().to_vec();for i in 0..protocol.len()-2{if &protocol[i..i+3]==b",I="{protocol[i+1]=b'i';}}
 std::fs::write(format!("{dir}/static-individual.bin"),protocol).unwrap();
 g.clear();renderer.kitty_raster=Some(KittyRaster::default());renderer.queue_render_frame(&mut g,&sim,&birds).unwrap();std::fs::write(format!("{dir}/static-individual-after.bin"),g.buffer()).unwrap();
}
