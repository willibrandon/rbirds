"""Independently decode both captured Kitty streams and compare local RGBA composition."""
import base64,io,json,re,zlib
from pathlib import Path
from PIL import Image
import numpy as np
root=Path(__file__).parent
pattern=re.compile(rb'\x1b\[(\d+);(\d+)H|\x1b_G([^\x1b]*)\x1b\\')
def read(path):
 images={}; placements=[]; row=col=0; parts=[]; metadata={}
 for m in pattern.finditer(path.read_bytes()):
  if m[1] is not None: row,col=int(m[1])-1,int(m[2])-1;continue
  command,_,payload=m[3].partition(b';')
  h=dict(item.decode().split('=',1) for item in command.split(b',') if b'=' in item)
  if h.get('a')=='t': metadata=h;parts=[]
  if payload:
   parts.append(base64.b64decode(payload,validate=True))
   if h.get('m')=='0':
    b=b''.join(parts);id=int(metadata['i'])
    if metadata['f']=='100': im=np.array(Image.open(io.BytesIO(b)).convert('RGBA'))
    else:
     assert metadata['f']=='32' and metadata['o']=='z'
     raw=zlib.decompress(b);w=int(metadata['s']);hh=int(metadata['v']);assert len(raw)==w*hh*4
     im=np.frombuffer(raw,dtype=np.uint8).reshape(hh,w,4)
    images[id]=im
  if h.get('a')=='p':placements.append((int(h['i']),col*14+int(h.get('X',0)),row*34+int(h.get('Y',0)),int(h['z'])))
 return images,placements
old,placements=read(root/'static-individual-z.bin');new,new_placements=read(root/'static-final.bin')
planes=[np.zeros((1088,1400,4),dtype=np.uint8) for _ in range(2)]
for id,x,y,z in sorted(placements,key=lambda p:p[3]):
 src=old[id].astype(np.uint32);dst=planes[int(z>=0)][y:y+src.shape[0],x:x+src.shape[1]]
 a=src[:,:,3];under=dst[:,:,3].astype(np.uint32)*(255-a)//255;alpha=a+under
 for c in range(3):
  numerator=src[:,:,c]*a+dst[:,:,c].astype(np.uint32)*under
  dst[:,:,c]=np.where(alpha!=0,numerator//np.maximum(alpha,1),dst[:,:,c]).astype(np.uint8)
 dst[:,:,3]=alpha.astype(np.uint8)
report=[]
for id,x,y,z in new_placements:
 expected=planes[int(z>=0)];got=np.zeros_like(expected);im=new[id];got[y:y+im.shape[0],x:x+im.shape[1]]=im
 different=int(np.count_nonzero(np.any(got!=expected,axis=2)));assert different==0,(id,different)
 report.append({'id':id,'position':[x,y],'size':[im.shape[1],im.shape[0]],'z':z,'differing_pixels':different})
assert len(report)==2
(root/'transport-check.json').write_text(json.dumps({'reference_sprites':len(old),'reference_placements':len(placements),'surfaces':report},indent=2)+'\n')
print(json.dumps(report))
