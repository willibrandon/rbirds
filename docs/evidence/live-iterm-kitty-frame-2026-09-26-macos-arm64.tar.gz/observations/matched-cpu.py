import json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');out=root/'target/live-perf/iterm-kitty-frame/matched-cpu';out.mkdir(exist_ok=True)
for index,variant in enumerate(['before','after','after','before']):
 d=out/f'{index}-{variant}';d.mkdir(exist_ok=True);name='rbirds-perf-kitty-frame-cpu-'+str(index)+'-'+variant
 binary=root/'target/live-perf'/('iterm-kitty-frame/banked-rbirds' if variant=='before' else 'iterm-kitty-frame/matched-rbirds')
 cmd=shlex.join(['/usr/bin/env','RBIRDS_TRACE='+str(d/'trace.jsonl'),'/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(d/'completed.json'),'/opt/homebrew/bin/python3',str(root/'tools/terminal-perf.py'),'--terminal-pid','73499','--helper-pid','24604','--warmup-seconds','3','--sample-seconds','20','--note','Foreground own 100x32 iTerm 3.6.6 window, ABBA composed surfaces, pixel runs versus pixel runs plus one-probe repeated spans, no capture/profiler/build/test; main process and image decoder helper','--output',str(d/'cpu.json'),'--',str(binary),'--render','kitty','--seed','42','--frames','1800'])
 w=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),cmd,name],text=True));(d/'window.txt').write_text(str(w)+'\n');print(index,variant,'window',w,flush=True)
 for _ in range(180):
  if (d/'completed.json').exists():
   assert json.loads((d/'completed.json').read_text())['status']==0
   break
  time.sleep(.5)
 else:raise RuntimeError('child did not finish')
 subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {w})'],check=True)
 print(index,variant,'done',flush=True)
