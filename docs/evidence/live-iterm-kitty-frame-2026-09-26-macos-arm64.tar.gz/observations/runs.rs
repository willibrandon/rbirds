#[derive(Default)]
pub struct PixelRuns { bytes: Vec<u8>, bits: u64, count: u32 }
impl PixelRuns {
 fn bits(&mut self, value:u32, count:u32){self.bits|=u64::from(value)<<self.count;self.count+=count;while self.count>=8 {self.bytes.push(self.bits as u8);self.bits>>=8;self.count-=8;}}
 fn symbol(&mut self, value:u32){let (code,n)=match value {0..=143=>(value+0x30,8),144..=255=>(value-144+0x190,9),256..=279=>(value-256,7),_=>(value-280+0xc0,8)};self.bits(code.reverse_bits()>>(32-n),n);}
 fn run(&mut self, length:usize){const BASE:[usize;28]=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227];const EXTRA:[u32;28]=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5];let at=BASE.partition_point(|&x|x<=length)-1;self.symbol(257+at as u32);self.bits((length-BASE[at])as u32,EXTRA[at]);self.bits(0b11000,5);}
 pub fn encode(&mut self, rgba:&[u8])->&[u8]{assert!(!rgba.is_empty()&&rgba.len()%4==0);self.bytes.clear();self.bytes.reserve(rgba.len()+rgba.len().div_ceil(8)+16);self.bits=0;self.count=0;self.bytes.extend_from_slice(&[0x78,0x01]);self.bits(3,3);
 let mut at=0;while at<rgba.len(){if at>=4&&rgba[at..at+4]==rgba[at-4..at]{let end=(at+256).min(rgba.len());let mut next=at+4;while next<end&&rgba[next..next+4]==rgba[at..at+4]{next+=4;}self.run(next-at);at=next;}else{for &byte in &rgba[at..at+4]{self.symbol(u32::from(byte));}at+=4;}}
 self.symbol(256);if self.count>0{self.bits(0,8-self.count);}let(mut a,mut b)=(1u32,0u32);for chunk in rgba.chunks(5552){for &byte in chunk{a+=u32::from(byte);b+=a;}a%=65521;b%=65521;}self.bytes.extend_from_slice(&((b<<16)|a).to_be_bytes());&self.bytes}
}
