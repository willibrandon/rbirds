from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path('/Users/brandon/src/rbirds');work=repo/'target/live-perf/iterm-kitty-frame';dest=repo/'target/live-perf/iterm-kitty-frame-evidence'
assert not dest.exists(), 'create the evidence staging directory only once'
dest.mkdir()
for f in sorted(work.rglob('*')):
 if not f.is_file():continue
 if f.parent.name.startswith('precomputed') and f.name not in ['timings.json','frame-000.bin','first.rgba','first.zlib']:continue
 if f.suffix not in ['.py','.rs','.json','.jsonl','.txt','.log','.metal','.rgba','.zlib','.bin']:continue
 target=dest/'observations'/f.relative_to(work);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
shots=[]
for f in sorted(work.rglob('*screenshot.txt')):
 for path in f.read_text().splitlines():
  source=Path(path)
  assert source.name.startswith('codex-shot-') and source.is_file(), str(source)
  target=dest/'screenshots'/f.relative_to(work).with_suffix('.png');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
  shots.append({'original':str(source),'archive':str(target.relative_to(dest))})
(dest/'screenshots.json').write_text(json.dumps(shots,indent=2)+'\n')
changed=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()
changed+=['src/render/pixel_runs.rs','tests/pty_kitty_raster.rs']
for name in changed:
 if name.endswith('.tar.gz'):continue
 target=dest/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,target)
patch=subprocess.check_output(['git','diff','--binary'],cwd=repo)
for name in ['src/render/pixel_runs.rs','tests/pty_kitty_raster.rs']:
 r=subprocess.run(['git','diff','--no-index','--','/dev/null',name],cwd=repo,stdout=subprocess.PIPE);assert r.returncode in [0,1];patch+=r.stdout
(dest/'source.patch').write_bytes(patch)
for name in ['tools/terminal-perf.py','tools/presentation-capture.swift','tools/trace-report.py','target/live-perf/completion-exec.py','target/live-perf/run-iterm.scpt']:
 target=dest/'support'/Path(name).name;target.parent.mkdir(exist_ok=True);shutil.copyfile(repo/name,target)
hashes={name:hashlib.sha256((work/name).read_bytes()).hexdigest() for name in ['before-rbirds','prototype-rbirds','final-rbirds','banked-rbirds','matched-rbirds']}
hashes['older explicit-ID sprite diagnostic']=hashlib.sha256((repo/'target/live-perf/iterm-kitty-ids/prototype-rbirds').read_bytes()).hexdigest()
(dest/'executable-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
(dest/'README.md').write_text('''The source patch is based on 8f24d293298d7f889d5978eebd26d5dcf2399bb2.
The final candidate is matched-rbirds. Executables are excluded.

before-rbirds is the accepted Sixel width-guard build. prototype-rbirds and
final-rbirds reuse displayed IDs and have blank-frame failures. banked-rbirds
stages alternating images with pixel runs only; matched-rbirds adds a single
hash probe for repeated spans. matched-cpu is the qualified compression ABBA
comparison. cpu is the earlier comparison with the slow explicit-ID sprite
diagnostic and does not establish an overall CPU saving over working playback.

All CPU observations were serial and separate from visible capture. Main iTerm
was shared with other sessions; its selected decoder helper remained alive.
Compositor and GPU work are not counted. Presentation timestamps are from
ScreenCaptureKit and cannot establish physical scanout timing.

The final-visible dense driver timed out; q ended it cleanly after 1469 ticks.
Its blank frames invalidate its apparent change rate. banked-visible and
matched-visible retain the corrected captures; matched-events covers controls.
All test windows were owned by these probes and closed afterward.

compare-static.py and check-transport.py use the existing system Python Pillow
and NumPy installation. The former compares display screenshots and records
small composition differences; the latter independently decodes zlib/PNG and
confirms exact local RGBA pixels and positions. These are different claims.

Precomputed playback is diagnostic only and repeats a finite scene. One packet
and timing data are retained for each precompute experiment; the generator can
recreate the remaining packets. Screenshot mappings retain their original
absolute paths and copies within this archive. No personal windows are included.
''')
manifest={str(f.relative_to(dest)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(dest.rglob('*')) if f.is_file()}
(dest/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
out=repo/'docs/evidence/live-iterm-kitty-frame-2026-09-26-macos-arm64.tar.gz'
with tarfile.open(out,'w:gz',compresslevel=9) as tar:
 for f in sorted(dest.rglob('*')):
  if f.is_file():tar.add(f,arcname=str(f.relative_to(dest)))
with tarfile.open(out,'r:gz') as tar:
 saved=json.load(tar.extractfile('MANIFEST.json'));assert saved==manifest
 for name,digest in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest,name
print(json.dumps({'archive':str(out),'files':len(manifest)+1,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
