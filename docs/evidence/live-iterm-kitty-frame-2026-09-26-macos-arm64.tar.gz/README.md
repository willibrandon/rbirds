The source patch is based on 8f24d293298d7f889d5978eebd26d5dcf2399bb2.
The final candidate is matched-rbirds. Executables are excluded.

before-rbirds is the accepted Sixel width-guard build. prototype-rbirds and
final-rbirds reuse displayed IDs and have blank-frame failures. banked-rbirds
stages alternating images with pixel runs only; matched-rbirds adds a single
hash probe for repeated spans. matched-cpu is the qualified compression ABBA
comparison. cpu is the earlier comparison with the slow explicit-ID sprite
diagnostic and does not establish an overall CPU saving over working playback.

All CPU observations were serial and separate from visible capture. Main iTerm
was shared with other sessions; its selected decoder helper remained alive.
Compositor and GPU work are not counted. Presentation timestamps are from
ScreenCaptureKit and cannot establish physical scanout timing.

The final-visible dense driver timed out; q ended it cleanly after 1469 ticks.
Its blank frames invalidate its apparent change rate. banked-visible and
matched-visible retain the corrected captures; matched-events covers controls.
All test windows were owned by these probes and closed afterward.

compare-static.py and check-transport.py use the existing system Python Pillow
and NumPy installation. The former compares display screenshots and records
small composition differences; the latter independently decodes zlib/PNG and
confirms exact local RGBA pixels and positions. These are different claims.

Precomputed playback is diagnostic only and repeats a finite scene. One packet
and timing data are retained for each precompute experiment; the generator can
recreate the remaining packets. Screenshot mappings retain their original
absolute paths and copies within this archive. No personal windows are included.
