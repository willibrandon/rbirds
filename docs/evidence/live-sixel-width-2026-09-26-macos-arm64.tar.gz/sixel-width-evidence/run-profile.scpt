on run argv
    tell application "/Applications/iTerm.app"
        set perfWindow to (create window with profile (item 3 of argv) command (item 1 of argv))
        set bounds of perfWindow to {60, 60, 860, 620}
        tell current session of perfWindow
            set columns to 100
            set rows to 32
            set name to (item 2 of argv)
        end tell
        activate
        return id of perfWindow
    end tell
end run
