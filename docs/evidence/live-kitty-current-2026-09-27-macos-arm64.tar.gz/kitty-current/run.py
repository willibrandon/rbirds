import fcntl
import hashlib
import json
import os
import struct
import subprocess
import sys
import termios
import time
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'tools'))
from process_usage import Counters

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

if len(sys.argv) > 1 and sys.argv[1] == 'child':
    directory = Path(sys.argv[2])
    job = json.loads((directory / 'job.json').read_text())
    parent = os.getppid()
    before = termios.tcgetattr(0)
    save(directory / 'session.json', {'pid': os.getpid(), 'terminal_pid': parent,
         'geometry': struct.unpack('HHHH', fcntl.ioctl(1, termios.TIOCGWINSZ, b'\0' * 8))})
    deadline = time.monotonic() + 30
    while not (directory / 'go').exists():
        if time.monotonic() > deadline:
            raise TimeoutError('controller did not start the owned session')
        time.sleep(.01)
    command = job['command']
    if job['kind'] == 'cpu':
        command = ['/usr/bin/python3', str(root / 'tools/terminal-perf.py'),
                   '--output', str(directory / 'cpu.json'),
                   '--trace', str(directory / 'trace.jsonl'),
                   '--terminal-pid', str(parent), '--fixture-frames', '180:900',
                   '--note', 'Kitty 0.44.0, config NONE, owned foreground window, UFC off; no builds/tests/capture/profile during CPU; memory guard 1 Hz and focus checks every five seconds; same executable repeated',
                   '--', *command]
    environment = os.environ.copy()
    if job['kind'] == 'visible':
        environment['RBIRDS_TRACE'] = str(directory / 'trace.jsonl')
    with (directory / 'stderr.txt').open('w') as errors:
        result = subprocess.run(command, env=environment, stderr=errors)
    after = termios.tcgetattr(0)
    save(directory / 'completed.json', {'status': result.returncode,
         'termios_before': before[:-1], 'termios_after': after[:-1],
         'final_geometry': struct.unpack('HHHH', fcntl.ioctl(1, termios.TIOCGWINSZ, b'\0' * 8)),
         'termios_equal': before == after})
    raise SystemExit(result.returncode)

kind = sys.argv[1]
assert kind in ['cpu', 'visible']
binary = root / ('target/live-perf/fixed-scene/fixture' if kind == 'cpu' else 'target/release/rbirds')
dense = ['--birds', '4096', '--speed', '12', '--hawks', '4', '--flocks', '3', '--depth', '--trails', '--color', 'ember']
cases = [(size, mode) for size in ['normal', 'large-dense'] for mode in ['default', 'kitty', 'blocks', 'sextants']]
with Counters() as counters:
    for size, mode in cases:
        for repeat in range(2 if kind == 'cpu' else 1):
            name = f'{size}-{mode}-{repeat}'
            directory = work / kind / name
            if directory.exists():
                completed = json.loads((directory / 'completed.json').read_text())
                assert completed['status'] == 0, completed
                if kind == 'cpu':
                    assert json.loads((directory / 'cpu.json').read_text())['measurement_valid']
                continue
            directory.mkdir(parents=True)
            title = 'rbirds-perf-kitty-current-' + name
            render = [] if mode == 'default' else ['--render', mode]
            extra = [] if size == 'normal' else dense
            width, height = (800, 500) if size == 'normal' else (1200, 750)
            job = {'kind': kind, 'title': title, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                   'command': [str(binary), '--seed', '42', '--frames', '1080' if kind == 'cpu' else '1500', *render, *extra]}
            save(directory / 'job.json', job)
            command = ['open', '-W', '-n', '-a', 'kitty', '--args', '--config', 'NONE', '--title', title,
                       '--override', f'initial_window_width={width}', '--override', f'initial_window_height={height}',
                       '--override', 'remember_window_size=no', '--override', 'macos_quit_when_last_window_closed=yes',
                       '/usr/bin/python3', str(Path(__file__).resolve()), 'child', str(directory)]
            process = subprocess.Popen(command)
            start = time.monotonic()
            while not (directory / 'session.json').exists():
                if process.poll() is not None or time.monotonic() - start > 20:
                    raise RuntimeError('owned terminal did not start')
                time.sleep(.05)
            session = json.loads((directory / 'session.json').read_text())
            pid = session['terminal_pid']
            assert counters.name(pid) == '/Applications/kitty.app/Contents/MacOS/kitty'
            subprocess.run(['osascript', '-e', f'tell application "System Events" to tell (first application process whose unix id is {pid})\nset frontmost to true\nperform action "AXRaise" of (first window whose name contains "{title}")\nend tell'], check=True)
            (directory / 'go').touch()
            print(kind, name, 'started', 'pid', pid, 'geometry', session['geometry'], flush=True)
            observations = []
            started = time.monotonic()
            captured = False
            while not (directory / 'completed.json').exists():
                elapsed = time.monotonic() - started
                if elapsed > 150:
                    raise TimeoutError('owned terminal command did not finish')
                record = {'seconds': elapsed, 'memory': counters.snapshot(pid).memory}
                if record['memory']['physical_footprint'] > 2 * 1024**3:
                    raise RuntimeError('owned terminal crossed memory guard')
                if len(observations) % 5 == 0:
                    record['owner_active'] = subprocess.check_output(['osascript', '-e', f'tell application "System Events" to get frontmost of (first application process whose unix id is {pid})'], text=True).strip() == 'true'
                observations.append(record)
                if kind == 'visible' and elapsed >= 3 and not captured:
                    subprocess.run([str(root / 'target/presentation-capture'), title, str(directory / 'presentation.json'), '15'], check=True)
                    capture = json.loads((directory / 'presentation.json').read_text())
                    screenshot = subprocess.check_output(['/usr/bin/python3', '/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py', '--window-id', str(capture['window_id']), '--mode', 'temp'], text=True).strip()
                    save(directory / 'screenshot.json', {'path': screenshot})
                    captured = True
                time.sleep(1)
            save(directory / 'observations.json', observations)
            completed = json.loads((directory / 'completed.json').read_text())
            assert completed['status'] == 0, completed
            assert all(o.get('owner_active', True) for o in observations)
            assert process.wait(timeout=20) == 0
            if kind == 'cpu':
                report = json.loads((directory / 'cpu.json').read_text())
                assert report['measurement_valid'], report
            save(directory / 'cleanup.json', {'launcher_exited': True, 'owned_pid': pid,
                 'owned_terminal_exited': subprocess.run(['ps', '-p', str(pid)], stdout=subprocess.DEVNULL).returncode != 0})
            print(kind, name, 'complete', flush=True)
