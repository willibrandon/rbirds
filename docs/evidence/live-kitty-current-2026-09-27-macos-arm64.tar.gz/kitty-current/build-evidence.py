import hashlib
import json
import shutil
import tarfile
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent
stage = work / 'evidence'
stage.mkdir()
names = ['run.py', 'sixel-check.py', 'analyze.py', 'build-evidence.py',
         'environment.json', 'process-tree.json', 'helper-identification.json',
         'cpu-summary.json', 'visible-summary.json']
names += [p.name for p in sorted(work.glob('comparison-*.json'))]
names += [str(p.relative_to(work))
          for folder in ['cpu', 'visible', 'invalid', 'sixel-check', 'sixel-check-initial']
          for p in sorted((work / folder).rglob('*'))
          if p.is_file() and p.suffix in ['.json', '.jsonl', '.png', '.txt']]
assert len(names) == len(set(names))
for name in names:
    destination = stage / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(work / name, destination)
sources = ['tools/terminal-perf.py', 'tools/compare-fixed-scenes.py',
           'tools/process_usage.py', 'tools/measurement_clock.py', 'tools/trace_alignment.py',
           'tools/presentation-capture.swift', 'tools/test_terminal_perf.py',
           'examples/fixed-scene.rs', 'src/fixed_scene.rs', 'src/live.rs', 'src/timing.rs',
           'target/live-perf/query-size.py']
for name in sources:
    destination = stage / 'source' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, destination)
for name in ['fixed-scene-ci-fix-native.log', 'fixed-scene-ci-fix-rosetta.log',
             'fixed-scene-startup-reproduction.log']:
    destination = stage / 'checks' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / 'target' / name, destination)
manifest = {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(stage.rglob('*')) if p.is_file()}
(stage / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'docs/evidence/live-kitty-current-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(stage, arcname='kitty-current')
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        assert hashlib.sha256(tar.extractfile('kitty-current/' + name).read()).hexdigest() == expected, name
result = {'files': len(manifest), 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(work / 'archive.json').write_text(json.dumps(result, indent=2) + '\n')
print(result)
