import json
import os
import subprocess
import sys
import termios
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent / 'sixel-check'
if len(sys.argv) > 1:
    before = termios.tcgetattr(0)
    subprocess.run(['/usr/bin/python3', str(root / 'target/live-perf/query-size.py'), str(work / 'capabilities.json')], check=True)
    queried = termios.tcgetattr(0)
    with (work / 'stderr.txt').open('w') as errors:
        result = subprocess.run([str(root / 'target/release/rbirds'), '--render', 'sixel', '--seed', '42', '--frames', '60'], stderr=errors)
    after = termios.tcgetattr(0)
    (work / 'completed.json').write_text(json.dumps({'status': result.returncode,
        'terminal_pid': os.getppid(), 'query_preserved_termios': before == queried,
        'application_preserved_termios': queried == after,
        'before_query_flags': before[:-1], 'before_application_flags': queried[:-1],
        'after_application_flags': after[:-1], 'pendin': termios.PENDIN}, indent=2) + '\n')
else:
    work.mkdir()
    subprocess.run(['open', '-W', '-n', '-a', 'kitty', '--args', '--config', 'NONE',
                    '--title', 'rbirds-perf-kitty-sixel-check',
                    '--override', 'initial_window_width=800', '--override', 'initial_window_height=500',
                    '--override', 'remember_window_size=no', '--override', 'macos_quit_when_last_window_closed=yes',
                    '/usr/bin/python3', str(Path(__file__).resolve()), 'child'], check=True, timeout=30)
    result = json.loads((work / 'completed.json').read_text())
    result['owned_terminal_exited'] = subprocess.run(['ps', '-p', str(result['terminal_pid'])], stdout=subprocess.DEVNULL).returncode != 0
    (work / 'completed.json').write_text(json.dumps(result, indent=2) + '\n')
    print(result)
    print((work / 'stderr.txt').read_text())
