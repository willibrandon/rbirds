import collections
import importlib.util
import json
import math
import statistics
from pathlib import Path

work = Path(__file__).resolve().parent
source = work / 'source/tools/compare-fixed-scenes.py'
if not source.exists():
    source = work.parents[2] / 'tools/compare-fixed-scenes.py'
spec = importlib.util.spec_from_file_location('compare', source)
compare = importlib.util.module_from_spec(spec)
spec.loader.exec_module(compare)

def percentile(values, percent):
    values = sorted(values)
    index = (len(values) - 1) * percent / 100
    lo = math.floor(index)
    return values[lo] + (values[math.ceil(index)] - values[lo]) * (index - lo)

cpu = []
visible = []
for size in ['normal', 'large-dense']:
    for mode in ['default', 'kitty', 'blocks', 'sextants']:
        name = f'{size}-{mode}'
        paths = [work / 'cpu' / f'{name}-{i}' for i in range(2)]
        compared = compare.compare([json.loads((p / 'cpu.json').read_text()) for p in paths])
        observations = [o for p in paths for o in json.loads((p / 'observations.json').read_text())]
        focus = [o['owner_active'] for o in observations if 'owner_active' in o]
        assert focus and all(focus)
        for p in paths:
            assert json.loads((p / 'cleanup.json').read_text())['owned_terminal_exited']
            assert json.loads((p / 'completed.json').read_text())['termios_equal']
        runs = compared['runs']
        means = {component: statistics.mean(r['cpu_ms_per_frame'][component] for r in runs)
                 for component in ['application', 'terminal', 'combined']}
        combined = [r['cpu_ms_per_frame']['combined'] for r in runs]
        cpu.append({'case': name, 'mean_cpu_ms_per_frame': means,
                    'pair_spread_percent': (max(combined) - min(combined)) / means['combined'] * 100,
                    'wall_seconds': [r['wall_seconds'] for r in runs],
                    'focus_checks': len(focus), 'all_focus_active': all(focus),
                    'maximum_observed_terminal_footprint_bytes': max(o['memory']['physical_footprint'] for o in observations)})
        path = work / 'visible' / f'{name}-0'
        report = json.loads((path / 'presentation.json').read_text())
        samples = report['frames']
        stamps = [f['pts'] for f in samples if f['changed']]
        gaps = [(b - a) * 1000 for a, b in zip(stamps, stamps[1:])]
        focus = report['focus_observations']
        assert all(f['owner_active'] and f['top_normal_window'] for f in focus)
        assert json.loads((path / 'completed.json').read_text())['status'] == 0
        assert json.loads((path / 'cleanup.json').read_text())['owned_terminal_exited']
        visible.append({'case': name, 'samples': len(samples),
                        'changes_per_second': (len(stamps) - 1) / (stamps[-1] - stamps[0]),
                        'p50_ms': percentile(gaps, 50), 'p95_ms': percentile(gaps, 95),
                        'p99_ms': percentile(gaps, 99), 'p999_ms': percentile(gaps, 99.9),
                        'max_ms': max(gaps),
                        'gaps_above_ms': {str(n): sum(g > n for g in gaps) for n in [25, 50, 100]},
                        'dominant_colors': dict(collections.Counter(str(f['dominant_rgb']) for f in samples)),
                        'blank_samples': sum(f['dominant_fraction'] == 1 for f in samples),
                        'focus_checks': len(focus), 'all_focus_active_and_on_top': True,
                        'capture_cpu_seconds': report['capture_cpu_seconds']})
(work / 'cpu-summary.json').write_text(json.dumps(cpu, indent=2) + '\n')
(work / 'visible-summary.json').write_text(json.dumps(visible, indent=2) + '\n')
print(json.dumps({'cpu': cpu, 'visible': visible}, indent=2))
