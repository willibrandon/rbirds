import json,shlex,subprocess,time,shutil
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');out=Path(__file__).resolve().parent
name='rbirds-perf-sixel-position'
command=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,
    str(out/'completed.json'),str(out/'probe'),str(out)])
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True))
(out/'window.txt').write_text(str(window)+'\n');print('own window',window,flush=True)
for index in range(13):
    start=time.monotonic()
    while not (out/'ready').exists() or (out/'ready').read_text()!=str(index):
        if (out/'completed.json').exists():raise RuntimeError((out/'completed.json').read_text())
        if time.monotonic()-start>30:raise RuntimeError('frame not ready')
        time.sleep(.05)
    path=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py',
          '--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
    shutil.copy2(path,out/(str(index)+'.png'));(out/(str(index)+'-screenshot.txt')).write_text(path+'\n')
    print('captured',index,path,flush=True)
    if index in [7,11]:
        columns,rows=(80,24) if index==7 else (100,32)
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window})\nset columns to {columns}\nset rows to {rows}\nend tell'],check=True)
        time.sleep(.5)
    (out/'ack.tmp').write_text(str(index));(out/'ack.tmp').replace(out/'ack')
for _ in range(600):
    if (out/'completed.json').exists():
        result=json.loads((out/'completed.json').read_text());assert result['status']==0,result
        break
    time.sleep(.5)
else:raise RuntimeError('probe did not finish; retain own window')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
print('complete',flush=True)
