use std::{io::Write, time::{Duration, Instant}};
use rbirds::{platform, terminal::{self, Terminal}, render::{Renderer, kitty::KittyGraphics}, simulation::{Bird, RenderMode, Sim}};
fn main() -> std::io::Result<()> {
    let dir = std::path::PathBuf::from(std::env::args().nth(1).unwrap());
    platform::install_signal_handlers();
    let mut term = Terminal::enter()?;
    let negotiated = terminal::prepare_sixel()?;
    assert!(negotiated.erase_before_frame && negotiated.can_position_images);
    term.enter_alt_screen();
    assert!(terminal::sixel_backdrop_is_single_width());
    let mut sim = Sim::new();
    sim.render_mode = RenderMode::Sixel;
    sim.config.birds = 80;
    sim.config.trails = true;
    sim.config.hawks = 2;
    sim.config.flocks = 2;
    sim.config.palette = 1;
    sim.deep_look = true;
    sim.settle_the_bird_size();
    let mut renderer = Renderer::default();
    renderer.prepare_text_renderer(&mut sim, None, b"rbirds").unwrap();
    let mut graphics = KittyGraphics::new(1).unwrap();
    let mut birds = vec![Bird::default(); 80];
    for index in 0..if std::env::args().nth(2).as_deref()==Some("cleanup") {0} else {13} {
        let case = index / 2;
        let size = terminal::graphics_window(platform::window_size_or_zero(1), Some(negotiated.cell_size));
        sim.legend_enabled = case == 4;
        sim.apply_screen_size(size.col.into(), size.row.into(), size.xpixel.into(), size.ypixel.into());
        let (x,y) = match case {
            0 | 6 => (370.,360.),
            1 => (f64::from(size.xpixel)-220., f64::from(size.ypixel)-130.),
            2 => (-30.,-20.),
            3 => (10000.,10000.),
            _ => (150.,240.),
        };
        for (i, bird) in birds.iter_mut().enumerate() {
            bird.x=x+(i%10) as f64*28.; bird.y=y+(i/10) as f64*28.;
            bird.frame=(i%32) as i32; bird.layer=(i%2) as i32; bird.shade=(i%2) as i32;
            bird.trail_held=1; bird.trail_at=1; bird.trail_x[0]=bird.x-35.; bird.trail_y[0]=bird.y-25.;
        }
        sim.hawks[0].x=x-20.; sim.hawks[0].y=y;
        sim.hawks[1].x=x+370.; sim.hawks[1].y=y+350.;
        renderer.erase_sixel_before_frame=true;
        renderer.crop_sixel_frames=index%2==1 || index==12;
        graphics.clear();
        renderer.queue_render_frame(&mut graphics,&sim,&birds).unwrap();
        let mut bytes=graphics.buffer().to_vec();
        if index==12 {
            // Reproduce the old production path while retaining actual startup.
            for mode in [b"\x1b[?80l",b"\x1b[?80h"] {
                if let Some(at)=bytes.windows(mode.len()).position(|b| b==mode) { bytes.drain(at..at+mode.len()); }
            }
        }
        std::fs::write(dir.join(format!("{index}.bin")), &bytes)?;
        std::io::stdout().write_all(&bytes)?;
        std::io::stdout().flush()?;
        std::thread::sleep(Duration::from_millis(400));
        std::fs::write(dir.join("ready.tmp"),index.to_string())?;
        std::fs::rename(dir.join("ready.tmp"),dir.join("ready"))?;
        let start=Instant::now();
        while std::fs::read_to_string(dir.join("ack")).ok().as_deref()!=Some(&index.to_string()) {
            assert!(start.elapsed()<Duration::from_secs(30),"capture did not acknowledge");
            std::thread::sleep(Duration::from_millis(20));
        }
    }
    term.restore();
    drop(term);
    // Exercise the production cleanup at all kinds of partial control sequence.
    let frame = b"\x1b[?2026h\x1b[?80l\x1b[4;5H\x1bP0;1q\"1;1;14;34#0;2;100;0;0#0!14~\x1b\\\x1b[?80h\x1b[?2026l";
    let mut checks=Vec::new();
    for original in [false,true] {
        for cut in 0..=frame.len() {
            platform::reset_terminal_state_for_tests();
            let mut terminal=Terminal::enter()?;
            terminal::write_all(if original {b"\x1b[?80h"} else {b"\x1b[?80l"});
            let options=terminal::prepare_sixel()?;
            assert!(options.can_position_images);
            terminal.enter_alt_screen();
            terminal::write_all(&frame[..cut]);
            terminal.restore();
            drop(terminal);
            platform::reset_terminal_state_for_tests();
            let mut query=Terminal::enter()?;
            let reply=terminal::terminal_query(b"\x1b[?80$p",128,100);
            let expected=if original {b"\x1b[?80;1$y"} else {b"\x1b[?80;2$y"};
            assert_eq!(reply,expected,"original {original}, cut {cut}");
            checks.push(format!("{original},{cut},ok\n"));
            query.restore();
        }
    }
    std::fs::write(dir.join("cleanup.csv"),checks.concat())?;
    // The owned shell's original mode was queried and restored by the first Terminal.
    terminal::write_all(b"\x1b[?80h");
    Ok(())
}
