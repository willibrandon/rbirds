import json,shlex,shutil,subprocess,sys,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
mode=sys.argv[1];assert mode in ['visible','cpu']
for scene in ['default','dense']:
    out=work/mode/scene;out.mkdir(parents=True);name='rbirds-perf-position-'+mode+'-'+scene
    command=[str(root/'target/release/rbirds'),'--render','sixel','--seed','42','--frames','3600']
    if scene=='dense':command+=['--birds','4096','--speed','12','--hawks','4','--flocks','3','--depth','--trails','--color','ember']
    if mode=='cpu':
        command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(out/'cpu.json'),
            '--terminal-pid','73499','--helper-pid','24604','--warmup-seconds','3','--sample-seconds','15',
            '--note','Corrected Sixel placement; absolute post-fix sample, not a comparative saving. No capture, profiler, tests or builds.',
            '--',*command]
    command=['/usr/bin/env','RBIRDS_TRACE='+str(out/'trace.jsonl'),*command]
    wrapped=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),*command])
    start=time.perf_counter();window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapped,name],text=True))
    (out/'window.txt').write_text(str(window)+'\n');print(mode,scene,'own window',window,flush=True)
    if mode=='visible':
        time.sleep(max(0,start+5-time.perf_counter()))
        subprocess.run([str(root/'target/presentation-capture'),name,str(out/'presentation.json'),'30' if scene=='default' else '15'],check=True)
        path=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py',
            '--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
        (out/'screenshot-path.txt').write_text(path+'\n');shutil.copy2(path,out/'screenshot.png')
    else:time.sleep(max(0,start+23-time.perf_counter()))
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'],check=True)
    for _ in range(120):
        if (out/'completed.json').exists():
            result=json.loads((out/'completed.json').read_text());assert result['status']==0,result;break
        time.sleep(.5)
    else:raise RuntimeError('retain unfinished own window')
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
    print('complete',mode,scene,flush=True)
