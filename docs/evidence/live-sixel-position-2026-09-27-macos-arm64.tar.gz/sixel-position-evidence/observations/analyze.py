import json
from collections import Counter
from pathlib import Path
from PIL import Image
import numpy as np
p=Path(__file__).resolve().parent
result=[]
for a,b in [(0,1),(2,3),(4,5),(6,7),(8,9),(10,11),(0,12)]:
    x=np.array(Image.open(p/f'{a}.png').convert('RGB'))
    y=np.array(Image.open(p/f'{b}.png').convert('RGB'))
    w,h=(1120,816) if a in (8,10) else (1400,1088)
    x=x[148:148+h,122:122+w];y=y[148:148+h,122:122+w]
    assert x.shape==y.shape==(h,w,3)
    d=np.max(np.abs(x.astype(int)-y.astype(int)),axis=2)
    result.append(dict(reference=a,candidate=b,width=w,height=h,
        differing_pixels=int(np.count_nonzero(d)),maximum_difference=int(d.max())))
(p/'pixels.json').write_text(json.dumps(result,indent=2)+'\n')
assert all(r['differing_pixels']==0 for r in result[:-1])
assert result[-1]['differing_pixels']>0
visible={}
for scene in ['default','dense']:
    d=json.loads((p/'visible'/scene/'presentation.json').read_text());f=d['frames']
    t=[x['pts'] for x in f if x['changed']];g=sorted(1000*(b-a) for a,b in zip(t,t[1:]))
    visible[scene]={'samples':len(f),'changed_hz':(len(t)-1)/(t[-1]-t[0]),
        'p99_ms':g[int(len(g)*.99)],'max_ms':max(g),'over50ms':sum(x>50 for x in g),
        'dominant_colors':dict(Counter(str(x['dominant_rgb']) for x in f)),
        'max_dominant_fraction':max(x['dominant_fraction'] for x in f),
        'capture_cpu_seconds':d['capture_cpu_seconds']}
(p/'visible/summary.json').write_text(json.dumps(visible,indent=2)+'\n')
