use std::io::Write;
use std::time::{Duration, Instant};
use rbirds::{platform, terminal::Terminal};
fn main() -> std::io::Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let bytes = std::fs::read(&args[1])?;
    let mut frames = Vec::new();
    let mut at = 0;
    while at < bytes.len() {
        let n = u32::from_le_bytes(bytes[at..at + 4].try_into().unwrap()) as usize;
        at += 4;
        frames.push(&bytes[at..at + n]);
        at += n;
    }
    let mut times = Vec::with_capacity(1200);
    platform::install_signal_handlers();
    let mut terminal = Terminal::enter()?;
    rbirds::terminal::prepare_sixel()?;
    terminal.enter_alt_screen();
    assert!(rbirds::terminal::sixel_backdrop_is_single_width());
    let mut output = std::io::stdout().lock();
    output.write_all(b"\x1b[2J")?;
    output.flush()?;
    let mut sleeper = platform::FrameSleeper::new();
    let start = Instant::now();
    let mut input = [0; 1024];
    for (i, frame) in frames.iter().cycle().take(1200).enumerate() {
        let deadline = start + Duration::from_nanos(i as u64 * 1_000_000_000 / 60);
        sleeper.sleep(deadline.saturating_duration_since(Instant::now()));
        if platform::exit_requested() || platform::read(0, &mut input).ok().is_some_and(|n| input[..n].contains(&b'q')) { break; }
        let began = start.elapsed().as_nanos();
        output.write_all(frame)?;
        output.flush()?;
        times.push((began, start.elapsed().as_nanos()));
    }
    terminal.restore();
    let mut file = std::fs::File::create(&args[2])?;
    for (start, end) in times { writeln!(file, "{start},{end}")?; }
    Ok(())
}
