use std::ffi::OsString;
use rbirds::{app::{Program, read_options}, live::LiveLoop, platform::{Timespec, WinSize},
    render::kitty::KittyGraphics, simulation::Bird, spatial_grid::SpatialGrid,
    sprites::PICTURE_GROUND, stdio::CStdout};
fn main() {
    let mut p=Program::new();
    let args:Vec<OsString>=["rbirds","--render","sixel","--seed","42","--birds","4096",
        "--speed","12","--hawks","4","--flocks","3","--depth","--trails","--color","ember"]
        .into_iter().map(OsString::from).collect();
    read_options(&mut p,&args,&mut CStdout::new()).unwrap();
    let sim=&mut p.sim;let renderer=&mut p.renderer;
    sim.settle_the_bird_size();sim.rng.seed(42);sim.apply_screen_size(100,32,1400,1088);
    renderer.prepare_text_renderer(sim,None,b"rbirds").unwrap();
    renderer.erase_sixel_before_frame=true;renderer.crop_sixel_frames=true;
    sim.set_frame_seconds(1.0/60.0);sim.hawk_sets_built=true;
    let mut birds=vec![Bird::default();4096];let mut snapshot=birds.clone();
    sim.initialize_birds(&mut birds);sim.place_hawks();sim.begin_the_intro();
    let mut grid=SpatialGrid::new(12).unwrap();grid.prepare(1400,1088,4096).unwrap();
    let mut output=KittyGraphics::new(1).unwrap();let mut live=LiveLoop::new(Timespec{tv_sec:10,tv_nsec:0},4096);
    for frame in 1..=900 {
        output.clear();
        let ns=frame*16_666_667_i64;
        live.frame(sim,renderer,&mut output,&mut birds,&mut snapshot,&mut grid,None,
            Timespec{tv_sec:10+ns/1_000_000_000,tv_nsec:ns%1_000_000_000},
            WinSize{row:32,col:100,xpixel:1400,ypixel:1088}).unwrap();
        if frame%30==0 {
            let mut cells=vec![b'0';3200];
            for (y,row) in renderer.canvas.pixels.chunks_exact(1400*4).enumerate() {
                for (x,px) in row.chunks_exact(4).enumerate() {
                    if px[..3]!=PICTURE_GROUND {cells[(y/34)*100+x/14]=b'1';}
                }
            }
            println!("{frame} {}",String::from_utf8(cells).unwrap());
        }
    }
}
