import concurrent.futures, json, os, shlex, subprocess, sys, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
if len(sys.argv)>1 and sys.argv[1]=='child':
    (work/'app.pid').write_text(str(os.getpid())+'\n')
    binary=str(root/'target/release/rbirds')
    os.execv(binary,[binary,'--render','sixel','--seed','42','--frames','900',
                    '--birds','4096','--speed','12','--hawks','4','--flocks','3',
                    '--depth','--trails','--color','ember'])
name='rbirds-perf-sixel-dense-profile'
command=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),
                    name,str(work/'completed.json'),'/usr/bin/python3',str(Path(__file__).resolve()),'child'])
window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True))
(work/'window.txt').write_text(str(window)+'\n');print('own window',window,flush=True)
time.sleep(5)
pid=int((work/'app.pid').read_text())
ps=subprocess.check_output(['ps','-axo','pid,ppid,comm'],text=True)
(work/'processes.txt').write_text('\n'.join(line for line in ps.splitlines() if 'iTerm' in line or 'rbirds' in line)+'\n')
def sample(item):
    label,pid=item
    subprocess.run(['sample',str(pid),'3','1','-file',str(work/(label+'.sample.txt'))],check=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(sample,[('application',pid),('iterm',73499),('decoder',24604)]))
for _ in range(360):
    if (work/'completed.json').exists():
        assert json.loads((work/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:raise RuntimeError('finite child did not finish; retain own window')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
print('complete',flush=True)
