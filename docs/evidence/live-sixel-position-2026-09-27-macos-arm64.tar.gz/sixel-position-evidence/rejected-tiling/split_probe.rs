use std::ffi::OsString;
use std::io::Write;
use rbirds::{app::{Program, read_options}, live::LiveLoop, platform::{Timespec, WinSize},
    render::kitty::KittyGraphics, simulation::Bird, spatial_grid::SpatialGrid,
    sprites::PICTURE_GROUND, stdio::CStdout};
fn main() {
    let mut p=Program::new();
    let args:Vec<OsString>=["rbirds","--render","sixel","--seed","42","--birds","4096",
        "--speed","12","--hawks","4","--flocks","3","--depth","--trails","--color","ember"]
        .into_iter().map(OsString::from).collect();
    read_options(&mut p,&args,&mut CStdout::new()).unwrap();
    let sim=&mut p.sim;let renderer=&mut p.renderer;
    sim.settle_the_bird_size();sim.rng.seed(42);sim.apply_screen_size(100,32,1400,1088);
    renderer.prepare_text_renderer(sim,None,b"rbirds").unwrap();
    renderer.erase_sixel_before_frame=true;renderer.crop_sixel_frames=true;
    sim.set_frame_seconds(1.0/60.0);sim.hawk_sets_built=true;
    let mut birds=vec![Bird::default();4096];let mut snapshot=birds.clone();
    sim.initialize_birds(&mut birds);sim.place_hawks();sim.begin_the_intro();
    let mut grid=SpatialGrid::new(12).unwrap();grid.prepare(1400,1088,4096).unwrap();
    let mut output=KittyGraphics::new(1).unwrap();let mut live=LiveLoop::new(Timespec{tv_sec:10,tv_nsec:0},4096);
    let mut original=std::fs::File::create("target/live-perf/sixel-dense-profile/original.frames").unwrap();
    let mut split=std::fs::File::create("target/live-perf/sixel-dense-profile/split.frames").unwrap();
    let mut encoder=rbirds::render::sixel::Sixel::default();
    for frame in 1..=900 {
        output.clear();
        let ns=frame*16_666_667_i64;
        live.frame(sim,renderer,&mut output,&mut birds,&mut snapshot,&mut grid,None,
            Timespec{tv_sec:10+ns/1_000_000_000,tv_nsec:ns%1_000_000_000},
            WinSize{row:32,col:100,xpixel:1400,ypixel:1088}).unwrap();
        if frame>600 {
            let mut cells=vec![b'0';3200];
            for (y,row) in renderer.canvas.pixels.chunks_exact(1400*4).enumerate() {
                for (x,px) in row.chunks_exact(4).enumerate() {
                    if px[..3]!=PICTURE_GROUND {cells[(y/34)*100+x/14]=b'1';}
                }
            }
            let initial=bounds(&cells,(0,0,100,32));
            let mut rectangles=vec![initial];
            while rectangles.len()<4 {
                let mut best=None;
                let mut saving=0;
                for (index,&r) in rectangles.iter().enumerate() {
                    for axis in 0..2 {
                        let (start,end)=if axis==0 {(r.0,r.2)} else {(r.1,r.3)};
                        for cut in start+1..end {
                            let (a,b)=if axis==0 {((r.0,r.1,cut,r.3),(cut,r.1,r.2,r.3))}
                                else {((r.0,r.1,r.2,cut),(r.0,cut,r.2,r.3))};
                            let a=bounds(&cells,a);let b=bounds(&cells,b);
                            let reduced=area(r)-area(a)-area(b);
                            if reduced>saving {saving=reduced;best=Some((index,a,b));}
                        }
                    }
                }
                let Some((index,a,b))=best else {break};
                rectangles.swap_remove(index);rectangles.extend([a,b].into_iter().filter(|r|area(*r)>0));
            }
            let data=output.buffer();
            let dcs=data.windows(2).position(|p|p==b"\x1bP").unwrap();
            let end=dcs+data[dcs..].windows(2).position(|p|p==b"\x1b\\").unwrap()+2;
            let mut candidate=data[..dcs].to_vec();
            for &(x0,y0,x1,y1) in &rectangles {
                candidate.extend_from_slice(format!("\x1b[{};{}H",y0+1,x0+1).as_bytes());
                candidate.extend_from_slice(encoder.encode_region(&renderer.canvas,x0*14,y0*34,(x1-x0)*14,(y1-y0)*34).unwrap());
            }
            candidate.extend_from_slice(&data[end..]);
            assert_eq!(decode_frame(data,1400,1088,14,34),decode_frame(&candidate,1400,1088,14,34),"frame {frame}");
            original.write_all(&(data.len() as u32).to_le_bytes()).unwrap();original.write_all(data).unwrap();
            split.write_all(&(candidate.len() as u32).to_le_bytes()).unwrap();split.write_all(&candidate).unwrap();
            println!("{frame},{},{},{},{},{}",area(initial),rectangles.iter().copied().map(area).sum::<usize>(),rectangles.len(),data.len(),candidate.len());
        }
    }
}

type Rect=(usize,usize,usize,usize);
fn area(r:Rect)->usize {(r.2-r.0)*(r.3-r.1)}
fn bounds(cells:&[u8],r:Rect)->Rect {
 let mut result=(100,32,0,0);
 for y in r.1..r.3 {for x in r.0..r.2 {if cells[y*100+x]==b'1' {
  result.0=result.0.min(x);result.1=result.1.min(y);result.2=result.2.max(x+1);result.3=result.3.max(y+1);
 }}}
 if result.2==0 {(0,0,0,0)} else {result}
}

fn number(bytes: &[u8], at: &mut usize) -> usize {
    let start = *at;
    while bytes.get(*at).is_some_and(u8::is_ascii_digit) {
        *at += 1;
    }
    assert!(*at > start, "missing number at {start}");
    std::str::from_utf8(&bytes[start..*at]).unwrap().parse().unwrap()
}

fn decode(bytes: &[u8]) -> (usize, usize, Vec<[u8; 3]>) {
    assert!(bytes.starts_with(b"\x1bP0;1q\"1;1;"));
    assert!(bytes.ends_with(b"\x1b\\"));
    let mut at = b"\x1bP0;1q\"1;1;".len();
    let width = number(bytes, &mut at);
    assert_eq!(bytes[at], b';');
    at += 1;
    let height = number(bytes, &mut at);
    let mut pixels = vec![None; width * height];
    let mut colours = [[0; 3]; 256];
    let (mut x, mut y, mut colour) = (0, 0, 0);
    while at < bytes.len() - 2 {
        let command = bytes[at];
        at += 1;
        match command {
            b'#' => {
                colour = number(bytes, &mut at);
                if bytes[at] == b';' {
                    at += 1;
                    assert_eq!(number(bytes, &mut at), 2);
                    for channel in &mut colours[colour] {
                        assert_eq!(bytes[at], b';');
                        at += 1;
                        *channel = ((number(bytes, &mut at) * 255 + 50) / 100) as u8;
                    }
                }
            }
            b'$' => x = 0,
            b'-' => {
                x = 0;
                y += 6;
            }
            _ => {
                let (count, bits) = if command == b'!' {
                    let count = number(bytes, &mut at);
                    let bits = bytes[at] - b'?';
                    at += 1;
                    (count, bits)
                } else {
                    assert!((b'?'..=b'~').contains(&command));
                    (1, command - b'?')
                };
                for column in x..x + count {
                    assert!(column < width);
                    for bit in 0..6 {
                        if bits & (1 << bit) != 0 {
                            assert!(y + bit < height, "paint past the final partial band");
                            pixels[(y + bit) * width + column] = Some(colours[colour]);
                        }
                    }
                }
                x += count;
            }
        }
    }
    (
        width,
        height,
        pixels.into_iter().map(|p| p.expect("every raster pixel must be repainted")).collect(),
    )
}

// Interpret the frame's cursor moves, opaque block fills and Sixel rasters.
// Erased text backgrounds remain None: a transparent terminal needs an
// opaque glyph or raster at every pixel, not merely the right SGR colour.
fn decode_frame(bytes: &[u8], width: usize, height: usize, cw: usize, ch: usize) -> Vec<[u8; 3]> {
    let mut pixels = vec![None; width * height];
    let (mut at, mut row, mut col) = (0, 0, 0);
    let mut foreground = None;
    let mut opaque_backdrop = false;
    while at < bytes.len() {
        if bytes[at..].starts_with(b"\x1bP") {
            if opaque_backdrop {
                assert!(
                    pixels.iter().all(Option::is_some),
                    "paint the whole opaque backdrop before replacing its image"
                );
            }
            let end = at + bytes[at..].windows(2).position(|s| s == b"\x1b\\").unwrap() + 2;
            let (w, h, raster) = decode(&bytes[at..end]);
            for y in 0..h {
                for x in 0..w {
                    pixels[(row * ch + y) * width + col * cw + x] = Some(raster[y * w + x]);
                }
            }
            at = end;
            continue;
        }
        let count = if bytes[at..].starts_with("█".as_bytes()) {
            at += "█".len();
            1
        } else {
            assert!(bytes[at..].starts_with(b"\x1b["), "unexpected text at {at}");
            let start = at + 2;
            let end = start + bytes[start..].iter().position(u8::is_ascii_alphabetic).unwrap();
            let parameters = &bytes[start..end];
            at = end + 1;
            if parameters.starts_with(b"?") {
                continue;
            }
            let values: Vec<usize> = if parameters.is_empty() {
                Vec::new()
            } else {
                std::str::from_utf8(parameters)
                    .unwrap()
                    .split(';')
                    .map(|s| s.parse().unwrap())
                    .collect()
            };
            match bytes[end] {
                b'H' => {
                    row = values.first().copied().unwrap_or(1) - 1;
                    col = values.get(1).copied().unwrap_or(1) - 1;
                    continue;
                }
                b'm' => {
                    foreground = values
                        .windows(5)
                        .find(|v| v[..2] == [38, 2])
                        .map(|v| [v[2] as u8, v[3] as u8, v[4] as u8]);
                    continue;
                }
                b'J' => {
                    pixels.fill(None);
                    continue;
                }
                b'b' => values[0],
                other => panic!("unexpected command {other}"),
            }
        };
        opaque_backdrop = true;
        for _ in 0..count {
            for y in row * ch..(row + 1) * ch {
                for x in col * cw..(col + 1) * cw {
                    pixels[y * width + x] = foreground;
                }
            }
            col += 1;
        }
    }
    pixels.into_iter().map(|p| p.expect("every pixel must remain opaque")).collect()
}

