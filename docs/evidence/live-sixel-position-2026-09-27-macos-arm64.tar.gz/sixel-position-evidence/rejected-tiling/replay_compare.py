import hashlib,json,shlex,shutil,subprocess,sys,time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=Path(__file__).resolve().parent
mode=sys.argv[1];assert mode in ['cpu','visible']
out=work/mode;out.mkdir();order=['original','split'] if mode=='visible' else ['original','split','split','original']
for index,side in enumerate(order):
    directory=out/(str(index)+'-'+side);directory.mkdir()
    name='rbirds-perf-sixel-split-'+mode+'-'+str(index)
    command=[str(work/'replay'),str(work/(side+'.frames')),str(directory/'submitted.csv')]
    if mode=='cpu':
        command=['/usr/bin/python3',str(root/'tools/terminal-perf.py'),'--output',str(directory/'cpu.json'),
                 '--terminal-pid','73499','--helper-pid','24604','--warmup-seconds','3','--sample-seconds','15',
                 '--note','Precomposed dense Sixel replay; 300-frame identical-pixel corpus; repeated at a 60Hz ceiling. '
                 'No simulation/composition cost; no capture/profiler/build/tests. Shared iTerm otherwise idle.',
                 '--',*command]
    wrapped=shlex.join(['/usr/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,
                        str(directory/'completed.json'),*command])
    start=time.perf_counter()
    window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),wrapped,name],text=True))
    (directory/'window.txt').write_text(str(window)+'\n');print(mode,side,'own window',window,flush=True)
    if mode=='visible':
        time.sleep(max(0,start+5-time.perf_counter()))
        subprocess.run([str(root/'target/presentation-capture'),name,str(directory/'presentation.json'),'10'],check=True)
        path=subprocess.check_output(['/usr/bin/python3','/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py',
                '--app','iTerm2','--window-name',name,'--mode','temp'],text=True).strip()
        (directory/'screenshot-path.txt').write_text(path+'\n');shutil.copy2(path,directory/'screenshot.png')
    time.sleep(max(0,start+27-time.perf_counter()))
    if not (directory/'completed.json').exists():
        subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to tell current session of (first window whose id is {window}) to write text "q" newline NO'],check=True)
    for _ in range(60):
        if (directory/'completed.json').exists():
            result=json.loads((directory/'completed.json').read_text());assert result['status']==0,result
            break
        time.sleep(.5)
    else:raise RuntimeError('own replay did not quit; retain its window')
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
    if mode=='cpu':
        r=json.loads((directory/'cpu.json').read_text());assert r['measurement_valid'],r
        print(side,r['interval_sample'],flush=True)
    print('complete',mode,side,flush=True)
