import json
from pathlib import Path
import shlex
import subprocess
import time

root = Path('/Users/brandon/src/rbirds')
out = root / 'target/live-perf/text-cadence-probe/visible'
out.mkdir()
for scene, renderer in [('counter', 'kitty')]:
    name = 'rbirds-perf-text-counter-' + scene
    binary = Path('/usr/bin/python3')
    extra = [] if scene != 'dense' else ['--birds', '4096', '--speed', '12', '--hawks', '4', '--flocks', '3', '--depth', '--trails', '--color', 'ember']
    command = shlex.join(['/usr/bin/env', 'RBIRDS_TRACE=' + str(out / (scene + '.jsonl')),
                         '/opt/homebrew/bin/python3', str(root / 'target/live-perf/completion-exec.py'),
                         name, str(out / (scene + '-completed.json')), str(binary), str(root / 'target/live-perf/text-cadence-probe/writer.py'), str(out / 'submitted.json')])
    window = int(subprocess.check_output(['osascript', str(root / 'target/live-perf/run-iterm.scpt'), command, name], text=True))
    (out / (scene + '-window.txt')).write_text(str(window) + '\n')
    print(scene, 'window', window, flush=True)
    time.sleep(5)
    subprocess.run([str(root / 'target/presentation-capture'), name, str(out / (scene + '-presentation.json')), '10'], check=True)
    screenshot = subprocess.check_output(['/opt/homebrew/bin/python3', '/Users/brandon/.codex/skills/screenshot/scripts/take_screenshot.py', '--app', 'iTerm2', '--window-name', name, '--mode', 'temp'], text=True)
    (out / (scene + '-screenshot.txt')).write_text(screenshot)
    for _ in range(400):
        if (out / (scene + '-completed.json')).exists():
            result = json.loads((out / (scene + '-completed.json')).read_text())
            assert result['status'] == 0, result
            break
        time.sleep(.5)
    else:
        raise RuntimeError('finite command has not finished; leave its window for inspection')
    subprocess.run(['osascript', '-e', f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'], check=True)
    print(scene, 'done', flush=True)
