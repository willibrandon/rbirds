import errno, fcntl, json, os, pty, select, subprocess, sys, termios, time, tty
from pathlib import Path
out = Path(sys.argv[1])
master, slave = pty.openpty()
fcntl.ioctl(slave, termios.TIOCSWINSZ, fcntl.ioctl(1, termios.TIOCGWINSZ, bytes(8)))
saved = termios.tcgetattr(0)
chunks = []
reads = []
child = None
try:
    tty.setraw(0)
    child = subprocess.Popen(sys.argv[2:], stdin=slave, stdout=slave, stderr=slave)
    os.close(slave)
    slave = -1
    started = time.perf_counter()
    while True:
        ready, _, _ = select.select([master, 0], [], [], .1)
        if 0 in ready:
            keys = os.read(0, 4096)
            if keys:
                os.write(master, keys)
        if master not in ready:
            continue
        try:
            data = os.read(master, 65536)
        except OSError as error:
            if error.errno != errno.EIO:
                raise
            break
        if not data:
            break
        chunks.append(data)
        reads.append({'seconds': time.perf_counter() - started, 'bytes': len(data)})
        remaining = memoryview(data)
        while remaining:
            remaining = remaining[os.write(1, remaining):]
    status = child.wait(timeout=10)
finally:
    if child is not None and child.poll() is None:
        child.kill()
        child.wait()
    if slave >= 0:
        os.close(slave)
    os.close(master)
    termios.tcsetattr(0, termios.TCSANOW, saved)
    (out/'stream.bin').write_bytes(b''.join(chunks))
    (out/'reads.json').write_text(json.dumps(reads)+'\n')
raise SystemExit(status)
