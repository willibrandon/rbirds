import hashlib, json, shlex, subprocess, sys, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');sys.path.insert(0,str(root/'tools'))
from process_usage import Counters,cpu_delta
work=root/'target/live-perf/text-cadence-probe';out=work/'warm-cpu';out.mkdir()
name='rbirds-perf-text-warm-cpu'
command=shlex.join(['/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),str(work/'replay-rbirds'),str(work/'twice-frames.bin'),str(out/'submitted.csv')])
started=time.perf_counter();window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True));(out/'window.txt').write_text(str(window)+'\n');print('own window',window,flush=True)
def until(deadline):
    while (left:=deadline-time.perf_counter())>0:time.sleep(max(left,.001))
rows=[]
with Counters() as counters:
    for label,offset in [('first',5),('repeat',25)]:
        until(started+offset)
        before={pid:counters.snapshot(pid) for pid in [73499,24604]};begin=time.perf_counter()
        until(begin+15)
        after={pid:counters.snapshot(pid) for pid in before};end=time.perf_counter()
        rows.append({'pass':label,'start_seconds_after_launch':begin-started,'wall_seconds':end-begin,'cpu_ms_per_second':{str(pid):cpu_delta(before[pid],after[pid])/(end-begin)*1000 for pid in before}})
        print(label,rows[-1],flush=True)
    report={'scope':'iTerm main and stable decoder helper; 15second windows in the first and repeated identical20second text replay; no capture profile builds tests','counters':counters.metadata,'terminal_pid':73499,'terminal_name':counters.name(73499),'helper_pid':24604,'frames_sha256':hashlib.sha256((work/'twice-frames.bin').read_bytes()).hexdigest(),'samples':rows}
    (out/'cpu.json').write_text(json.dumps(report,indent=2)+'\n')
for _ in range(50):
    if (out/'completed.json').exists():
        assert json.loads((out/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:raise RuntimeError('finite replay did not complete')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
print('complete',flush=True)
