# Preliminary text presentation checks

Production head ec4db12 contains the accepted shared-image change plus the CPU
harness deadline correction. These diagnostic probes do not modify production
code or terminal preferences.

A simple 60 Hz numbered text counter with synchronized updates recorded 59.96
changed images/s in 894 ScreenCaptureKit samples. Its emitted rate was 59.98 Hz;
Python sleep had noticeable jitter (24.11 ms p99), so this is not a pacing gold
standard. It only establishes that a small text stream can update near 60 Hz
in this window. The inspected screenshot contained the expected counter. Its
own window 22188 closed after a status-zero finite run.

The relay probe forwards rbirds output through an additional PTY and retains
its bytes. Its timing can be affected by that relay. The purpose is to check
which submitted frames actually change the text grid after color quantization,
then compare separately observed content changes. This is not CPU evidence.

iTermUpdateCadenceController.m was retrieved from the official v3.6.6 source:
https://github.com/gnachman/iTerm2/blob/v3.6.6/sources/iTermUpdateCadenceController.m
The nonadaptive branch calls setUpdateCadence but then falls through to the
adaptive branch; this may matter, but it has NOT been established as the
measured frame-gap cause. Do not change user preferences based on this lead.
Readonly checks found no explicit values for useGCDUpdateTimer,
activeUpdateCadence, maximumFrameRate, adaptiveFrameRateThroughputThreshold
or metalSlowFrameRate in the current preferences domain.

The relay run reproduced the lower visible rate: 54.95 changes/s across 920
samples, p99 gap 51.70 ms, maximum 70.88 ms. All 1,020 submitted frames after
three seconds changed the decoded glyph grid, with at least 378 changed glyphs
per frame. That rules out identical emitted glyph grids in this run. The
application trace had a 16.83 ms p99 interval and 20.25 ms maximum. The extra
PTY and capture remain limitations; this does not isolate terminal scheduling
from capture coalescing. Own window 22194 completed with status zero and closed.
The analyzer checks every sequence it encounters, tracks absolute/relative
cursors, ignores SGR for the glyph-only comparison, and normalizes blank braille
to a space. Color changes cannot inflate the changed-glyph count.

A native Rust replayer then sent the identical 1,200 recorded frames using
rBirds' FrameSleeper, without simulation, composition, or the forwarding PTY.
It still measured 55.17 visible changes/s (873 samples; 47.16 ms p99 gap,
79.69 ms maximum). Write-completion intervals after warmup had a 17.12 ms p99
and 17.95 ms maximum. This does not support treating application composition
jitter as the explanation for this case. The screenshot was inspected and
the status-zero finite run closed its own window 22200. No source change was
made on the basis of this probe.

The recorded stream used truecolor foregrounds, with no identical repeated
foreground escape when respecting resets. It contained 46,180 resets and
137,660 foreground-color commands across 1,200 frames. A possible later
optimization is to preserve the foreground across blank cells when no
background is active, avoiding reset/set pairs that cannot affect those
spaces. This requires decoded-screen equality and CPU/presentation evidence
before any production change. Keep default C-oracle behavior when evaluating
a live-only alternative.

A deferred-foreground prototype (compact_styles.py) preserved all 3.84 million
compared glyph/color cells for the 1,200-frame Braille corpus, while reducing
bytes13.68% andSGRcommands39.18%. Four isolated ABBA replay runs measured median
iTerm CPU580.15ms/s original versus575.60ms/s compact, a0.79% reduction. Visible
compact replay stayed55.99changes/s with45.29ms p99gap and74.17ms maximum. This
does not establish a meaningful fix for text pacing, and no production change
is retained. Foreground retention also changes the latent foreground attribute
of blank cells, which some selection/cursor styles could reveal; decoded equality
in this probe covers normal unselected cells, not those emulator states.
Own compact-visiblewindow22206 and CPUwindows22214/16/18/20 completed and closed.

A separate intrusive three-second iTerm sample found 1,614 wall-stack samples
in addNonASCII and 1,601 in metalImagesForGlyphKey. This is a glyph construction
lead, not a CPU percentage or cadence measurement. The official v3.6.6 glyph
key includes visual column but not foreground color. The text cache permits
65,536 glyph entries, so these observations do not prove capacity thrashing.
The same GlyphKey.h in v3.6.11 is byte-identical. No preference was changed.

Two identical 20-second passes in the same window measured 54.65 then 60.08
visible changes/s. Separate quiet 15-second CPU intervals measured iTerm at
581.91 then 450.91 ms/s, a 22.5% reduction. The stable helper used zero CPU.
Replaying an unchanged corpus isolates warm-up better than comparing different
parts of a changing simulation. Own windows 22224 and 22234 closed normally.

The revised CPU harness then sampled the actual default simulation around
seconds 3–18 and 43–58 in one 3,600-frame run. Application CPU was 216.10 then
221.72 ms/s; iTerm was 571.97 then 446.12 ms/s; helper CPU was zero. The report
was valid and the finite child exited successfully. Both sample windows precede
the 60-second idle threshold; no input was injected to alter the scene.

A separate actual-simulation capture measured 56.43 then 59.88 changes/s, with
p99 gaps of 50.21 then 30.33 ms and maximum gaps of 80.63 then 36.05 ms. The
application trace still had five isolated intervals above 25 ms, none above
50 ms. Do not call the startup cadence fixed or promise stall-free playback.
The driver first read completed.json between creation and the JSON write;
rereading confirmed status zero and own window 22239 was closed explicitly.
The launcher now publishes future completion files with atomic replacement.
The original measurements and failed driver log remain intact.
