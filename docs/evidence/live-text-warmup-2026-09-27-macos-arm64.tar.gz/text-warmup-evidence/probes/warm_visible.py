import json, shlex, subprocess, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=root/'target/live-perf/text-cadence-probe';out=work/'warm-visible';out.mkdir()
name='rbirds-perf-text-warm-replay'
command=shlex.join(['/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),str(work/'replay-rbirds'),str(work/'twice-frames.bin'),str(out/'submitted.csv')])
started=time.monotonic();window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True));(out/'window.txt').write_text(str(window)+'\n');print('own window',window,flush=True)
for label,offset in [('first',5),('repeat',25)]:
    time.sleep(max(0,started+offset-time.monotonic()))
    subprocess.run([str(root/'target/presentation-capture'),name,str(out/(label+'-presentation.json')),'10'],check=True)
for _ in range(100):
    if (out/'completed.json').exists():
        assert json.loads((out/'completed.json').read_text())['status']==0
        break
    time.sleep(.5)
else:raise RuntimeError('finite replay did not complete')
subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
print('complete',flush=True)
