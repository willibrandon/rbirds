import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import tarfile

root = Path('/Users/brandon/src/rbirds')
work = root / 'target/live-perf/text-cadence-probe'
stage = root / 'target/live-perf/text-warmup-evidence'
stage.mkdir()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

excluded = {'replay-rbirds', 'frames.bin', 'compact-frames.bin', 'twice-frames.bin',
            'iterm.sample.txt'}
for source in sorted(work.rglob('*')):
    if not source.is_file() or source.name in excluded or source.suffix in {'.h', '.m', '.mm'}:
        continue
    dest = stage / 'probes' / source.relative_to(work)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)

profile = (work / 'profile/iterm.sample.txt').read_text().splitlines()
(stage / 'probes/profile/iterm.sample.excerpt.txt').write_text(
    'Selected header and glyph-construction branch from the intrusive sample.\n'
    'These are wall-stack counts, not percentages of CPU time.\n\n' +
    '\n'.join(profile[:35]) + '\n\nOriginal lines 1010–1060:\n' +
    '\n'.join(profile[1009:1060]) + '\n')

for relative in ['tools/terminal-perf.py', 'tools/test_terminal_perf.py',
                 'tools/process_usage.py', 'tools/trace-report.py',
                 'tools/presentation-capture.swift', 'rust-toolchain.toml',
                 'target/live-perf/completion-exec.py', 'target/live-perf/run-iterm.scpt']:
    dest = stage / 'source' / Path(relative).name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / relative, dest)
(stage / 'source.patch').write_bytes(subprocess.check_output([
    'git', 'diff', '--', 'tools/terminal-perf.py', 'tools/test_terminal_perf.py']))
metadata = {
    'parent_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'platform': platform.platform(),
    'application_sha256': sha(root / 'target/release/rbirds'),
    'replayer_sha256': sha(work / 'replay-rbirds'),
    'full_profile_sha256': sha(work / 'profile/iterm.sample.txt'),
    'regenerable_inputs': {name: sha(work / name) for name in
                          ['frames.bin', 'compact-frames.bin', 'twice-frames.bin']},
    'local_validation': [
        {'command': '/usr/bin/python3 tools/test_terminal_perf.py',
         'python': '3.9.6', 'tests': 15, 'result': 'passed', 'elapsed_seconds': 4.824},
        {'command': '/opt/homebrew/bin/python3 tools/test_terminal_perf.py',
         'python': '3.14.7', 'tests': 15, 'result': 'passed', 'elapsed_seconds': 4.947}],
    'validation_note': 'Local test summaries transcribed from tool output; not raw test logs. '
                       'ci-ec4db12.json is the preceding commit, before repeated sampling.',
}
(stage / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
(stage / 'README.txt').write_text('''Text warm-up investigation on M4 Pro, macOS 26.5.2 and iTerm 3.6.6.

Production rendering is unchanged from metadata.json's parent. This change adds
repeated CPU intervals and records the effect of terminal glyph cache warm-up.
The default single-interval JSON schema remains unchanged.

probes/relay retains the extra-PTY stream and glyph-grid analysis. The native
Rust replayer sends the same recorded frames without simulation or composition.
warm-visible and warm-cpu repeat the identical 20-second corpus in one window;
capture and quiet CPU observations are separate. live-warm-cpu uses the revised
harness with the actual default simulation in windows around seconds 3–18 and
43–58. live-warm-visible separately captures the actual default scene in those
parts of its run. The simulation changes naturally within a fixed configuration.
Both measured windows precede the 60-second idle threshold.

compact_styles.py is a rejected prototype. Normal unselected glyph/color cells
match, but retained foregrounds can change selection/cursor behavior on blank
cells. Bytes and SGR counts fall without a meaningful CPU or pacing improvement.
No production style change was retained.

The profile excerpt is intrusive diagnostic evidence. Stack counts are not CPU
percentages. Official iTerm source URLs and checked hashes are retained without
redistributing those sources. Glyph keys include visual column, and the cache
allows 65,536 entries; these observations do not establish capacity thrashing.

The relay stream is the canonical frame input. To reconstruct frames.bin, extract
each full ESC[?2026h ... ESC[?2026l block (DOTALL, nongreedy), prefix each with its
little-endian uint32 byte length, and concatenate. There are 1,200 frames.
twice-frames.bin concatenates that framed file with itself. compact_styles.py
regenerates compact-frames.bin. metadata.json retains all three expected hashes.
Build replay.rs with rustc --edition=2024 -O, --extern pointing to the release
librbirds.rlib and -L dependency=target/release/deps from the recorded parent.

Drivers contain original absolute paths and owned process/window IDs. Adapt
those to fresh output directories and currently owned processes before reuse.
They only controlled rbirds-perf windows. The completion wrapper in source/
includes the atomic-publication correction after the visible driver's JSON read
race. That original error log is retained; the child exited successfully and
the owned window was subsequently closed. No installed executable or terminal
preference was replaced. Screenshots are of the owned test windows only.

Presentation compares every content pixel at the logical capture resolution.
Color/blank diagnostics sample a grid. Captures are not physical scanout, and
no individual displayed frame IDs were decoded. Quiet CPU runs have no capture,
profiler, build or tests; shared iTerm sessions, compositor/GPU and unknown helper
costs limit attribution. Measurements describe this host and these runs.
''')
manifest = {str(p.relative_to(stage)): sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}
(stage / 'SHA256.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'docs/evidence/live-text-warmup-2026-09-27-macos-arm64.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(stage, arcname='text-warmup-evidence')
with tarfile.open(archive) as tar:
    for name, expected in manifest.items():
        data = tar.extractfile('text-warmup-evidence/' + name).read()
        assert hashlib.sha256(data).hexdigest() == expected, name
print(json.dumps({'archive': str(archive), 'files_verified': len(manifest),
                  'bytes': archive.stat().st_size, 'sha256': sha(archive)}, indent=2))
