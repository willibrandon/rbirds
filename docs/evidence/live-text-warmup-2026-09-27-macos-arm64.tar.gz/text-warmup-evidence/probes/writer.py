import json, os, select, sys, termios, time, tty
from pathlib import Path
original = termios.tcgetattr(0)
samples = []
try:
    tty.setraw(0)
    os.write(1, b"\x1b[?1049h\x1b[?25l\x1b[0m\x1b[2J\x1b[2;4H60 Hz text timing check")
    start = time.monotonic()
    for frame in range(1200):
        left = start + frame / 60 - time.monotonic()
        if left > 0:
            time.sleep(left)
        if select.select([0], [], [], 0)[0] and b'q' in os.read(0, 1024):
            break
        packet = f"\x1b[?2026h\x1b[4;4HFrame {frame:04d}   {'#' * (frame % 32 + 1):32s}\x1b[?2026l".encode()
        at = time.monotonic() - start
        os.write(1, packet)
        samples.append(at)
finally:
    os.write(1, b"\x1b[0m\x1b[?2026l\x1b[?25h\x1b[?1049l")
    termios.tcsetattr(0, termios.TCSANOW, original)
    Path(sys.argv[1]).write_text(json.dumps({'submitted_seconds': samples, 'rate': 60}) + '\n')
