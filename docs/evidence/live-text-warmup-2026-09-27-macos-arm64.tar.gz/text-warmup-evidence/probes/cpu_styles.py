import json, shlex, subprocess, time
from pathlib import Path
root=Path('/Users/brandon/src/rbirds');work=root/'target/live-perf/text-cadence-probe'
for index,variant in enumerate(['original','compact','compact','original']):
    out=work/'cpu-styles'/f'{index}-{variant}';out.mkdir(parents=True)
    name=f'rbirds-perf-text-styles-{index}-{variant}'
    frames=work/('frames.bin' if variant=='original' else 'compact-frames.bin')
    command=shlex.join(['/opt/homebrew/bin/python3',str(root/'target/live-perf/completion-exec.py'),name,str(out/'completed.json'),'/opt/homebrew/bin/python3',str(root/'tools/terminal-perf.py'),'--terminal-pid','73499','--helper-pid','24604','--warmup-seconds','3','--sample-seconds','15','--note','Foreground iTerm3.6.6 100x32 native1400x1088; identical decoded text frames replayed60Hz; ABBA original versus deferred blank-cell foreground; no capture profiler builds tests; measures terminal work not full rbirds CPU','--output',str(out/'cpu.json'),'--',str(work/'replay-rbirds'),str(frames),str(out/'submitted.csv')])
    window=int(subprocess.check_output(['osascript',str(root/'target/live-perf/run-iterm.scpt'),command,name],text=True));(out/'window.txt').write_text(str(window)+'\n');print(index,variant,'window',window,flush=True)
    for _ in range(100):
        if (out/'completed.json').exists():
            completed=json.loads((out/'completed.json').read_text());assert completed['status']==0,completed
            break
        time.sleep(.5)
    else:raise RuntimeError('finite replay did not complete; leave own window for inspection')
    report=json.loads((out/'cpu.json').read_text());assert report['measurement_valid'] and report['status']==0,report
    subprocess.run(['osascript','-e',f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],check=True)
    print(index,variant,'complete',flush=True)
