import hashlib, json, re, struct
from pathlib import Path
work=Path(__file__).parent
raw=(work/'relay/stream.bin').read_bytes()
frames=re.findall(rb"\x1b\[\?2026h.*?\x1b\[\?2026l",raw,re.S)
TOKEN=re.compile(r"\x1b\[([0-?]*)([ -/]*)([@-~])|([^\x1b]+)")
def tokens(data):
    text=data.decode();end=0
    for m in TOKEN.finditer(text):
        assert m.start()==end;end=m.end();yield m
    assert end==len(text)
def colour(params):
    if params=='0':return None
    parts=params.split(';')
    assert parts[:2]==['38','2'] and len(parts)==5,parts
    return tuple(map(int,parts[2:]))
def compact(frame):
    wanted=actual=None;out=[]
    for m in tokens(frame):
        if m.group(4) is None and m.group(3)=='m':
            wanted=colour(m.group(1));continue
        if m.group(4) is not None and m.group(4).strip(' \u2800'):
            if wanted!=actual:
                out.append('\x1b[0m' if wanted is None else '\x1b[38;2;'+ ';'.join(map(str,wanted))+'m')
                actual=wanted
        if m.group(1)=='?2026' and m.group(3)=='l':
            assert wanted is None
            if actual is not None:out.append('\x1b[0m')
            actual=None
        out.append(m.group())
    return ''.join(out).encode()
class Grid:
    def __init__(self):
        self.cells=[(' ',None)]*3200;self.x=self.y=0;self.fg=None
    def frame(self,data):
        for m in tokens(data):
            text=m.group(4)
            if text is not None:
                for char in text:
                    assert 0<=self.x<100 and 0<=self.y<32
                    char=' ' if char=='\u2800' else char
                    self.cells[self.y*100+self.x]=(char,self.fg if char!=' ' else None)
                    self.x+=1
            else:
                p,intermediate,c=m.group(1,2,3);assert not intermediate
                if c=='m':self.fg=colour(p)
                elif c=='H':
                    row,col=p.split(';');self.x=int(col)-1;self.y=int(row)-1
                elif c=='C':self.x+=int(p)
                else:assert p=='?2026' and c in 'hl',(p,c)
        assert self.fg is None
old,new=Grid(),Grid();compacted=[]
for i,frame in enumerate(frames):
    candidate=compact(frame);old.frame(frame);new.frame(candidate)
    assert old.cells==new.cells,(i,'visible cells differ')
    assert (old.x,old.y)==(new.x,new.y),(i,'cursor differs')
    compacted.append(candidate)
packed=b''.join(struct.pack('<I',len(f))+f for f in compacted)
(work/'compact-frames.bin').write_bytes(packed)
summary={'frames':len(frames),'cells_compared':len(frames)*3200,'original_bytes':sum(map(len,frames)),'compact_bytes':sum(map(len,compacted)),'original_sgr':sum(len(re.findall(rb"\x1b\[[0-9;]*m",f)) for f in frames),'compact_sgr':sum(len(re.findall(rb"\x1b\[[0-9;]*m",f)) for f in compacted),'original_sha256':hashlib.sha256((work/'frames.bin').read_bytes()).hexdigest(),'compact_sha256':hashlib.sha256(packed).hexdigest(),'scope':'Recorded truecolor Braille stream with no background colors. Exact glyph/foreground grid and final cursor/pen equality; not a general ANSI optimizer.'}
(work/'compact-styles.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
