import json
from pathlib import Path
import shlex
import subprocess
import sys
import time

root = Path('/Users/brandon/src/rbirds')
mode = sys.argv[1]
assert mode in ('cpu', 'visible')
out = root / 'target/live-perf/text-cadence-probe' / ('live-warm-' + mode)
out.mkdir()
name = 'rbirds-perf-live-text-warm-' + mode
command = [str(root / 'target/release/rbirds'), '--seed', '42', '--frames', '3600']
if mode == 'cpu':
    command = ['/usr/bin/python3', str(root / 'tools/terminal-perf.py'),
               '--output', str(out / 'cpu.json'), '--terminal-pid', '73499',
               '--helper-pid', '24604', '--warmup-seconds', '3', '--sample-seconds', '15',
               '--sample-count', '2', '--sample-gap-seconds', '25',
               '--note', 'iTerm 3.6.6, own visible 100x32 window; default Braille; '
               '60second run before first idle drift; no capture, profiling, builds or tests; '
               'UFC off; existing shared iTerm process otherwise idle', '--', *command]
else:
    command = ['/usr/bin/env', 'RBIRDS_TRACE=' + str(out / 'trace.jsonl'), *command]
wrapped = shlex.join(['/usr/bin/python3', str(root / 'target/live-perf/completion-exec.py'),
                      name, str(out / 'completed.json'), *command])
started = time.perf_counter()
window = int(subprocess.check_output([
    'osascript', str(root / 'target/live-perf/run-iterm.scpt'), wrapped, name], text=True))
(out / 'window.txt').write_text(str(window) + '\n')
print('own window', window, flush=True)
if mode == 'visible':
    for label, offset in [('early', 5), ('later', 45)]:
        time.sleep(max(0, started + offset - time.perf_counter()))
        subprocess.run([str(root / 'target/presentation-capture'), name,
                        str(out / (label + '-presentation.json')), '15'], check=True)
        print(label, 'capture complete', flush=True)
for _ in range(150):
    if (out / 'completed.json').exists():
        result = json.loads((out / 'completed.json').read_text())
        assert result['status'] == 0, result
        break
    time.sleep(.5)
else:
    raise RuntimeError('finite run did not complete; leave own window for inspection')
subprocess.run(['osascript', '-e',
                f'tell application "/Applications/iTerm.app" to close (every window whose id is {window})'],
               check=True)
print('complete', mode, flush=True)
