import importlib.util, json, re
from pathlib import Path
work=Path(__file__).parent/'relay'
raw=(work/'stream.bin').read_bytes()
frames=re.findall(rb"\x1b\[\?2026h(.*?)\x1b\[\?2026l",raw,re.S)
assert len(frames)==1200
cols,rows=100,32
grid=[' ']*(cols*rows)
x=y=0
changes=[]
for ordinal,frame in enumerate(frames):
    before=grid.copy()
    text=frame.decode('utf-8')
    end=0
    for match in re.finditer(r"\x1b\[([0-?]*)([ -/]*)([@-~])|([^\x1b]+)",text):
        assert match.start()==end, (ordinal, repr(text[end:match.start()]))
        end=match.end()
        if match.group(4) is not None:
            for glyph in match.group(4):
                assert ord(glyph)>=32 and 0<=x<cols and 0<=y<rows,(ordinal,x,y,repr(glyph))
                grid[y*cols+x]=' ' if glyph=='\u2800' else glyph
                x+=1
        else:
            params,intermediate,command=match.group(1,2,3)
            assert not intermediate
            if command=='H':
                parts=[int(n or '1') for n in params.split(';')]
                y=parts[0]-1;x=(parts[1] if len(parts)>1 else 1)-1
            elif command=='C':
                x+=int(params or '1')
            elif command=='m':
                pass # Only glyph identities are compared, independent of color.
            else:
                raise AssertionError((ordinal,params,command))
    assert end==len(text)
    changes.append(sum(a!=b for a,b in zip(before,grid)))
(work/'glyph-changes.json').write_text(json.dumps(changes)+'\n')
trace=[json.loads(line) for line in (work/'braille.jsonl').read_text().splitlines()]
assert len(trace)==len(changes)+1
steady=[c for c,r in zip(changes,trace[1:]) if r['start_us']>=3e6]
report=json.loads((work/'braille-presentation.json').read_text())
t=[f['pts'] for f in report['frames'] if f['changed']]
spec=importlib.util.spec_from_file_location('report',Path(__file__).resolve().parents[3]/'tools/trace-report.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
summary={'submitted_frames':len(changes),'after_warmup_frames':len(steady),'after_warmup_frames_with_glyph_changes':sum(c>0 for c in steady),'minimum_changed_glyphs_after_warmup':min(steady),'maximum_changed_glyphs_after_warmup':max(steady),'captured_samples':len(report['frames']),'visible_changes_hz':(len(t)-1)/(t[-1]-t[0]),'visible_gap_ms':m.distribution([(b-a)*1000 for a,b in zip(t,t[1:])]),'capture_cpu_seconds':report['capture_cpu_seconds'],'trace':m.summarize(work/'braille.jsonl',3),'limitations':'Extra forwarding PTY; glyph-grid changes are decoded, physical scanout and individual displayed frame IDs are not.'}
(work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
