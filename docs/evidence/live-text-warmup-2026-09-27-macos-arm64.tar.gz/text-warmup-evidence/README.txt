Text warm-up investigation on M4 Pro, macOS 26.5.2 and iTerm 3.6.6.

Production rendering is unchanged from metadata.json's parent. This change adds
repeated CPU intervals and records the effect of terminal glyph cache warm-up.
The default single-interval JSON schema remains unchanged.

probes/relay retains the extra-PTY stream and glyph-grid analysis. The native
Rust replayer sends the same recorded frames without simulation or composition.
warm-visible and warm-cpu repeat the identical 20-second corpus in one window;
capture and quiet CPU observations are separate. live-warm-cpu uses the revised
harness with the actual default simulation in windows around seconds 3–18 and
43–58. live-warm-visible separately captures the actual default scene in those
parts of its run. The simulation changes naturally within a fixed configuration.
Both measured windows precede the 60-second idle threshold.

compact_styles.py is a rejected prototype. Normal unselected glyph/color cells
match, but retained foregrounds can change selection/cursor behavior on blank
cells. Bytes and SGR counts fall without a meaningful CPU or pacing improvement.
No production style change was retained.

The profile excerpt is intrusive diagnostic evidence. Stack counts are not CPU
percentages. Official iTerm source URLs and checked hashes are retained without
redistributing those sources. Glyph keys include visual column, and the cache
allows 65,536 entries; these observations do not establish capacity thrashing.

The relay stream is the canonical frame input. To reconstruct frames.bin, extract
each full ESC[?2026h ... ESC[?2026l block (DOTALL, nongreedy), prefix each with its
little-endian uint32 byte length, and concatenate. There are 1,200 frames.
twice-frames.bin concatenates that framed file with itself. compact_styles.py
regenerates compact-frames.bin. metadata.json retains all three expected hashes.
Build replay.rs with rustc --edition=2024 -O, --extern pointing to the release
librbirds.rlib and -L dependency=target/release/deps from the recorded parent.

Drivers contain original absolute paths and owned process/window IDs. Adapt
those to fresh output directories and currently owned processes before reuse.
They only controlled rbirds-perf windows. The completion wrapper in source/
includes the atomic-publication correction after the visible driver's JSON read
race. That original error log is retained; the child exited successfully and
the owned window was subsequently closed. No installed executable or terminal
preference was replaced. Screenshots are of the owned test windows only.

Presentation compares every content pixel at the logical capture resolution.
Color/blank diagnostics sample a grid. Captures are not physical scanout, and
no individual displayed frame IDs were decoded. Quiet CPU runs have no capture,
profiler, build or tests; shared iTerm sessions, compositor/GPU and unknown helper
costs limit attribution. Measurements describe this host and these runs.
