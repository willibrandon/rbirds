import json, os, subprocess, sys, time
title, output, *command = sys.argv[1:]
assert title.startswith('rbirds-perf-')
os.write(1, f'\x1b]0;{title}\x07'.encode())
time.sleep(2)
start=time.monotonic()
result=subprocess.run(command, stderr=subprocess.PIPE)
status=result.returncode
with open(output + '.tmp', 'w') as f:
    json.dump({'status': status, 'stderr':result.stderr.decode(errors='replace'), 'wall_seconds':time.monotonic()-start, 'command':command}, f)
os.replace(output + '.tmp', output)
raise SystemExit(status)
