import hashlib, json, shutil, tarfile
from pathlib import Path

root = Path('/Users/brandon/src/rbirds')
work = Path(__file__).resolve().parent
stage = work / 'evidence'
stage.mkdir()
names = [
    'binaries.json', 'setup.json', 'owned-window.json', 'app-process.json',
    'session.json', 'cleanup.json', 'bench.py', 'bench.json', 'bench.log',
    'small.py', 'small.json', 'small.log', 'large-boundary.py',
    'large-boundary.json', 'large-boundary.log', 'before-flock.rs',
    'before-grid.rs', 'changes.patch', 'first-flock.rs', 'first-grid.rs',
    'first-bench.json', 'first-bench.log', 'measured.patch',
    'live.py', 'session.py', 'setup.py', 'cleanup.py', 'analyze.py',
    'build-evidence.py', 'cpu-summary.json', 'cpu-intervals.json',
    'visible-summary.json', 'phase-summary.json', 'native-debug-checks.log',
    'final-release-checks.log', 'rosetta-checks.log',
    'final-active-items-checks.log', 'final-clippy.log',
    'spare-storage-before.log', 'spare-storage-debug.log',
    'spare-storage-release.log', 'spare-storage-rosetta.log',
]
names += [str(p.relative_to(work))
          for directory in ['cpu', 'visible', 'preliminary']
          for p in (work / directory).rglob('*')
          if p.is_file() and p.suffix in ['.json', '.jsonl', '.png', '.log']]
assert len(names) == len(set(names))
for name in names:
    src = work / name
    dst = stage / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
for name in ['src/simulation/flock.rs', 'src/spatial_grid.rs',
             'tools/terminal-perf.py', 'tools/process_usage.py',
             'tools/measurement_clock.py', 'tools/trace_alignment.py',
             'tools/presentation-capture.swift']:
    dst = stage / 'source' / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, dst)
manifest = {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(stage.rglob('*')) if p.is_file()}
(stage / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'docs/evidence/live-sorted-neighbors-2026-09-27-macos-arm64.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(stage, arcname='sorted-neighbors')
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        actual = hashlib.sha256(tar.extractfile('sorted-neighbors/' + name).read()).hexdigest()
        assert actual == expected, name
report = {'files': len(manifest), 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(work / 'archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(report)
