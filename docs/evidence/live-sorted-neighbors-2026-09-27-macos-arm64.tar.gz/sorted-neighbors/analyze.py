import collections, csv, json, statistics
from pathlib import Path
import numpy as np
from PIL import Image

work=Path(__file__).resolve().parent
def save(name,value):
    (work/name).write_text(json.dumps(value,indent=2)+'\n')

visible={}
for p in sorted((work/'visible').glob('*/presentation.json')):
    d=json.loads(p.read_text());f=d['frames'];focus=d['focus_observations']
    c=[x['pts'] for x in f if x['changed']];g=np.diff(c)*1000
    visible[p.parent.name]={'samples':len(f),'changes_per_second':(len(c)-1)/(c[-1]-c[0]),'p99_gap_ms':float(np.percentile(g,99)),'max_gap_ms':float(max(g)),
        'dominant_colors':dict(collections.Counter(str(x['dominant_rgb']) for x in f)),
        'max_dominant_fraction':max(x['dominant_fraction'] for x in f),
        'focus_observations':len(focus),'owner_active':sum(x['owner_active'] for x in focus),'top_content_window':sum(x['top_normal_window'] for x in focus),'capture_cpu_seconds':d['capture_cpu_seconds']}
save('visible-summary.json',visible)

cpu={};intervals=[]
for p in sorted((work/'cpu').glob('*/cpu.json')):
    d=json.loads(p.read_text());assert d['measurement_valid'];i=d['interval_sample']
    scene,index,side=p.parent.name.rsplit('-',2);alignment=i['trace_alignment'];lo=alignment['submitted_frames_min'];hi=alignment['submitted_frames_max']
    app=i['application_cpu_ms_per_second'];terminal=i['terminal_cpu_ms_per_second'];helper=i['terminal_helpers']['cpu_ms_per_second']
    observations=json.loads((p.parent/'observations.json').read_text());focus=[o['owner_active'] for o in observations if 'owner_active' in o]
    intervals.append({'scene':scene,'side':side,'index':int(index),'application':app,'terminal':terminal,'decoder':helper,'combined':app+terminal+helper,'submitted_min':lo,'submitted_max':hi,
        'submitted_hz_min':lo/i['wall_seconds'],'submitted_hz_max':hi/i['wall_seconds'],'combined_ms_per_submission_min':(app+terminal+helper)*i['wall_seconds']/hi,'combined_ms_per_submission_max':(app+terminal+helper)*i['wall_seconds']/lo,
        'owner_active':sum(focus),'focus_observations':len(focus),'terminal_peak_sampled_mib':max(o['memory']['physical_footprint'] for o in observations)/2**20})
for scene in ['sixel','dense-sixel','default','kitty','dense-kitty']:
    rows=[i for i in intervals if i['scene']==scene]
    if len(rows)!=4:continue
    cpu[scene]={}
    for side in ['before','after']:
        these=[i for i in rows if i['side']==side]
        cpu[scene][side]={k:statistics.mean(i[k] for i in these) for k in ['application','terminal','decoder','combined','submitted_hz_min','submitted_hz_max','combined_ms_per_submission_min','combined_ms_per_submission_max']}
    cpu[scene]['combined_change_percent']=(cpu[scene]['after']['combined']/cpu[scene]['before']['combined']-1)*100
save('cpu-intervals.json',intervals);save('cpu-summary.json',cpu)


phase={}
for path in sorted((work/'cpu').glob('*/cpu.json')):
    i=json.loads(path.read_text())['interval_sample'];bounds=i['counter_read_bounds_ns'];lo=bounds['before'][1];hi=bounds['after'][0]
    frames=[json.loads(line) for line in (path.parent/'trace.jsonl').read_text().splitlines()]
    frames=[f for f in frames if f['kind']=='frame' and lo<=f['submitted_ns']<=hi]
    phase[path.parent.name]={key:statistics.mean(f[key] for f in frames) for key in ['update_us','compose_us','encode_us','flush_us','sleep_us','bytes']}
save('phase-summary.json',phase)
print(json.dumps({'visible':visible,'cpu':cpu,'phase':phase},indent=2))
