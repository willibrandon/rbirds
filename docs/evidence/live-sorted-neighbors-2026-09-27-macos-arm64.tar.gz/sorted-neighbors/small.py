import json,resource,subprocess,time,statistics
from pathlib import Path
w=Path(__file__).resolve().parent;rows=[]
def cpu():
    u=resource.getrusage(resource.RUSAGE_CHILDREN);return u.ru_utime+u.ru_stime
for count,frames in [(1,600000),(32,200000),(128,70000),(129,70000)]:
    command=['--render','kitty','--bench',str(frames),'--seed','42','--birds',str(count)]
    for side in ['before','after','after','before']:
        start=time.perf_counter();before=cpu();raw=subprocess.check_output([str(w/(side+'-rbirds')),*command],text=True);elapsed=time.perf_counter()-start;used=cpu()-before
        rows.append({'count':count,'side':side,'command':command,'wall_seconds':elapsed,'cpu_seconds':used,'cpu_us_per_frame':used*1e6/frames,'stdout':raw});(w/'small.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(count,{side:statistics.mean(r['cpu_us_per_frame'] for r in rows if r['count']==count and r['side']==side) for side in ['before','after']},flush=True)
